import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";

interface OnboardingData {
  businessType: string;
  companyName: string;
  registrationNumber: string;
  incorporationCountry: string;
  businessAddress: string;
  annualTurnover: string;
  tradeActivity: string;
  goodsType: string;
  tradingCountries: string[];
  bankingRelationship: string;
  creditFacilities: string;
  complianceFramework: string;
  riskAppetite: string;
  documentationRequirements: string;
  expectedTransactionVolume: string;
  paymentTerms: string;
  currency: string;
  businessExperience: string;
}

export function CustomerOnboarding() {
  const [currentStep, setCurrentStep] = useState(1);
  const [formData, setFormData] = useState<OnboardingData>({
    businessType: '',
    companyName: '',
    registrationNumber: '',
    incorporationCountry: '',
    businessAddress: '',
    annualTurnover: '',
    tradeActivity: '',
    goodsType: '',
    tradingCountries: [],
    bankingRelationship: '',
    creditFacilities: '',
    complianceFramework: '',
    riskAppetite: '',
    documentationRequirements: '',
    expectedTransactionVolume: '',
    paymentTerms: '',
    currency: '',
    businessExperience: ''
  });
  
  const { toast } = useToast();

  const updateField = (field: keyof OnboardingData, value: string | string[]) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const nextStep = () => {
    if (currentStep < 4) {
      setCurrentStep(currentStep + 1);
    }
  };

  const prevStep = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
    }
  };

  const submitMutation = useMutation({
    mutationFn: async (data: OnboardingData) => {
      // Simulate API submission
      await new Promise(resolve => setTimeout(resolve, 2000));
      return { success: true, customerId: 'CUST-' + Date.now() };
    },
    onSuccess: (result) => {
      toast({
        title: "Customer Onboarding Complete",
        description: `Customer ID: ${result.customerId} has been created successfully`,
      });
    },
    onError: () => {
      toast({
        title: "Submission Failed",
        description: "Unable to complete onboarding. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = () => {
    submitMutation.mutate(formData);
  };

  const renderStep1 = () => (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-semibold text-slate-900 mb-4">Company Information</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">Business Type</label>
            <select
              value={formData.businessType}
              onChange={(e) => updateField('businessType', e.target.value)}
              className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            >
              <option value="">Select Business Type</option>
              <option value="manufacturer">Manufacturer</option>
              <option value="exporter">Exporter</option>
              <option value="importer">Importer</option>
              <option value="trading_company">Trading Company</option>
              <option value="distributor">Distributor</option>
              <option value="retailer">Retailer</option>
              <option value="service_provider">Service Provider</option>
            </select>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">Company Name</label>
            <input
              type="text"
              value={formData.companyName}
              onChange={(e) => updateField('companyName', e.target.value)}
              className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              placeholder="Enter company legal name"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">Registration Number</label>
            <input
              type="text"
              value={formData.registrationNumber}
              onChange={(e) => updateField('registrationNumber', e.target.value)}
              className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              placeholder="Company registration number"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">Country of Incorporation</label>
            <input
              type="text"
              value={formData.incorporationCountry}
              onChange={(e) => updateField('incorporationCountry', e.target.value)}
              className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              placeholder="Country where company is registered"
            />
          </div>
        </div>
        
        <div className="mt-6">
          <label className="block text-sm font-medium text-slate-700 mb-2">Business Address</label>
          <textarea
            value={formData.businessAddress}
            onChange={(e) => updateField('businessAddress', e.target.value)}
            rows={3}
            className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            placeholder="Complete business address including postal code"
          />
        </div>
        
        <div className="mt-6">
          <label className="block text-sm font-medium text-slate-700 mb-2">Annual Turnover (USD)</label>
          <select
            value={formData.annualTurnover}
            onChange={(e) => updateField('annualTurnover', e.target.value)}
            className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          >
            <option value="">Select Annual Turnover Range</option>
            <option value="under_1m">Under $1 Million</option>
            <option value="1m_5m">$1 - $5 Million</option>
            <option value="5m_25m">$5 - $25 Million</option>
            <option value="25m_100m">$25 - $100 Million</option>
            <option value="100m_500m">$100 - $500 Million</option>
            <option value="over_500m">Over $500 Million</option>
          </select>
        </div>
      </div>
    </div>
  );

  const renderStep2 = () => (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-semibold text-slate-900 mb-4">Trade Activities</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">Primary Trade Activity</label>
            <select
              value={formData.tradeActivity}
              onChange={(e) => updateField('tradeActivity', e.target.value)}
              className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            >
              <option value="">Select Trade Activity</option>
              <option value="import_only">Import Only</option>
              <option value="export_only">Export Only</option>
              <option value="import_export">Import & Export</option>
              <option value="domestic_trade">Domestic Trade</option>
              <option value="re_export">Re-export</option>
              <option value="transit_trade">Transit Trade</option>
            </select>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">Type of Goods</label>
            <select
              value={formData.goodsType}
              onChange={(e) => updateField('goodsType', e.target.value)}
              className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            >
              <option value="">Select Goods Type</option>
              <option value="raw_materials">Raw Materials</option>
              <option value="agricultural">Agricultural Products</option>
              <option value="textiles">Textiles & Apparel</option>
              <option value="machinery">Machinery & Equipment</option>
              <option value="electronics">Electronics & Technology</option>
              <option value="chemicals">Chemicals & Pharmaceuticals</option>
              <option value="automotive">Automotive Parts</option>
              <option value="food_beverages">Food & Beverages</option>
              <option value="energy">Energy & Oil Products</option>
              <option value="metals">Metals & Minerals</option>
              <option value="consumer_goods">Consumer Goods</option>
            </select>
          </div>
        </div>
        
        <div className="mt-6">
          <label className="block text-sm font-medium text-slate-700 mb-2">Trading Countries/Regions</label>
          <textarea
            value={formData.tradingCountries.join(', ')}
            onChange={(e) => updateField('tradingCountries', e.target.value.split(', ').filter(country => country.trim()))}
            rows={3}
            className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            placeholder="List countries/regions you trade with (comma separated)"
          />
        </div>
        
        <div className="mt-6">
          <label className="block text-sm font-medium text-slate-700 mb-2">Expected Transaction Volume (Monthly)</label>
          <select
            value={formData.expectedTransactionVolume}
            onChange={(e) => updateField('expectedTransactionVolume', e.target.value)}
            className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          >
            <option value="">Select Transaction Volume</option>
            <option value="under_100k">Under $100,000</option>
            <option value="100k_500k">$100,000 - $500,000</option>
            <option value="500k_1m">$500,000 - $1 Million</option>
            <option value="1m_5m">$1 - $5 Million</option>
            <option value="5m_25m">$5 - $25 Million</option>
            <option value="over_25m">Over $25 Million</option>
          </select>
        </div>
      </div>
    </div>
  );

  const renderStep3 = () => (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-semibold text-slate-900 mb-4">Banking & Finance Requirements</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">Existing Banking Relationship</label>
            <select
              value={formData.bankingRelationship}
              onChange={(e) => updateField('bankingRelationship', e.target.value)}
              className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            >
              <option value="">Select Banking Status</option>
              <option value="new_customer">New Customer</option>
              <option value="existing_domestic">Existing Domestic Banking</option>
              <option value="existing_trade">Existing Trade Finance Customer</option>
              <option value="multiple_banks">Multiple Banking Relationships</option>
            </select>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">Required Credit Facilities</label>
            <select
              value={formData.creditFacilities}
              onChange={(e) => updateField('creditFacilities', e.target.value)}
              className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            >
              <option value="">Select Credit Facilities</option>
              <option value="letter_of_credit">Letters of Credit</option>
              <option value="bank_guarantees">Bank Guarantees</option>
              <option value="trade_loans">Trade Loans</option>
              <option value="working_capital">Working Capital Facilities</option>
              <option value="documentary_collections">Documentary Collections</option>
              <option value="supply_chain_finance">Supply Chain Finance</option>
              <option value="multiple_facilities">Multiple Facilities</option>
            </select>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">Preferred Payment Terms</label>
            <select
              value={formData.paymentTerms}
              onChange={(e) => updateField('paymentTerms', e.target.value)}
              className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            >
              <option value="">Select Payment Terms</option>
              <option value="advance_payment">Advance Payment</option>
              <option value="open_account">Open Account</option>
              <option value="documentary_collection">Documentary Collection</option>
              <option value="letter_of_credit">Letter of Credit</option>
              <option value="mixed_terms">Mixed Terms</option>
            </select>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">Primary Currency</label>
            <select
              value={formData.currency}
              onChange={(e) => updateField('currency', e.target.value)}
              className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            >
              <option value="">Select Primary Currency</option>
              <option value="USD">US Dollar (USD)</option>
              <option value="EUR">Euro (EUR)</option>
              <option value="GBP">British Pound (GBP)</option>
              <option value="JPY">Japanese Yen (JPY)</option>
              <option value="CNY">Chinese Yuan (CNY)</option>
              <option value="CHF">Swiss Franc (CHF)</option>
              <option value="CAD">Canadian Dollar (CAD)</option>
              <option value="AUD">Australian Dollar (AUD)</option>
              <option value="multiple">Multiple Currencies</option>
            </select>
          </div>
        </div>
      </div>
    </div>
  );

  const renderStep4 = () => (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-semibold text-slate-900 mb-4">Compliance & Risk Assessment</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">Compliance Framework</label>
            <select
              value={formData.complianceFramework}
              onChange={(e) => updateField('complianceFramework', e.target.value)}
              className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            >
              <option value="">Select Compliance Level</option>
              <option value="basic">Basic Compliance</option>
              <option value="enhanced">Enhanced Due Diligence</option>
              <option value="pep_screening">PEP Screening Required</option>
              <option value="high_risk">High-Risk Jurisdiction</option>
              <option value="sanctions_screening">Enhanced Sanctions Screening</option>
            </select>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">Risk Appetite</label>
            <select
              value={formData.riskAppetite}
              onChange={(e) => updateField('riskAppetite', e.target.value)}
              className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            >
              <option value="">Select Risk Appetite</option>
              <option value="conservative">Conservative</option>
              <option value="moderate">Moderate</option>
              <option value="aggressive">Aggressive</option>
              <option value="country_specific">Country-Specific Assessment</option>
            </select>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">Documentation Requirements</label>
            <select
              value={formData.documentationRequirements}
              onChange={(e) => updateField('documentationRequirements', e.target.value)}
              className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            >
              <option value="">Select Documentation Level</option>
              <option value="standard">Standard Documentation</option>
              <option value="enhanced">Enhanced Documentation</option>
              <option value="simplified">Simplified Process</option>
              <option value="digital_only">Digital-Only Processing</option>
            </select>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">Years in Trade Finance</label>
            <select
              value={formData.businessExperience}
              onChange={(e) => updateField('businessExperience', e.target.value)}
              className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            >
              <option value="">Select Experience Level</option>
              <option value="new">New to Trade Finance</option>
              <option value="1_3_years">1-3 Years</option>
              <option value="3_5_years">3-5 Years</option>
              <option value="5_10_years">5-10 Years</option>
              <option value="over_10_years">Over 10 Years</option>
            </select>
          </div>
        </div>
      </div>
    </div>
  );

  return (
    <div className="flex-1 flex flex-col">
      {/* Progress Header */}
      <div className="border-b border-slate-200 p-6 bg-white">
        <div className="max-w-4xl">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-medium text-slate-900">Customer Onboarding Process</h3>
            <span className="text-sm text-slate-500">Step {currentStep} of 4</span>
          </div>
          
          {/* Progress Bar */}
          <div className="w-full bg-gray-200 rounded-full h-2">
            <div 
              className="bg-blue-600 h-2 rounded-full transition-all duration-300"
              style={{ width: `${(currentStep / 4) * 100}%` }}
            ></div>
          </div>
          
          {/* Step Labels */}
          <div className="flex justify-between mt-2 text-xs text-slate-500">
            <span className={currentStep >= 1 ? 'text-blue-600 font-medium' : ''}>Company Info</span>
            <span className={currentStep >= 2 ? 'text-blue-600 font-medium' : ''}>Trade Activities</span>
            <span className={currentStep >= 3 ? 'text-blue-600 font-medium' : ''}>Banking & Finance</span>
            <span className={currentStep >= 4 ? 'text-blue-600 font-medium' : ''}>Compliance & Risk</span>
          </div>
        </div>
      </div>

      {/* Form Content */}
      <div className="flex-1 overflow-y-auto p-6">
        <div className="max-w-4xl">
          {currentStep === 1 && renderStep1()}
          {currentStep === 2 && renderStep2()}
          {currentStep === 3 && renderStep3()}
          {currentStep === 4 && renderStep4()}
        </div>
      </div>

      {/* Navigation Footer */}
      <div className="border-t border-slate-200 p-6 bg-white">
        <div className="max-w-4xl flex justify-between">
          <button
            onClick={prevStep}
            disabled={currentStep === 1}
            className="px-4 py-2 text-slate-600 hover:text-slate-900 disabled:text-slate-400 disabled:cursor-not-allowed"
          >
            Previous
          </button>
          
          <div className="flex space-x-3">
            {currentStep < 4 ? (
              <button
                onClick={nextStep}
                className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
              >
                Next Step
              </button>
            ) : (
              <button
                onClick={handleSubmit}
                disabled={submitMutation.isPending}
                className="px-6 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 disabled:bg-gray-400 disabled:cursor-not-allowed transition-colors"
              >
                {submitMutation.isPending ? (
                  <div className="flex items-center space-x-2">
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                    <span>Submitting...</span>
                  </div>
                ) : (
                  "Complete Onboarding"
                )}
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}