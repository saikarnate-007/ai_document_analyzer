import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient } from "@/lib/queryClient";
import { storage } from "@/lib/storage";
import { useToast } from "@/hooks/use-toast";
import { nanoid } from "nanoid";
import type { PersonalNote } from "@/lib/storage";

export function PersonalNotes() {
  const { toast } = useToast();
  const [newNote, setNewNote] = useState({ title: "", content: "" });
  const [editingNote, setEditingNote] = useState<PersonalNote | null>(null);
  
  const { data: notes = [] } = useQuery<PersonalNote[]>({
    queryKey: ["personal_notes"],
    queryFn: () => storage.getPersonalNotes(),
  });

  const saveNoteMutation = useMutation({
    mutationFn: async (note: PersonalNote) => {
      storage.savePersonalNote(note);
      return note;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["personal_notes"] });
      setNewNote({ title: "", content: "" });
      setEditingNote(null);
      toast({
        title: "Note Saved",
        description: "Your note has been saved successfully.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to save note. Please try again.",
        variant: "destructive",
      });
    },
  });

  const deleteNoteMutation = useMutation({
    mutationFn: async (noteId: string) => {
      storage.deletePersonalNote(noteId);
      return noteId;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["personal_notes"] });
      toast({
        title: "Note Deleted",
        description: "Your note has been deleted.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to delete note. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleCreateNote = () => {
    if (!newNote.title.trim()) return;
    
    const note: PersonalNote = {
      id: nanoid(),
      title: newNote.title,
      content: newNote.content,
      createdAt: new Date(),
      isCompleted: false
    };
    
    saveNoteMutation.mutate(note);
  };

  const handleUpdateNote = () => {
    if (!editingNote || !editingNote.title.trim()) return;
    
    saveNoteMutation.mutate(editingNote);
  };

  const handleToggleComplete = (note: PersonalNote) => {
    const updatedNote = { ...note, isCompleted: !note.isCompleted };
    saveNoteMutation.mutate(updatedNote);
  };

  const formatDate = (date: Date): string => {
    return new Date(date).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric'
    });
  };

  return (
    <div className="flex-1 overflow-y-auto p-4">
      <div className="space-y-6">
        {/* Add New Note */}
        <div className="bg-white rounded-lg border border-slate-200 p-4">
          <h3 className="font-semibold text-slate-900 mb-4">Add New Note</h3>
          <div className="space-y-3">
            <input
              type="text"
              value={newNote.title}
              onChange={(e) => setNewNote({...newNote, title: e.target.value})}
              placeholder="Note title..."
              className="w-full p-2 border border-slate-300 rounded-md focus:ring-2 focus:ring-primary focus:border-transparent"
            />
            <textarea
              value={newNote.content}
              onChange={(e) => setNewNote({...newNote, content: e.target.value})}
              placeholder="Note content..."
              rows={3}
              className="w-full p-2 border border-slate-300 rounded-md focus:ring-2 focus:ring-primary focus:border-transparent resize-none"
            />
            <button
              onClick={handleCreateNote}
              disabled={!newNote.title.trim() || saveNoteMutation.isPending}
              className="w-full bg-primary text-white py-2 px-4 rounded-md hover:bg-blue-700 transition-colors disabled:opacity-50"
            >
              {saveNoteMutation.isPending ? 'Saving...' : 'Add Note'}
            </button>
          </div>
        </div>

        {/* Notes List */}
        <div className="space-y-3">
          {notes.length === 0 ? (
            <div className="text-center py-8 text-slate-500">
              <i className="fas fa-sticky-note text-3xl mb-4"></i>
              <p>No notes yet. Create your first note above!</p>
            </div>
          ) : (
            notes.map((note) => (
              <div
                key={note.id}
                className={`bg-white rounded-lg border p-4 transition-all ${
                  note.isCompleted ? 'border-green-200 bg-green-50' : 'border-slate-200'
                }`}
              >
                {editingNote?.id === note.id ? (
                  <div className="space-y-3">
                    <input
                      type="text"
                      value={editingNote.title}
                      onChange={(e) => setEditingNote({...editingNote, title: e.target.value})}
                      className="w-full p-2 border border-slate-300 rounded-md focus:ring-2 focus:ring-primary focus:border-transparent"
                    />
                    <textarea
                      value={editingNote.content}
                      onChange={(e) => setEditingNote({...editingNote, content: e.target.value})}
                      rows={3}
                      className="w-full p-2 border border-slate-300 rounded-md focus:ring-2 focus:ring-primary focus:border-transparent resize-none"
                    />
                    <div className="flex space-x-2">
                      <button
                        onClick={handleUpdateNote}
                        className="px-3 py-1 bg-primary text-white rounded text-sm hover:bg-blue-700 transition-colors"
                      >
                        Save
                      </button>
                      <button
                        onClick={() => setEditingNote(null)}
                        className="px-3 py-1 bg-slate-300 text-slate-700 rounded text-sm hover:bg-slate-400 transition-colors"
                      >
                        Cancel
                      </button>
                    </div>
                  </div>
                ) : (
                  <div>
                    <div className="flex items-start justify-between mb-2">
                      <div className="flex items-center space-x-3">
                        <button
                          onClick={() => handleToggleComplete(note)}
                          className={`w-5 h-5 rounded border-2 flex items-center justify-center transition-colors ${
                            note.isCompleted 
                              ? 'bg-green-500 border-green-500 text-white' 
                              : 'border-slate-300 hover:border-slate-400'
                          }`}
                        >
                          {note.isCompleted && <i className="fas fa-check text-xs"></i>}
                        </button>
                        <h4 className={`font-medium ${
                          note.isCompleted ? 'text-green-700 line-through' : 'text-slate-900'
                        }`}>
                          {note.title}
                        </h4>
                      </div>
                      <div className="flex items-center space-x-2">
                        <button
                          onClick={() => setEditingNote(note)}
                          className="p-1 text-slate-400 hover:text-slate-600 transition-colors"
                          title="Edit note"
                        >
                          <i className="fas fa-edit text-sm"></i>
                        </button>
                        <button
                          onClick={() => deleteNoteMutation.mutate(note.id)}
                          className="p-1 text-slate-400 hover:text-red-500 transition-colors"
                          title="Delete note"
                        >
                          <i className="fas fa-trash text-sm"></i>
                        </button>
                      </div>
                    </div>
                    {note.content && (
                      <p className={`text-sm mb-2 ${
                        note.isCompleted ? 'text-green-600' : 'text-slate-600'
                      }`}>
                        {note.content}
                      </p>
                    )}
                    <p className="text-xs text-slate-400">
                      Created: {formatDate(note.createdAt)}
                    </p>
                  </div>
                )}
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}