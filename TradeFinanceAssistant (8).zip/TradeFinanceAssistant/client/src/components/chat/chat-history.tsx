import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { storage } from "@/lib/storage";
import type { ChatSession, ChatMessage } from "@/lib/storage";
import { useLocation } from "wouter";

interface ChatHistoryProps {
  onMessageSelect?: (message: string) => void;
}

export function ChatHistory({ onMessageSelect }: ChatHistoryProps = {}) {
  const [, navigate] = useLocation();
  const [expandedSession, setExpandedSession] = useState<string | null>(null);
  
  const { data: sessions = [] } = useQuery<ChatSession[]>({
    queryKey: ["chat_sessions"],
    queryFn: () => storage.getChatSessions(),
  });

  const formatRelativeTime = (date: Date): string => {
    const now = new Date();
    const diffInMinutes = Math.floor((now.getTime() - new Date(date).getTime()) / (1000 * 60));
    
    if (diffInMinutes < 1) return "Just now";
    if (diffInMinutes < 60) return `${diffInMinutes} min ago`;
    
    const diffInHours = Math.floor(diffInMinutes / 60);
    if (diffInHours < 24) return `${diffInHours}h ago`;
    
    const diffInDays = Math.floor(diffInHours / 24);
    return `${diffInDays}d ago`;
  };

  const handleSessionClick = (sessionId: string) => {
    navigate(`/chat/${sessionId}`);
  };

  const toggleSessionExpansion = (sessionId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setExpandedSession(expandedSession === sessionId ? null : sessionId);
  };

  const handleMessageClick = (content: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (onMessageSelect) {
      onMessageSelect(content);
      // Switch to chat assistant section
      navigate('/chat');
    }
  };

  const getSessionMessages = (sessionId: string): ChatMessage[] => {
    return storage.getChatMessages(sessionId);
  };

  return (
    <div className="flex-1 overflow-y-auto p-4">
      <div className="space-y-3">
        {sessions.length === 0 ? (
          <p className="text-sm text-slate-500 italic">No chat history yet</p>
        ) : (
          sessions.map((session) => {
            const sessionMessages = getSessionMessages(session.id);
            const isExpanded = expandedSession === session.id;
            
            return (
              <div key={session.id} className="border border-slate-200 rounded-lg overflow-hidden">
                <div
                  onClick={() => handleSessionClick(session.id)}
                  className="p-3 hover:bg-slate-50 cursor-pointer transition-colors"
                >
                  <div className="flex items-start justify-between">
                    <div className="flex-1 min-w-0">
                      <h4 className="font-medium text-slate-900 truncate">{session.title}</h4>
                      <p className="text-sm text-slate-500 mt-1">
                        {session.messageCount} messages • {formatRelativeTime(session.lastActivity)}
                      </p>
                    </div>
                    <div className="flex items-center space-x-2 ml-2">
                      <button
                        onClick={(e) => toggleSessionExpansion(session.id, e)}
                        className="p-1 text-slate-400 hover:text-slate-600 transition-colors"
                        title="View messages"
                      >
                        <i className={`fas ${isExpanded ? 'fa-chevron-up' : 'fa-chevron-down'} text-xs`}></i>
                      </button>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          storage.clearSession(session.id);
                          // Trigger refetch
                          window.location.reload();
                        }}
                        className="p-1 text-slate-400 hover:text-red-500 transition-colors"
                        title="Delete chat"
                      >
                        <i className="fas fa-trash text-xs"></i>
                      </button>
                    </div>
                  </div>
                </div>
                
                {isExpanded && (
                  <div className="border-t border-slate-100 bg-slate-50 p-3">
                    <div className="space-y-2 max-h-60 overflow-y-auto">
                      {sessionMessages.length === 0 ? (
                        <p className="text-xs text-slate-500 italic">No messages in this session</p>
                      ) : (
                        sessionMessages
                          .filter(msg => msg.role === 'user')
                          .slice(-5) // Show last 5 user messages
                          .map((message) => (
                            <div
                              key={message.id}
                              onClick={(e) => handleMessageClick(message.content, e)}
                              className="p-2 bg-white rounded border border-slate-200 hover:bg-blue-50 cursor-pointer transition-colors text-sm"
                            >
                              <div className="flex items-start space-x-2">
                                <i className="fas fa-user text-slate-400 text-xs mt-1"></i>
                                <span className="text-slate-700 line-clamp-2">{message.content}</span>
                              </div>
                              <div className="text-xs text-slate-500 mt-1">
                                Click to use in Chat Assistant
                              </div>
                            </div>
                          ))
                      )}
                    </div>
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}