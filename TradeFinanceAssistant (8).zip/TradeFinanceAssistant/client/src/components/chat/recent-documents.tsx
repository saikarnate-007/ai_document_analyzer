import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { FileText, Calendar, Eye, Download } from 'lucide-react';
import { Document } from '@shared/schema';

interface RecentDocumentsProps {
  onDocumentSelect?: (document: Document) => void;
}

export function RecentDocuments({ onDocumentSelect }: RecentDocumentsProps) {
  const [selectedDocument, setSelectedDocument] = useState<Document | null>(null);

  // Fetch recent documents
  const { data: recentDocuments = [], isLoading } = useQuery<Document[]>({
    queryKey: ['/api/documents/recent'],
    enabled: true
  });

  const formatFileSize = (bytes: number): string => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const formatDate = (date: Date): string => {
    return new Date(date).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const getFileTypeIcon = (fileType: string) => {
    if (fileType.startsWith('image/')) {
      return '🖼️';
    } else if (fileType === 'application/pdf') {
      return '📄';
    } else if (fileType.includes('word')) {
      return '📝';
    }
    return '📄';
  };

  const handleDocumentClick = (document: Document) => {
    setSelectedDocument(document);
    if (onDocumentSelect) {
      onDocumentSelect(document);
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2">
        <FileText className="h-5 w-5 text-blue-600" />
        <h2 className="text-xl font-semibold">Recent Documents</h2>
      </div>

      {isLoading ? (
        <div className="space-y-3">
          {[...Array(5)].map((_, i) => (
            <div key={i} className="border rounded-lg p-4 animate-pulse">
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 bg-gray-200 rounded"></div>
                <div className="flex-1 space-y-2">
                  <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                  <div className="h-3 bg-gray-200 rounded w-1/2"></div>
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : recentDocuments.length > 0 ? (
        <div className="space-y-3">
          {recentDocuments.map((document) => (
            <Card 
              key={document.id} 
              className={`cursor-pointer transition-all hover:shadow-md ${
                selectedDocument?.id === document.id ? 'ring-2 ring-blue-500 border-blue-200' : ''
              }`}
              onClick={() => handleDocumentClick(document)}
            >
              <CardContent className="p-4">
                <div className="flex items-start gap-3">
                  <div className="text-2xl">{getFileTypeIcon(document.fileType)}</div>
                  <div className="flex-1 min-w-0">
                    <h4 className="font-medium text-sm truncate">{document.originalName}</h4>
                    <div className="flex items-center gap-2 mt-1 text-xs text-gray-500">
                      <Calendar className="h-3 w-3" />
                      <span>{formatDate(document.createdAt)}</span>
                      <span>•</span>
                      <span>{formatFileSize(document.fileSize)}</span>
                    </div>
                    
                    {/* Scan Labels Used */}
                    {document.scanLabels && document.scanLabels.length > 0 && (
                      <div className="mt-2">
                        <div className="text-xs text-gray-600 mb-1">Scan Labels:</div>
                        <div className="flex flex-wrap gap-1">
                          {(document.scanLabels as string[]).slice(0, 3).map((label, index) => (
                            <Badge key={index} variant="secondary" className="text-xs px-1 py-0">
                              {label}
                            </Badge>
                          ))}
                          {(document.scanLabels as string[]).length > 3 && (
                            <Badge variant="outline" className="text-xs px-1 py-0">
                              +{(document.scanLabels as string[]).length - 3} more
                            </Badge>
                          )}
                        </div>
                      </div>
                    )}

                    {/* Extracted Fields Preview */}
                    {document.extractedFields && (document.extractedFields as any[]).length > 0 && (
                      <div className="mt-2">
                        <div className="text-xs text-gray-600 mb-1">Key Extractions:</div>
                        <div className="space-y-1">
                          {(document.extractedFields as any[]).slice(0, 2).map((field, index) => (
                            <div key={index} className="text-xs">
                              <span className="font-medium text-gray-700">{field.label}:</span>
                              <span className="ml-1 text-gray-600 truncate">{field.value}</span>
                            </div>
                          ))}
                          {(document.extractedFields as any[]).length > 2 && (
                            <div className="text-xs text-gray-500">
                              +{(document.extractedFields as any[]).length - 2} more fields
                            </div>
                          )}
                        </div>
                      </div>
                    )}
                  </div>
                  
                  <div className="flex flex-col gap-1">
                    <Button 
                      variant="ghost" 
                      size="sm"
                      className="h-8 w-8 p-0"
                      onClick={(e) => {
                        e.stopPropagation();
                        // Handle view document
                      }}
                    >
                      <Eye className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <Card>
          <CardContent className="py-8 text-center">
            <FileText className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-sm font-medium text-gray-900 mb-2">No Recent Documents</h3>
            <p className="text-sm text-gray-500">
              Upload your first trade finance document to get started with analysis and extraction.
            </p>
          </CardContent>
        </Card>
      )}

      {/* Selected Document Details */}
      {selectedDocument && (
        <Card className="border-blue-200 bg-blue-50">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm">Selected Document Details</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="grid grid-cols-2 gap-2 text-xs">
              <div>
                <span className="font-medium">File Type:</span>
                <span className="ml-1">{selectedDocument.fileType}</span>
              </div>
              <div>
                <span className="font-medium">Size:</span>
                <span className="ml-1">{formatFileSize(selectedDocument.fileSize)}</span>
              </div>
            </div>
            
            {/* All Scan Labels */}
            {selectedDocument.scanLabels && (selectedDocument.scanLabels as string[]).length > 0 && (
              <div>
                <div className="text-xs font-medium mb-2">All Scan Labels Used:</div>
                <div className="flex flex-wrap gap-1">
                  {(selectedDocument.scanLabels as string[]).map((label, index) => (
                    <Badge key={index} variant="secondary" className="text-xs">
                      {label}
                    </Badge>
                  ))}
                </div>
              </div>
            )}

            {/* All Extracted Fields */}
            {selectedDocument.extractedFields && (selectedDocument.extractedFields as any[]).length > 0 && (
              <div>
                <div className="text-xs font-medium mb-2">All Extracted Fields:</div>
                <div className="space-y-2 max-h-40 overflow-y-auto">
                  {(selectedDocument.extractedFields as any[]).map((field, index) => (
                    <div key={index} className="border-l-2 border-blue-300 pl-2">
                      <div className="text-xs">
                        <span className="font-medium text-blue-900">{field.label}:</span>
                        <div className="text-blue-800 mt-0.5">{field.value}</div>
                        {field.confidence && (
                          <div className="text-blue-600 text-xs mt-0.5">
                            Confidence: {Math.round(field.confidence * 100)}%
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            <div className="flex gap-2 pt-2">
              <Button size="sm" variant="outline" className="text-xs">
                <Eye className="h-3 w-3 mr-1" />
                View Document
              </Button>
              <Button size="sm" variant="outline" className="text-xs">
                Re-extract
              </Button>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}