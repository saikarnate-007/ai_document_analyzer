import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient } from "@/lib/queryClient";
import { FileUpload } from "@/components/ui/file-upload";
import { storage } from "@/lib/storage";
import { useToast } from "@/hooks/use-toast";
import { nanoid } from "nanoid";
import type { Document } from "@shared/schema";

interface DocumentPanelProps {
  sessionId: string;
  onClose: () => void;
}

export function DocumentPanel({ sessionId, onClose }: DocumentPanelProps) {
  const [activeTab, setActiveTab] = useState<"upload" | "analysis" | "summary">("upload");
  const [isUploading, setIsUploading] = useState(false);
  const { toast } = useToast();

  const { data: documents = [] } = useQuery<Document[]>({
    queryKey: ["documents", sessionId],
    queryFn: () => storage.getDocuments(sessionId),
    enabled: !!sessionId,
  });

  const uploadDocumentMutation = useMutation({
    mutationFn: async (file: File) => {
      // Create document entry locally first
      const document: Document = {
        id: parseInt(nanoid(), 36),
        sessionId,
        filename: `${Date.now()}_${file.name}`,
        originalName: file.name,
        fileType: file.type,
        fileSize: file.size,
        analysisResult: null,
        summary: null,
        createdAt: new Date(),
      };
      
      // Save to local storage immediately
      storage.saveDocument(sessionId, document);
      storage.addSession(sessionId);
      
      try {
        // Try to call API for analysis
        const formData = new FormData();
        formData.append("document", file);
        
        const response = await fetch(`/api/documents/${sessionId}/upload`, {
          method: "POST",
          body: formData,
        });
        
        if (response.ok) {
          const result = await response.json();
          // Update local storage with analysis results
          const updatedDocument: Document = {
            ...document,
            analysisResult: result.analysisResult,
            summary: result.summary,
          };
          storage.saveDocument(sessionId, updatedDocument);
          return result;
        } else {
          throw new Error("API upload failed");
        }
      } catch (error) {
        console.error("Upload API failed, using local storage only:", error);
        
        // Create dummy analysis for offline mode
        const dummyAnalysis = {
          summary: `Document "${file.name}" has been uploaded and saved locally. Analysis would normally be performed by AI services.`,
          compliance: [
            { status: 'pass' as const, message: 'Document format is supported', reference: 'Local Processing' },
            { status: 'warning' as const, message: 'Online analysis not available', reference: 'Offline Mode' }
          ],
          keyFindings: ['Document saved locally', 'File format validated', 'Ready for manual review']
        };
        
        // Update document with dummy analysis
        const updatedDocument: Document = {
          ...document,
          analysisResult: dummyAnalysis,
          summary: dummyAnalysis.summary,
        };
        storage.saveDocument(sessionId, updatedDocument);
        
        return updatedDocument;
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["documents", sessionId] });
      queryClient.invalidateQueries({ queryKey: ["all_documents"] });
      setActiveTab("analysis");
      toast({
        title: "Success",
        description: "Document uploaded and saved successfully",
      });
      setIsUploading(false);
    },
    onError: (error) => {
      toast({
        title: "Upload Issue",
        description: "Document saved locally. Online analysis unavailable.",
        variant: "default",
      });
      setIsUploading(false);
    },
  });

  const handleFileUpload = (files: File[]) => {
    if (files.length > 0) {
      setIsUploading(true);
      uploadDocumentMutation.mutate(files[0]);
    }
  };

  const formatFileSize = (bytes: number): string => {
    if (bytes === 0) return "0 Bytes";
    const k = 1024;
    const sizes = ["Bytes", "KB", "MB", "GB"];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + " " + sizes[i];
  };

  const getFileIcon = (fileType: string): string => {
    if (fileType.includes("pdf")) return "fas fa-file-pdf text-red-500";
    if (fileType.includes("document") || fileType.includes("word")) return "fas fa-file-word text-blue-500";
    if (fileType.includes("image")) return "fas fa-file-image text-green-500";
    return "fas fa-file text-gray-500";
  };

  const getStatusIcon = (status: "pass" | "warning" | "fail") => {
    switch (status) {
      case "pass": return "fas fa-check-circle text-green-500";
      case "warning": return "fas fa-exclamation-triangle text-yellow-500";
      case "fail": return "fas fa-times-circle text-red-500";
      default: return "fas fa-circle text-gray-500";
    }
  };

  const supportedDocTypes = [
    { icon: "fas fa-file-contract text-blue-500", name: "Letters of Credit" },
    { icon: "fas fa-ship text-blue-500", name: "Bills of Lading" },
    { icon: "fas fa-receipt text-blue-500", name: "Commercial Invoices" },
    { icon: "fas fa-certificate text-blue-500", name: "Certificates of Origin" },
    { icon: "fas fa-file-invoice text-blue-500", name: "Packing Lists" },
  ];

  return (
    <div className="flex-1 flex flex-col">
      {/* Tabs */}
      <div className="border-b border-slate-200 p-6">
        <div className="flex space-x-1 bg-slate-100 p-1 rounded-lg w-full max-w-2xl">
          <button 
            onClick={() => setActiveTab("upload")}
            className={`flex-1 px-4 py-3 rounded-md text-sm font-medium transition-colors ${
              activeTab === "upload" 
                ? "bg-white text-slate-900 shadow-sm" 
                : "text-slate-600 hover:text-slate-900"
            }`}
          >
            Upload
          </button>
          <button 
            onClick={() => setActiveTab("analysis")}
            className={`flex-1 px-4 py-3 rounded-md text-sm font-medium transition-colors ${
              activeTab === "analysis" 
                ? "bg-white text-slate-900 shadow-sm" 
                : "text-slate-600 hover:text-slate-900"
            }`}
          >
            Analysis
          </button>
          <button 
            onClick={() => setActiveTab("summary")}
            className={`flex-1 px-4 py-3 rounded-md text-sm font-medium transition-colors ${
              activeTab === "summary" 
                ? "bg-white text-slate-900 shadow-sm" 
                : "text-slate-600 hover:text-slate-900"
            }`}
          >
            Summary
          </button>
        </div>
      </div>

      {/* Panel Content */}
      <div className="flex-1 overflow-y-auto p-6">
        
        {activeTab === "upload" && (
          <div className="w-full">
            {/* Supported Document Types as Tags */}
            <div className="mb-8">
              <h4 className="text-lg font-medium text-slate-900 mb-4">Supported Document Types</h4>
              <div className="flex flex-wrap gap-3">
                {supportedDocTypes.map((type, index) => (
                  <div key={index} className="inline-flex items-center space-x-2 px-3 py-2 bg-blue-50 border border-blue-200 rounded-full text-sm text-blue-700">
                    <i className={type.icon.replace('text-blue-500', 'text-blue-600')}></i>
                    <span>{type.name}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* File Upload Area */}
            <FileUpload onFileSelect={handleFileUpload}>
              <div className="border-2 border-dashed border-slate-300 rounded-xl p-12 text-center hover:border-slate-400 transition-colors cursor-pointer bg-slate-50">
                <div className="space-y-4">
                  <div className="w-16 h-16 bg-white rounded-xl flex items-center justify-center mx-auto shadow-sm">
                    <i className="fas fa-cloud-upload-alt text-slate-500 text-2xl"></i>
                  </div>
                  <div>
                    <p className="text-xl text-slate-700 font-medium">
                      {isUploading || uploadDocumentMutation.isPending ? 'Uploading Document...' : 'Upload Document'}
                    </p>
                    <p className="text-slate-500 mt-2">
                      {isUploading || uploadDocumentMutation.isPending ? 'Please wait while we process your document...' : 'Drag & drop your file here or click to browse'}
                    </p>
                  </div>
                  <div className="text-sm text-slate-400 space-y-1">
                    <p>Supported formats: PDF, DOC, DOCX, JPG, PNG</p>
                    <p>Maximum file size: 10MB</p>
                  </div>
                </div>
              </div>
            </FileUpload>

            {/* Recent Uploads */}
            {documents.length > 0 && (
              <div className="mt-12">
                <h4 className="text-lg font-medium text-slate-900 mb-6">Recent Documents</h4>
                <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                  {documents.slice(0, 6).map((doc) => (
                    <div key={doc.id} className="border border-slate-200 rounded-lg p-4 hover:shadow-md transition-shadow">
                      <div className="flex items-start space-x-3">
                        <div className="w-12 h-12 bg-slate-100 rounded-lg flex items-center justify-center flex-shrink-0">
                          <i className={getFileIcon(doc.fileType)}></i>
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium text-slate-900 truncate">{doc.originalName}</p>
                          <p className="text-xs text-slate-500">
                            {doc.analysisResult ? "Analyzed" : "Processing"} • {formatFileSize(doc.fileSize)}
                          </p>
                        </div>
                        <button className="p-1 text-slate-400 hover:text-slate-600 transition-colors">
                          <i className="fas fa-eye"></i>
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {activeTab === "analysis" && (
          <div className="w-full space-y-4">
            {documents.filter(doc => doc.analysisResult).length === 0 ? (
              <p className="text-sm text-slate-500 italic">No analyzed documents yet</p>
            ) : (
              documents
                .filter(doc => doc.analysisResult)
                .map((doc) => (
                  <div key={doc.id} className="border border-slate-200 rounded-lg p-4">
                    <h5 className="font-medium text-slate-900 mb-2">{doc.originalName}</h5>
                    {doc.analysisResult?.compliance && (
                      <div className="space-y-2">
                        <h6 className="text-sm font-medium text-slate-700">Compliance Check</h6>
                        {doc.analysisResult.compliance.map((item: any, index: number) => (
                          <div key={index} className="flex items-start space-x-2">
                            <i className={`${getStatusIcon(item.status)} text-sm mt-0.5`}></i>
                            <div className="flex-1">
                              <p className="text-sm text-slate-700">{item.message}</p>
                              {item.reference && (
                                <p className="text-xs text-slate-500">{item.reference}</p>
                              )}
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                ))
            )}
          </div>
        )}

        {activeTab === "summary" && (
          <div className="w-full space-y-4">
            {documents.filter(doc => doc.summary).length === 0 ? (
              <p className="text-sm text-slate-500 italic">No document summaries yet</p>
            ) : (
              documents
                .filter(doc => doc.summary)
                .map((doc) => (
                  <div key={doc.id} className="border border-slate-200 rounded-lg p-4">
                    <h5 className="font-medium text-slate-900 mb-2">{doc.originalName}</h5>
                    <p className="text-sm text-slate-700">{doc.summary}</p>
                    {doc.analysisResult?.keyFindings && doc.analysisResult.keyFindings.length > 0 && (
                      <div className="mt-3">
                        <h6 className="text-sm font-medium text-slate-700 mb-2">Key Findings</h6>
                        <ul className="text-sm text-slate-600 space-y-1">
                          {doc.analysisResult.keyFindings.map((finding: string, index: number) => (
                            <li key={index} className="flex items-start space-x-2">
                              <span className="text-primary">•</span>
                              <span>{finding}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}
                  </div>
                ))
            )}
          </div>
        )}

      </div>
    </div>
  );
}
