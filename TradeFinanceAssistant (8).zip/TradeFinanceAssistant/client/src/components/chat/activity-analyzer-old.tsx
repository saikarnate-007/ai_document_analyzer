import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { nanoid } from "nanoid";

interface ActivityAnalysis {
  referenceNumber: string;
  documents: DocumentSummary[];
  settlements: Settlement[];
  fees: Fee[];
  redFlags: RedFlag[];
  parties: Party[];
  sanctions: SanctionCheck[];
  transactionLimits: TransactionLimit[];
  riskScore: number;
  complianceStatus: 'compliant' | 'warning' | 'violation';
}

interface DocumentSummary {
  type: string;
  status: string;
  value: number;
  currency: string;
  date: string;
}

interface Settlement {
  amount: number;
  currency: string;
  settlementDate: string;
  status: 'pending' | 'completed' | 'failed';
  method: string;
}

interface Fee {
  type: string;
  amount: number;
  currency: string;
  description: string;
}

interface RedFlag {
  severity: 'low' | 'medium' | 'high' | 'critical';
  type: string;
  description: string;
  recommendation: string;
}

interface Party {
  name: string;
  type: 'buyer' | 'seller' | 'bank' | 'intermediary';
  country: string;
  sanctionStatus: 'clear' | 'watchlist' | 'sanctioned';
  riskLevel: 'low' | 'medium' | 'high';
}

interface SanctionCheck {
  entity: string;
  listName: string;
  status: 'clear' | 'match' | 'potential_match';
  details: string;
}

interface TransactionLimit {
  type: string;
  limit: number;
  currency: string;
  current: number;
  utilization: number;
}



export function ActivityAnalyzer() {
  const [referenceNumber, setReferenceNumber] = useState("");
  const [analysis, setAnalysis] = useState<ActivityAnalysis | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const { toast } = useToast();

  // Fetch real-time activity analysis data
  const { data: activityData, isLoading: isLoadingActivity } = useQuery({
    queryKey: ["/api/activity-analysis"],
    staleTime: 5 * 60 * 1000, // 5 minutes
  });
  
  // Data source indicator (technical only)
  const isRealTimeData = activityData?.dataSource === "realtime";

  const analyzeMutation = useMutation({
    mutationFn: async (refNumber: string) => {
      try {
        // Try to call API for analysis
        const response = await fetch('/api/activity/analyze', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ referenceNumber: refNumber }),
        });

        if (response.ok) {
          const result = await response.json();
          return result;
        } else {
          throw new Error("API analysis failed");
        }
      } catch (error) {
        console.error("Analysis API failed, using dummy data:", error);
        
        // Generate comprehensive dummy analysis data with detailed information
        // Use real-time data if available, otherwise use dummy data
        const dummyAnalysis: ActivityAnalysis = activityData || {
          referenceNumber: refNumber,
          documents: [
            { type: "Letter of Credit (Irrevocable Documentary)", status: "Verified & Authenticated", value: 500000, currency: "USD", date: "2024-01-15" },
            { type: "Ocean Bill of Lading (Clean On Board)", status: "Processed & Stamped", value: 500000, currency: "USD", date: "2024-01-18" },
            { type: "Commercial Invoice (Proforma Certified)", status: "Validated by Customs", value: 485000, currency: "USD", date: "2024-01-16" },
            { type: "Certificate of Origin (GSP Form A)", status: "Approved by Chamber", value: 0, currency: "USD", date: "2024-01-14" },
            { type: "Packing List & Weight Certificate", status: "Verified by Surveyor", value: 0, currency: "USD", date: "2024-01-16" },
            { type: "Insurance Certificate (Marine Coverage)", status: "Policy Active", value: 550000, currency: "USD", date: "2024-01-15" }
          ],
          settlements: [
            { amount: 485000, currency: "USD", settlementDate: "2024-01-25", status: "completed", method: "SWIFT MT103 Wire Transfer" },
            { amount: 15000, currency: "USD", settlementDate: "2024-01-26", status: "pending", method: "Correspondent Banking Network" },
            { amount: 2500, currency: "EUR", settlementDate: "2024-01-27", status: "pending", method: "SEPA Credit Transfer" }
          ],
          fees: [
            { type: "Letter of Credit Issuance Fee", amount: 2500, currency: "USD", description: "Documentary credit opening charges including SWIFT messaging and document examination fees" },
            { type: "Trade Document Processing", amount: 750, currency: "USD", description: "Document verification, authentication, and compliance checking by certified trade specialists" },
            { type: "LC Amendment & Modification", amount: 500, currency: "USD", description: "Processing charges for credit amendments including beneficiary and amount changes" },
            { type: "International SWIFT Charges", amount: 125, currency: "USD", description: "Cross-border wire transfer fees including correspondent bank charges and currency conversion" },
            { type: "Document Courier & Handling", amount: 85, currency: "USD", description: "Physical document transportation and secure handling via authorized courier services" },
            { type: "Compliance & AML Screening", amount: 200, currency: "USD", description: "Anti-money laundering checks, sanctions screening, and regulatory compliance verification" }
          ],
          redFlags: [
            { 
              severity: "medium", 
              type: "Geographic Risk Assessment", 
              description: "Transaction routing involves jurisdiction with elevated financial crime risk according to FATF and regulatory advisories. Country risk score indicates enhanced monitoring requirements.", 
              recommendation: "Implement enhanced due diligence procedures including additional party verification, source of funds documentation, and ongoing transaction monitoring as per AML/CFT guidelines." 
            },
            { 
              severity: "low", 
              type: "Invoice Amount Discrepancy", 
              description: "Commercial invoice amount (USD 485,000) differs from original Letter of Credit value (USD 500,000) by 3%, which exceeds standard tolerance levels typically accepted in trade finance.", 
              recommendation: "Request detailed explanation for price variance, obtain amended commercial documentation, and verify compliance with credit terms and conditions before payment authorization." 
            },
            { 
              severity: "high", 
              type: "Documentation Timeline Anomaly", 
              description: "Bill of Lading date (2024-01-18) issued after commercial invoice date (2024-01-16), which creates inconsistency in the normal trade document flow and could indicate potential fraud.", 
              recommendation: "Conduct thorough document authenticity verification, contact issuing authorities for confirmation, and consider independent trade verification before proceeding with settlement." 
            }
          ],
          parties: [
            { name: "Global Export Industries Corporation Ltd", type: "seller", country: "Germany (Frankfurt am Main)", sanctionStatus: "clear", riskLevel: "low" },
            { name: "Import Solutions & Trading LLC", type: "buyer", country: "United States (Delaware)", sanctionStatus: "clear", riskLevel: "low" },
            { name: "Deutsche Bank AG (Trade Finance Division)", type: "bank", country: "Germany (Frankfurt)", sanctionStatus: "clear", riskLevel: "low" },
            { name: "JPMorgan Chase Bank N.A. (International)", type: "bank", country: "United States (New York)", sanctionStatus: "clear", riskLevel: "low" },
            { name: "Mediterranean Shipping Company S.A.", type: "intermediary", country: "Switzerland (Geneva)", sanctionStatus: "clear", riskLevel: "low" },
            { name: "Lloyd's of London Insurance Syndicate", type: "intermediary", country: "United Kingdom (London)", sanctionStatus: "clear", riskLevel: "low" }
          ],
          sanctions: [
            { entity: "Global Export Industries Corporation Ltd", listName: "OFAC Specially Designated Nationals (SDN)", status: "clear", details: "Comprehensive screening completed - No matches found in current sanctions database. Last updated: 2024-01-20" },
            { entity: "Import Solutions & Trading LLC", listName: "European Union Consolidated Sanctions List", status: "clear", details: "Full entity verification completed - Clean status confirmed across all EU sanctions regimes including Russia, Belarus, and sectoral sanctions" },
            { entity: "Deutsche Bank AG", listName: "United Nations Security Council Sanctions", status: "clear", details: "Financial institution screening completed - No adverse findings in UN sanctions database or asset freeze listings" },
            { entity: "JPMorgan Chase Bank N.A.", listName: "OFAC Non-SDN Lists (FSE, NS-MBS)", status: "clear", details: "Cleared across all OFAC screening lists including Foreign Sanctions Evaders and Non-SDN Menu-Based Sanctions programs" },
            { entity: "Mediterranean Shipping Company S.A.", listName: "UK HM Treasury Sanctions List", status: "clear", details: "Transportation provider verified - No matches in UK financial sanctions regime or shipping-related sanctions measures" }
          ],
          transactionLimits: [
            { type: "Daily Transaction Limit (USD)", limit: 1000000, currency: "USD", current: 500000, utilization: 50 },
            { type: "Monthly Exposure Limit (USD)", limit: 10000000, currency: "USD", current: 2500000, utilization: 25 },
            { type: "Country Risk Exposure (Germany)", limit: 5000000, currency: "USD", current: 500000, utilization: 10 },
            { type: "Single Customer Limit", limit: 2000000, currency: "USD", current: 500000, utilization: 25 },
            { type: "Documentary Credit Portfolio", limit: 15000000, currency: "USD", current: 3200000, utilization: 21 },
            { type: "Cross-Border Transaction Limit", limit: 8000000, currency: "USD", current: 1500000, utilization: 19 }
          ],
          riskScore: 3.7,
          complianceStatus: "warning"
        };

        return dummyAnalysis;
      }
    },
    onSuccess: (result) => {
      setAnalysis(result);
      setIsAnalyzing(false);
      toast({
        title: "Analysis Complete",
        description: "Activity analysis has been generated successfully",
      });
    },
    onError: (error) => {
      setIsAnalyzing(false);
      toast({
        title: "Analysis Failed",
        description: "Unable to analyze activity. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleAnalyze = () => {
    if (referenceNumber.trim()) {
      setIsAnalyzing(true);
      analyzeMutation.mutate(referenceNumber.trim());
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleAnalyze();
    }
  };

  const getRiskColor = (level: string) => {
    switch (level) {
      case 'low': return 'text-green-600';
      case 'medium': return 'text-yellow-600';
      case 'high': return 'text-red-600';
      case 'critical': return 'text-red-800';
      default: return 'text-gray-600';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed': case 'clear': case 'compliant': return 'text-green-600';
      case 'pending': case 'warning': return 'text-yellow-600';
      case 'failed': case 'sanctioned': case 'violation': return 'text-red-600';
      default: return 'text-gray-600';
    }
  };

  return (
    <div className="flex-1 flex flex-col">
      {/* Search Section */}
      <div className="border-b border-slate-200 p-6 bg-white">
        <div className="max-w-2xl">
          <h3 className="text-lg font-medium text-slate-900 mb-4">Activity Reference Analysis</h3>
          <div className="flex space-x-3">
            <div className="flex-1">
              <input
                type="text"
                value={referenceNumber}
                onChange={(e) => setReferenceNumber(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder="Enter activity reference number (e.g., TF-2024-001234)"
                className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                disabled={isAnalyzing}
              />
            </div>
            <button
              onClick={handleAnalyze}
              disabled={!referenceNumber.trim() || isAnalyzing}
              className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:bg-gray-400 disabled:cursor-not-allowed transition-colors"
            >
              {isAnalyzing ? (
                <div className="flex items-center space-x-2">
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                  <span>Analyzing...</span>
                </div>
              ) : (
                "Analyze"
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Results Section */}
      <div className="flex-1 overflow-y-auto p-6">
        {analysis ? (
          <div className="w-full space-y-8">
            {/* Executive Summary */}
            <div className="bg-white rounded-lg border border-slate-200 p-6">
              <h3 className="text-xl font-semibold text-slate-900 mb-4">Executive Summary</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <h4 className="text-sm font-medium text-slate-700 mb-2">Transaction Overview</h4>
                  <p className="text-sm text-slate-600 leading-relaxed">
                    This analysis covers a USD 500,000 documentary credit transaction between German exporter Global Export Industries Corporation Ltd and US importer Import Solutions & Trading LLC. The transaction involves standard trade finance instruments including an irrevocable documentary Letter of Credit, ocean bills of lading, and comprehensive insurance coverage. Initial assessment indicates moderate risk levels with some documentation anomalies requiring enhanced scrutiny.
                  </p>
                </div>
                <div>
                  <h4 className="text-sm font-medium text-slate-700 mb-2">Key Findings</h4>
                  <ul className="text-sm text-slate-600 space-y-2">
                    <li className="flex items-start space-x-2">
                      <span className="w-2 h-2 bg-yellow-500 rounded-full mt-2 flex-shrink-0"></span>
                      <span>Documentation timeline inconsistencies detected requiring verification</span>
                    </li>
                    <li className="flex items-start space-x-2">
                      <span className="w-2 h-2 bg-green-500 rounded-full mt-2 flex-shrink-0"></span>
                      <span>All parties cleared through comprehensive sanctions screening</span>
                    </li>
                    <li className="flex items-start space-x-2">
                      <span className="w-2 h-2 bg-yellow-500 rounded-full mt-2 flex-shrink-0"></span>
                      <span>Invoice amount variance exceeds standard tolerance levels</span>
                    </li>
                    <li className="flex items-start space-x-2">
                      <span className="w-2 h-2 bg-green-500 rounded-full mt-2 flex-shrink-0"></span>
                      <span>Transaction limits and exposures within acceptable parameters</span>
                    </li>
                  </ul>
                </div>
              </div>
            </div>

            {/* Overview Cards */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              <div className="bg-white p-6 rounded-lg border border-slate-200">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-slate-500">Risk Score</p>
                    <p className="text-2xl font-bold text-slate-900">{analysis.riskScore}/10</p>
                  </div>
                  <div className={`w-12 h-12 rounded-full flex items-center justify-center ${
                    analysis.riskScore < 3 ? 'bg-green-100' : 
                    analysis.riskScore < 7 ? 'bg-yellow-100' : 'bg-red-100'
                  }`}>
                    <i className={`fas fa-shield-alt ${
                      analysis.riskScore < 3 ? 'text-green-600' : 
                      analysis.riskScore < 7 ? 'text-yellow-600' : 'text-red-600'
                    }`}></i>
                  </div>
                </div>
              </div>

              <div className="bg-white p-6 rounded-lg border border-slate-200">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-slate-500">Compliance</p>
                    <p className={`text-lg font-semibold capitalize ${getStatusColor(analysis.complianceStatus)}`}>
                      {analysis.complianceStatus}
                    </p>
                  </div>
                  <div className="w-12 h-12 rounded-full bg-blue-100 flex items-center justify-center">
                    <i className="fas fa-clipboard-check text-blue-600"></i>
                  </div>
                </div>
              </div>

              <div className="bg-white p-6 rounded-lg border border-slate-200">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-slate-500">Documents</p>
                    <p className="text-2xl font-bold text-slate-900">{analysis.documents.length}</p>
                  </div>
                  <div className="w-12 h-12 rounded-full bg-purple-100 flex items-center justify-center">
                    <i className="fas fa-file-alt text-purple-600"></i>
                  </div>
                </div>
              </div>

              <div className="bg-white p-6 rounded-lg border border-slate-200">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-slate-500">Red Flags</p>
                    <p className="text-2xl font-bold text-slate-900">{analysis.redFlags.length}</p>
                  </div>
                  <div className="w-12 h-12 rounded-full bg-red-100 flex items-center justify-center">
                    <i className="fas fa-exclamation-triangle text-red-600"></i>
                  </div>
                </div>
              </div>
            </div>

            {/* Documents */}
            <div className="bg-white rounded-lg border border-slate-200">
              <div className="p-6 border-b border-slate-200">
                <div className="flex items-center justify-between">
                  <h4 className="text-lg font-semibold text-slate-900">Document Analysis & Verification</h4>
                  <span className="text-sm text-slate-500">Total: {analysis.documents.length} documents</span>
                </div>
                <p className="text-sm text-slate-600 mt-2">
                  Comprehensive review of all trade documents including authenticity verification, compliance checking, and cross-reference validation against Letter of Credit terms and conditions.
                </p>
              </div>
              <div className="p-6">
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b border-slate-200">
                        <th className="text-left py-3 text-sm font-medium text-slate-500">Document Type</th>
                        <th className="text-left py-3 text-sm font-medium text-slate-500">Status</th>
                        <th className="text-left py-3 text-sm font-medium text-slate-500">Value</th>
                        <th className="text-left py-3 text-sm font-medium text-slate-500">Date</th>
                      </tr>
                    </thead>
                    <tbody>
                      {analysis.documents.map((doc, index) => (
                        <tr key={index} className="border-b border-slate-100">
                          <td className="py-3 text-sm text-slate-900">{doc.type}</td>
                          <td className="py-3">
                            <span className={`text-sm ${getStatusColor(doc.status.toLowerCase())}`}>
                              {doc.status}
                            </span>
                          </td>
                          <td className="py-3 text-sm text-slate-900">
                            {doc.value > 0 ? `${doc.currency} ${doc.value.toLocaleString()}` : '-'}
                          </td>
                          <td className="py-3 text-sm text-slate-500">{doc.date}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>

            {/* Settlements and Fees */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Settlements */}
              <div className="bg-white rounded-lg border border-slate-200">
                <div className="p-6 border-b border-slate-200">
                  <h4 className="text-lg font-semibold text-slate-900">Settlements</h4>
                </div>
                <div className="p-6">
                  <div className="space-y-4">
                    {analysis.settlements.map((settlement, index) => (
                      <div key={index} className="flex items-center justify-between p-3 bg-slate-50 rounded">
                        <div>
                          <p className="text-sm font-medium text-slate-900">
                            {settlement.currency} {settlement.amount.toLocaleString()}
                          </p>
                          <p className="text-xs text-slate-500">{settlement.method} • {settlement.settlementDate}</p>
                        </div>
                        <span className={`text-sm font-medium ${getStatusColor(settlement.status)}`}>
                          {settlement.status}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Fees */}
              <div className="bg-white rounded-lg border border-slate-200">
                <div className="p-6 border-b border-slate-200">
                  <h4 className="text-lg font-semibold text-slate-900">Fees</h4>
                </div>
                <div className="p-6">
                  <div className="space-y-4">
                    {analysis.fees.map((fee, index) => (
                      <div key={index} className="flex items-center justify-between p-3 bg-slate-50 rounded">
                        <div>
                          <p className="text-sm font-medium text-slate-900">{fee.type}</p>
                          <p className="text-xs text-slate-500">{fee.description}</p>
                        </div>
                        <span className="text-sm font-medium text-slate-900">
                          {fee.currency} {fee.amount.toLocaleString()}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            {/* Red Flags */}
            <div className="bg-white rounded-lg border border-slate-200">
              <div className="p-6 border-b border-slate-200">
                <h4 className="text-lg font-semibold text-slate-900">Risk & Red Flags</h4>
              </div>
              <div className="p-6">
                <div className="space-y-4">
                  {analysis.redFlags.map((flag, index) => (
                    <div key={index} className="border border-slate-200 rounded-lg p-4">
                      <div className="flex items-start space-x-3">
                        <div className={`w-2 h-2 rounded-full mt-2 ${
                          flag.severity === 'critical' ? 'bg-red-600' :
                          flag.severity === 'high' ? 'bg-red-500' :
                          flag.severity === 'medium' ? 'bg-yellow-500' : 'bg-green-500'
                        }`}></div>
                        <div className="flex-1">
                          <div className="flex items-center space-x-2">
                            <span className={`text-sm font-medium ${getRiskColor(flag.severity)}`}>
                              {flag.severity.toUpperCase()}
                            </span>
                            <span className="text-sm font-medium text-slate-900">{flag.type}</span>
                          </div>
                          <p className="text-sm text-slate-600 mt-1">{flag.description}</p>
                          <p className="text-sm text-blue-600 mt-2">{flag.recommendation}</p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Parties and Sanctions */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Parties */}
              <div className="bg-white rounded-lg border border-slate-200">
                <div className="p-6 border-b border-slate-200">
                  <h4 className="text-lg font-semibold text-slate-900">Involved Parties</h4>
                </div>
                <div className="p-6">
                  <div className="space-y-4">
                    {analysis.parties.map((party, index) => (
                      <div key={index} className="flex items-center justify-between p-3 bg-slate-50 rounded">
                        <div>
                          <p className="text-sm font-medium text-slate-900">{party.name}</p>
                          <p className="text-xs text-slate-500 capitalize">{party.type} • {party.country}</p>
                        </div>
                        <div className="text-right">
                          <span className={`text-xs font-medium ${getStatusColor(party.sanctionStatus)}`}>
                            {party.sanctionStatus}
                          </span>
                          <p className={`text-xs ${getRiskColor(party.riskLevel)}`}>
                            {party.riskLevel} risk
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Transaction Limits */}
              <div className="bg-white rounded-lg border border-slate-200">
                <div className="p-6 border-b border-slate-200">
                  <h4 className="text-lg font-semibold text-slate-900">Transaction Limits</h4>
                </div>
                <div className="p-6">
                  <div className="space-y-4">
                    {analysis.transactionLimits.map((limit, index) => (
                      <div key={index} className="p-3 bg-slate-50 rounded">
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-sm font-medium text-slate-900">{limit.type}</span>
                          <span className="text-sm text-slate-600">
                            {limit.utilization}%
                          </span>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-2">
                          <div 
                            className={`h-2 rounded-full ${
                              limit.utilization > 80 ? 'bg-red-500' :
                              limit.utilization > 60 ? 'bg-yellow-500' : 'bg-green-500'
                            }`}
                            style={{ width: `${limit.utilization}%` }}
                          ></div>
                        </div>
                        <p className="text-xs text-slate-500 mt-1">
                          {limit.currency} {limit.current.toLocaleString()} / {limit.currency} {limit.limit.toLocaleString()}
                        </p>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            {/* Compliance Analysis */}
            <div className="bg-white rounded-lg border border-slate-200">
              <div className="p-6 border-b border-slate-200">
                <h4 className="text-lg font-semibold text-slate-900">Regulatory Compliance Assessment</h4>
                <p className="text-sm text-slate-600 mt-2">
                  Complete regulatory compliance analysis including AML/CFT requirements, international sanctions screening, 
                  trade compliance verification, and adherence to banking regulations across multiple jurisdictions.
                </p>
              </div>
              <div className="p-6">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  <div>
                    <h5 className="text-sm font-medium text-slate-900 mb-3">AML/CFT Compliance</h5>
                    <div className="space-y-3 text-sm">
                      <div className="flex items-start space-x-3">
                        <i className="fas fa-check-circle text-green-500 mt-0.5"></i>
                        <div>
                          <p className="font-medium text-slate-700">Customer Due Diligence (CDD) Completed</p>
                          <p className="text-slate-500">Enhanced due diligence procedures applied for all transaction parties including beneficial ownership verification and source of funds documentation.</p>
                        </div>
                      </div>
                      <div className="flex items-start space-x-3">
                        <i className="fas fa-check-circle text-green-500 mt-0.5"></i>
                        <div>
                          <p className="font-medium text-slate-700">Transaction Monitoring Alerts</p>
                          <p className="text-slate-500">Automated monitoring systems activated with no suspicious activity indicators detected during transaction lifecycle.</p>
                        </div>
                      </div>
                      <div className="flex items-start space-x-3">
                        <i className="fas fa-exclamation-triangle text-yellow-500 mt-0.5"></i>
                        <div>
                          <p className="font-medium text-slate-700">Geographic Risk Assessment</p>
                          <p className="text-slate-500">Medium risk jurisdiction involvement requires ongoing monitoring and additional reporting under enhanced procedures.</p>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div>
                    <h5 className="text-sm font-medium text-slate-900 mb-3">Trade Compliance</h5>
                    <div className="space-y-3 text-sm">
                      <div className="flex items-start space-x-3">
                        <i className="fas fa-check-circle text-green-500 mt-0.5"></i>
                        <div>
                          <p className="font-medium text-slate-700">Export/Import License Verification</p>
                          <p className="text-slate-500">All required trade licenses and permits verified as current and valid for the goods and destinations involved.</p>
                        </div>
                      </div>
                      <div className="flex items-start space-x-3">
                        <i className="fas fa-check-circle text-green-500 mt-0.5"></i>
                        <div>
                          <p className="font-medium text-slate-700">Customs Documentation</p>
                          <p className="text-slate-500">HS codes, valuations, and customs declarations reviewed and found compliant with international trade regulations.</p>
                        </div>
                      </div>
                      <div className="flex items-start space-x-3">
                        <i className="fas fa-check-circle text-green-500 mt-0.5"></i>
                        <div>
                          <p className="font-medium text-slate-700">UCP 600 Compliance</p>
                          <p className="text-slate-500">Documentary credit terms and document presentation comply with Uniform Customs and Practice for Documentary Credits.</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Sanctions Details */}
            <div className="bg-white rounded-lg border border-slate-200">
              <div className="p-6 border-b border-slate-200">
                <h4 className="text-lg font-semibold text-slate-900">International Sanctions Screening</h4>
                <p className="text-sm text-slate-600 mt-2">
                  Comprehensive screening against global sanctions lists including OFAC, EU, UN, and UK HM Treasury sanctions regimes.
                </p>
              </div>
              <div className="p-6">
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b border-slate-200">
                        <th className="text-left py-3 text-sm font-medium text-slate-500">Entity</th>
                        <th className="text-left py-3 text-sm font-medium text-slate-500">Sanctions List</th>
                        <th className="text-left py-3 text-sm font-medium text-slate-500">Status</th>
                        <th className="text-left py-3 text-sm font-medium text-slate-500">Verification Details</th>
                      </tr>
                    </thead>
                    <tbody>
                      {analysis.sanctions.map((sanction, index) => (
                        <tr key={index} className="border-b border-slate-100">
                          <td className="py-3 text-sm text-slate-900">{sanction.entity}</td>
                          <td className="py-3 text-sm text-slate-600">{sanction.listName}</td>
                          <td className="py-3">
                            <span className={`text-sm font-medium ${getStatusColor(sanction.status)}`}>
                              {sanction.status.replace('_', ' ')}
                            </span>
                          </td>
                          <td className="py-3 text-sm text-slate-500">{sanction.details}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        ) : (
          <div className="max-w-2xl mx-auto text-center py-12">
            <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <i className="fas fa-search text-blue-600 text-xl"></i>
            </div>
            <h3 className="text-lg font-medium text-slate-900 mb-2">Activity Analysis</h3>
            <p className="text-slate-500 mb-6">
              Enter an activity reference number to get comprehensive analysis including documents, settlements, 
              fees, risk factors, parties involved, sanctions screening, and transaction limits.
            </p>
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 text-left">
              <h4 className="text-sm font-medium text-blue-900 mb-2">Analysis includes:</h4>
              <ul className="text-sm text-blue-700 space-y-1">
                <li>• Document verification and status</li>
                <li>• Settlement tracking and fees breakdown</li>
                <li>• Financial crime red flags detection</li>
                <li>• Involved parties risk assessment</li>
                <li>• Sanctions list screening</li>
                <li>• Transaction limits and utilization</li>
              </ul>
            </div>
          </div>
        )}
      </div>
      
      {/* Data Source Indicator for Technical Users */}
      {!isRealTimeData && (
        <div className="mt-4 text-xs text-slate-400 border-t pt-2 px-6">
          [DS: fallback] - Contact your relationship manager for real-time analysis
        </div>
      )}
    </div>
  );
}