import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Download, FileText, Calendar, User, Database } from "lucide-react";
import type { Document } from "@shared/schema";

interface ExtractedField {
  label: string;
  value: string;
}

interface APIDocument extends Document {
  extractedFields?: ExtractedField[];
  scanLabels?: string[];
}

export default function APIPage() {
  const [activeTab, setActiveTab] = useState<'overview' | 'endpoints' | 'data'>('endpoints');
  const [testEndpoint, setTestEndpoint] = useState<string>('');
  const [testResponse, setTestResponse] = useState<string>('');
  const [userName] = useState<string>('Sai Kumar Karnate'); // User name for API testing
  const [selectedApiConfig, setSelectedApiConfig] = useState<any>(null);

  // Fetch API documentation
  const { data: apiDocs, isLoading: docsLoading, error: docsError } = useQuery({
    queryKey: ['/api/v1/docs'],
    queryFn: async () => {
      const response = await fetch('/api/v1/docs');
      if (!response.ok) throw new Error('Failed to fetch API docs');
      return response.json();
    }
  });

  // Fetch all documents for data preview
  const { data: documentsData, isLoading: dataLoading } = useQuery({
    queryKey: ['/api/v1/documents'],
    queryFn: async () => {
      const response = await fetch('/api/v1/documents');
      if (!response.ok) throw new Error('Failed to fetch documents');
      return response.json();
    }
  });

  // Fetch API configuration
  const { data: apiConfig, isLoading: configLoading } = useQuery({
    queryKey: ['/api/config'],
    queryFn: async () => {
      const response = await fetch('/api/config');
      if (!response.ok) throw new Error('Failed to fetch API config');
      return response.json();
    }
  });

  const testAPIEndpoint = async (endpoint: string) => {
    try {
      setTestResponse('Loading...');
      const response = await fetch(endpoint);
      const data = await response.json();
      setTestResponse(JSON.stringify(data, null, 2));
    } catch (err) {
      setTestResponse(`Error: ${err instanceof Error ? err.message : 'Unknown error'}`);
    }
  };

  const testConfiguredAPI = async (apiName: string, config: any) => {
    try {
      setTestResponse('Loading...');
      
      // Replace placeholder in prompt with actual user name
      const prompt = config.test_prompt?.replace('{user_name}', userName) || `Test request for ${apiName}`;
      
      const response = await fetch(config.endpoint, {
        method: config.method || 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...config.headers
        },
        body: JSON.stringify({
          prompt: prompt,
          user: userName,
          ...config.test_data
        })
      });
      
      const data = await response.json();
      setTestResponse(JSON.stringify(data, null, 2));
    } catch (err) {
      setTestResponse(`Error: ${err instanceof Error ? err.message : 'Unknown error'}`);
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
  };

  const downloadAPIData = (format: 'json' | 'csv') => {
    const endpoint = `/api/v1/documents?format=${format}`;
    const link = document.createElement('a');
    link.href = endpoint;
    link.download = `trade_finance_data.${format}`;
    link.click();
  };

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return "0 Bytes";
    const k = 1024;
    const sizes = ["Bytes", "KB", "MB", "GB"];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + " " + sizes[i];
  };

  const getFileTypeIcon = (fileType: string) => {
    if (fileType?.includes('pdf')) return '📄';
    if (fileType?.includes('image')) return '🖼️';
    if (fileType?.includes('word') || fileType?.includes('document')) return '📝';
    return '📎';
  };

  return (
    <div className="w-full h-full p-6 bg-white max-w-none">
      <div className="mb-8">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-2">
              <Database className="h-8 w-8 text-blue-600" />
              Trade Finance API Service
            </h1>
            <p className="text-gray-600 mt-2">
              REST API endpoints for external systems to access document analysis and extraction data
            </p>
          </div>
          <div className="flex gap-2">
            <Button onClick={() => downloadAPIData('json')} className="flex items-center gap-2">
              <Download className="h-4 w-4" />
              Download JSON
            </Button>
            <Button onClick={() => downloadAPIData('csv')} variant="outline" className="flex items-center gap-2">
              <Download className="h-4 w-4" />
              Download CSV
            </Button>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex border-b border-gray-200 mb-6">
          <button
            onClick={() => setActiveTab('overview')}
            className={`px-4 py-2 font-medium text-sm ${
              activeTab === 'overview'
                ? 'border-b-2 border-blue-600 text-blue-600'
                : 'text-gray-500 hover:text-gray-700'
            }`}
          >
            API Overview
          </button>
          <button
            onClick={() => setActiveTab('endpoints')}
            className={`px-4 py-2 font-medium text-sm ${
              activeTab === 'endpoints'
                ? 'border-b-2 border-blue-600 text-blue-600'
                : 'text-gray-500 hover:text-gray-700'
            }`}
          >
            Endpoints & Testing
          </button>
          <button
            onClick={() => setActiveTab('data')}
            className={`px-4 py-2 font-medium text-sm ${
              activeTab === 'data'
                ? 'border-b-2 border-blue-600 text-blue-600'
                : 'text-gray-500 hover:text-gray-700'
            }`}
          >
            Data Preview
          </button>
        </div>
      </div>

      {/* API Overview Tab */}
      {activeTab === 'overview' && (
        <div className="space-y-6">
          {docsLoading ? (
            <div className="flex items-center justify-center py-12">
              <div className="text-gray-500">Loading API documentation...</div>
            </div>
          ) : docsError ? (
            <Card>
              <CardContent className="p-6">
                <div className="text-center">
                  <h3 className="text-lg font-medium text-red-600 mb-2">API Documentation Unavailable</h3>
                  <p className="text-gray-600">The API documentation service is currently unavailable.</p>
                  <p className="text-sm text-gray-500 mt-2">Please contact your system administrator or try again later.</p>
                </div>
              </CardContent>
            </Card>
          ) : apiDocs ? (
            <>
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Database className="h-5 w-5" />
                    {apiDocs.title}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <p className="text-gray-700">{apiDocs.description}</p>
                      <p className="text-sm text-gray-500 mt-2">Version: {apiDocs.version}</p>
                    </div>
                    <div>
                      <h4 className="font-medium text-gray-900 mb-2">Base URL</h4>
                      <code className="bg-gray-100 px-3 py-1 rounded text-sm">{apiDocs.base_url}</code>
                      <Button 
                        onClick={() => copyToClipboard(apiDocs.base_url)}
                        variant="outline" 
                        size="sm" 
                        className="ml-2"
                      >
                        Copy
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Available Endpoints */}
              <Card>
                <CardHeader>
                  <CardTitle>Available Endpoints</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {Object.entries(apiDocs.endpoints || {}).map(([endpoint, details]: [string, any]) => (
                      <div key={endpoint} className="border-l-4 border-blue-500 pl-4">
                        <h5 className="font-medium text-gray-900">{endpoint}</h5>
                        <p className="text-gray-600 text-sm">{details.description}</p>
                        {details.parameters && (
                          <div className="mt-2">
                            <p className="text-xs font-medium text-gray-500">Parameters:</p>
                            <ul className="text-xs text-gray-600 ml-4">
                              {Object.entries(details.parameters).map(([param, desc]) => (
                                <li key={param}>• <code>{param}</code>: {desc as string}</li>
                              ))}
                            </ul>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </>
          ) : (
            <div className="text-center py-12 text-gray-500">
              Failed to load API documentation
            </div>
          )}
        </div>
      )}

      {/* Endpoints & Testing Tab */}
      {activeTab === 'endpoints' && (
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>API Endpoint Testing</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <h4 className="font-medium mb-2">Available Endpoints</h4>
                    <div className="space-y-2">
                      <button
                        onClick={() => {
                          setTestEndpoint('/api/v1/documents');
                          testAPIEndpoint('/api/v1/documents');
                        }}
                        className="w-full text-left p-3 border rounded hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-blue-500"
                      >
                        <div className="font-mono text-sm text-blue-600">GET /api/v1/documents</div>
                        <div className="text-xs text-gray-500">Get all documents with extraction data</div>
                      </button>
                      
                      <button
                        onClick={() => {
                          setTestEndpoint('/api/v1/documents?format=csv');
                          testAPIEndpoint('/api/v1/documents?format=csv');
                        }}
                        className="w-full text-left p-3 border rounded hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-blue-500"
                      >
                        <div className="font-mono text-sm text-blue-600">GET /api/v1/documents?format=csv</div>
                        <div className="text-xs text-gray-500">Download data in CSV format</div>
                      </button>
                      
                      <button
                        onClick={() => {
                          setTestEndpoint('/api/v1/docs');
                          testAPIEndpoint('/api/v1/docs');
                        }}
                        className="w-full text-left p-3 border rounded hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-blue-500"
                      >
                        <div className="font-mono text-sm text-blue-600">GET /api/v1/docs</div>
                        <div className="text-xs text-gray-500">API documentation</div>
                      </button>
                    </div>
                    
                    {/* Configured API Tests */}
                    {apiConfig?.test_endpoints && (
                      <div className="mt-6">
                        <h4 className="font-medium mb-2">Configured API Tests</h4>
                        <div className="space-y-2">
                          {Object.entries(apiConfig.test_endpoints).map(([key, config]: [string, any]) => (
                            <button
                              key={key}
                              onClick={() => {
                                setTestEndpoint(config.endpoint);
                                testConfiguredAPI(key, config);
                              }}
                              className="w-full text-left p-3 border rounded hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-blue-500"
                            >
                              <div className="font-mono text-sm text-green-600">{config.method} {config.endpoint}</div>
                              <div className="text-xs text-gray-500">{config.description}</div>
                              <div className="text-xs text-blue-600 mt-1">User: {userName}</div>
                              <div className="text-xs text-gray-400 mt-1 italic">
                                Prompt: {config.test_prompt?.replace('{user_name}', userName)}
                              </div>
                            </button>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                  
                  <div>
                    <h4 className="font-medium mb-2">Test Response</h4>
                    <div className="bg-gray-50 border rounded p-3 h-64 overflow-auto">
                      {testResponse ? (
                        <pre className="text-xs whitespace-pre-wrap">{testResponse}</pre>
                      ) : (
                        <div className="text-gray-500 text-sm">Click an endpoint to test it</div>
                      )}
                    </div>
                    {testResponse && (
                      <Button 
                        onClick={() => copyToClipboard(testResponse)} 
                        variant="outline" 
                        size="sm" 
                        className="mt-2"
                      >
                        Copy Response
                      </Button>
                    )}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Integration Examples</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <h4 className="font-medium mb-2">cURL Example</h4>
                  <code className="block bg-gray-100 p-3 rounded text-sm">
                    curl -X GET "http://localhost:5000/api/v1/documents" \<br/>
                    &nbsp;&nbsp;&nbsp;&nbsp; -H "Accept: application/json"
                  </code>
                </div>
                
                <div>
                  <h4 className="font-medium mb-2">JavaScript/Node.js Example</h4>
                  <code className="block bg-gray-100 p-3 rounded text-sm">
                    const response = await fetch('/api/v1/documents');<br/>
                    const data = await response.json();<br/>
                    console.log(data.documents);
                  </code>
                </div>
                
                <div>
                  <h4 className="font-medium mb-2">Python Example</h4>
                  <code className="block bg-gray-100 p-3 rounded text-sm">
                    import requests<br/>
                    response = requests.get('http://localhost:5000/api/v1/documents')<br/>
                    data = response.json()<br/>
                    print(data['documents'])
                  </code>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Data Preview Tab */}
      {activeTab === 'data' && (
        <div className="space-y-6">
          {dataLoading ? (
            <div className="flex items-center justify-center py-12">
              <div className="text-gray-500">Loading document data...</div>
            </div>
          ) : documentsData ? (
            <>
              {/* Stats Cards */}
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <Card>
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-gray-600">Total Documents</p>
                        <p className="text-2xl font-bold">{documentsData.total_documents || 0}</p>
                      </div>
                      <FileText className="h-8 w-8 text-blue-600" />
                    </div>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-gray-600">With Extractions</p>
                        <p className="text-2xl font-bold">
                          {documentsData.documents?.filter((d: any) => d.has_extractions).length || 0}
                        </p>
                      </div>
                      <Database className="h-8 w-8 text-green-600" />
                    </div>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-gray-600">API Status</p>
                        <p className="text-sm font-bold text-green-600">
                          {documentsData.status === 'success' ? 'Active' : 'Error'}
                        </p>
                      </div>
                      <Download className="h-8 w-8 text-purple-600" />
                    </div>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-gray-600">Last Updated</p>
                        <p className="text-xs font-medium">
                          {new Date(documentsData.timestamp).toLocaleString()}
                        </p>
                      </div>
                      <Calendar className="h-8 w-8 text-orange-600" />
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Sample Data */}
              <Card>
                <CardHeader>
                  <CardTitle>Sample API Response</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="bg-gray-50 border rounded p-4 overflow-auto max-h-96">
                    <pre className="text-xs whitespace-pre-wrap">
                      {JSON.stringify(documentsData, null, 2)}
                    </pre>
                  </div>
                  <Button 
                    onClick={() => copyToClipboard(JSON.stringify(documentsData, null, 2))} 
                    variant="outline" 
                    className="mt-2"
                  >
                    Copy Sample Response
                  </Button>
                </CardContent>
              </Card>
            </>
          ) : (
            <div className="text-center py-12 text-gray-500">
              No data available
            </div>
          )}
        </div>
      )}

      {/* Loading State */}
      {(docsLoading || dataLoading) && (
        <div className="flex items-center justify-center py-12">
          <div className="text-gray-500">Loading...</div>
        </div>
      )}
    </div>
  );
}