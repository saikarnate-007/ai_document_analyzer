import { pgTable, text, serial, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const chatMessages = pgTable("chat_messages", {
  id: serial("id").primaryKey(),
  sessionId: text("session_id").notNull(),
  role: text("role").notNull(), // 'user' | 'assistant'
  content: text("content").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const documents = pgTable("documents", {
  id: serial("id").primaryKey(),
  sessionId: text("session_id").notNull(),
  filename: text("filename").notNull(),
  originalName: text("original_name").notNull(),
  fileType: text("file_type").notNull(),
  fileSize: integer("file_size").notNull(),
  analysisResult: jsonb("analysis_result"),
  summary: text("summary"),
  scanLabels: jsonb("scan_labels"), // Array of scan labels used
  extractedFields: jsonb("extracted_fields"), // Extraction results
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const redFlagEntries = pgTable("red_flag_entries", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  keywords: jsonb("keywords").notNull(), // Array of keywords
  category: text("category").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const documentExtractionHistory = pgTable("document_extraction_history", {
  id: serial("id").primaryKey(),
  documentId: integer("document_id").notNull(),
  scanLabels: jsonb("scan_labels").notNull(), // Array of scan labels used
  extractedFields: jsonb("extracted_fields").notNull(), // Extraction results
  extractedAt: timestamp("extracted_at").defaultNow().notNull(),
});

export const insertChatMessageSchema = createInsertSchema(chatMessages).pick({
  sessionId: true,
  role: true,
  content: true,
});

export const insertDocumentSchema = createInsertSchema(documents).pick({
  sessionId: true,
  filename: true,
  originalName: true,
  fileType: true,
  fileSize: true,
});

export const insertRedFlagEntrySchema = createInsertSchema(redFlagEntries).pick({
  name: true,
  description: true,
  keywords: true,
  category: true,
});

export const insertDocumentExtractionHistorySchema = createInsertSchema(documentExtractionHistory).pick({
  documentId: true,
  scanLabels: true,
  extractedFields: true,
});

export type InsertChatMessage = z.infer<typeof insertChatMessageSchema>;
export type ChatMessage = typeof chatMessages.$inferSelect;
export type InsertDocument = z.infer<typeof insertDocumentSchema>;
export type Document = typeof documents.$inferSelect;
export type InsertRedFlagEntry = z.infer<typeof insertRedFlagEntrySchema>;
export type RedFlagEntry = typeof redFlagEntries.$inferSelect;
export type InsertDocumentExtractionHistory = z.infer<typeof insertDocumentExtractionHistorySchema>;
export type DocumentExtractionHistory = typeof documentExtractionHistory.$inferSelect;

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
