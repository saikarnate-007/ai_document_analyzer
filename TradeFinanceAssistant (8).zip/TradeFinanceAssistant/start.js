#!/usr/bin/env node

/**
 * Universal startup script for Wells Fargo Trade Finance AI Assistant
 * Works on Windows, macOS, Linux, and in VS Code
 */

const { spawn } = require('child_process');
const os = require('os');

console.log('🚀 Starting Wells Fargo Trade Finance AI Assistant...');
console.log('📍 Platform:', os.platform());
console.log('📁 Working Directory:', process.cwd());

// Cross-platform npm command
const npmCommand = os.platform() === 'win32' ? 'npm.cmd' : 'npm';

// Start the development server
const child = spawn(npmCommand, ['run', 'dev'], {
  stdio: 'inherit',
  shell: true,
  env: {
    ...process.env,
    NODE_ENV: 'development'
  }
});

child.on('error', (error) => {
  console.error('❌ Failed to start application:', error.message);
  process.exit(1);
});

child.on('close', (code) => {
  if (code !== 0) {
    console.log(`❌ Application exited with code ${code}`);
  } else {
    console.log('✅ Application stopped gracefully');
  }
});

// Handle termination signals
process.on('SIGINT', () => {
  console.log('\n🛑 Shutting down...');
  child.kill('SIGINT');
});

process.on('SIGTERM', () => {
  console.log('\n🛑 Shutting down...');
  child.kill('SIGTERM');
});