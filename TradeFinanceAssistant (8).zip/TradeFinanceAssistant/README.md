# Wells Fargo Trade Finance AI Assistant

A comprehensive trade finance platform leveraging AI to provide document analysis, risk assessment, and financial insights for global trade transactions.

## Quick Start

### Prerequisites
- **Node.js 18+** (Required)
- **npm** (Comes with Node.js)

### One-Command Setup
```bash
npm run dev
```

That's it! The application will be available at `http://localhost:5000`

**Windows Command Prompt Users**: If you get `'NODE_ENV' is not recognized`, use:
```cmd
run-windows.cmd
```
Or switch to PowerShell:
```cmd
powershell
npm run dev
```

**Other Options**:
- Double-click `start.bat`
- Run `node start.js`
- Run `dev.cmd`

## Development Commands

### Primary Command (Works Everywhere)
```bash
npm run dev
```
This single command:
- Installs dependencies if needed
- Starts both frontend and backend servers
- Enables hot reload for development
- Works in VS Code, Command Prompt, PowerShell, and Terminal

### Additional Commands
```bash
npm run check     # Type checking
npm run build     # Production build
npm run db:push   # Database schema sync
```

## VS Code Setup

### Quick Setup
1. Open project in VS Code: `code .`
2. Open terminal in VS Code: `Ctrl+`` (backtick)
3. Run: `npm run dev`

### Recommended Extensions
- TypeScript and JavaScript Language Features
- ES6 modules Syntax Highlight
- REST Client (for API testing)

### VS Code Launch Configuration
Create `.vscode/launch.json`:
```json
{
  "version": "0.2.0",
  "configurations": [
    {
      "name": "Launch Wells Fargo App",
      "type": "node",
      "request": "launch",
      "program": "${workspaceFolder}/server/index.ts",
      "runtimeArgs": ["-r", "tsx/cjs"],
      "env": {
        "NODE_ENV": "development"
      },
      "console": "integratedTerminal",
      "skipFiles": ["<node_modules>/**"]
    }
  ]
}
```

## Environment Setup

### Required Environment Variables
Create `.env` file in project root:
```
OPENAI_API_KEY=your_openai_api_key_here
NODE_ENV=development
```

### Optional Database Configuration
```
DATABASE_URL=your_postgresql_url_here
```
*Note: App works with in-memory storage by default*

## Cross-Platform Compatibility

### Windows (Command Prompt/PowerShell)
```cmd
npm run dev
```

### macOS/Linux (Terminal)
```bash
npm run dev
```

### Git Bash (Windows)
```bash
npm run dev
```

### VS Code Integrated Terminal
```bash
npm run dev
```

## API Testing

### Built-in API Testing
1. Run `npm run dev`
2. Navigate to `http://localhost:5000`
3. Go to "API & Documentation" section
4. Test all endpoints with live data

### Manual API Testing
```bash
# Test API Documentation
curl http://localhost:5000/api/v1/docs

# Test Document API
curl http://localhost:5000/api/v1/documents

# Test Chat Generation
curl -X POST http://localhost:5000/api/chat/generate \
  -H "Content-Type: application/json" \
  -d '{"prompt": "Hello Sai Kumar Karnate, please provide trade finance advice", "user": "Sai Kumar Karnate"}'
```

## Project Structure

```
├── client/                 # React frontend
│   ├── src/
│   │   ├── components/    # UI components
│   │   ├── pages/         # Application pages
│   │   └── lib/           # Utilities
├── server/                # Express backend
│   ├── config/           # API configuration
│   ├── services/         # Business logic
│   └── routes.ts         # API endpoints
├── shared/               # Shared types and schemas
└── uploads/              # File upload storage
```

## Features

### Core Features
- **Document Extraction**: Upload and analyze trade finance documents
- **AI Chat**: Wells Fargo branded trade finance assistance
- **High Risk Analysis**: Dual-use goods detection
- **API Documentation**: Live testing interface
- **Recent Documents**: Browser-cached document management

### API Endpoints
- `GET /api/v1/documents` - Document data with extractions
- `GET /api/v1/docs` - API documentation
- `POST /api/chat/generate` - AI chat responses
- `GET /api/config` - Configuration and test endpoints

### Configured API Tests
- Chat generation with personalized prompts
- Document analysis and field extraction
- High-risk goods compliance checking
- Tachyon API integration testing

## Troubleshooting

### Common Issues

**Port Already in Use:**
```bash
# Kill process on port 5000
npx kill-port 5000
npm run dev
```

**Dependencies Issue:**
```bash
# Clean install
rm -rf node_modules package-lock.json
npm install
npm run dev
```

**TypeScript Errors:**
```bash
# Check types
npm run check
```

**API Connection Issues:**
- Ensure OPENAI_API_KEY is set in `.env`
- Check network connectivity
- Verify API endpoints in browser: `http://localhost:5000/api/v1/docs`

### Getting Help
1. Check console logs in browser developer tools
2. Check terminal output for error messages
3. Verify all environment variables are set
4. Ensure Node.js version 18+ is installed

## Production Deployment

### Build for Production
```bash
npm run build
```

### Environment Variables for Production
```
NODE_ENV=production
OPENAI_API_KEY=your_production_key
DATABASE_URL=your_production_database_url
```

## Development Notes

- Uses TypeScript with ES modules
- Vite for fast frontend development
- Express.js for backend API
- In-memory storage (can be switched to PostgreSQL)
- Hot reload enabled for all code changes
- Wells Fargo branded UI with professional styling

---

**Single Command to Get Started:** `npm run dev`