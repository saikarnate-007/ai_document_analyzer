import { Express, Request, Response, NextFunction } from "express";
import { createServer, Server } from "http";
import multer from "multer";
import { z } from "zod";
import { storage } from "./storage.js";
import {
  insertChatMessageSchema,
  insertDocumentSchema,
  insertRedFlagEntrySchema,
} from "../shared/schema.js";
import * as fs from "fs";
import { generateChatResponse, getHighRiskAnalysis, analyzeImageDocument, analyzeDocument } from "./services/openai.js";

// Multer setup for file uploads
const upload = multer({
  dest: "./uploads/",
  limits: { fileSize: 10 * 1024 * 1024 }, // 10MB limit
  fileFilter: (req, file, cb) => {
    const allowedTypes = [
      "application/pdf",
      "application/msword",
      "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
      "image/jpeg",
      "image/jpg",
      "image/png",
      "text/plain"
    ];
    cb(null, allowedTypes.includes(file.mimetype));
  },
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Unified Document Extraction API - Single call with document + prompt
  app.post("/api/extract", upload.single("document"), async (req, res) => {
    try {
      const { prompt, sessionId } = req.body;
      const file = req.file;
      
      if (!file) {
        return res.status(400).json({ message: "No document provided" });
      }
      
      if (!prompt) {
        return res.status(400).json({ message: "No prompt provided" });
      }
      
      if (!sessionId) {
        return res.status(400).json({ message: "No session ID provided" });
      }

      console.log(`Document extraction request for Sai Kumar Karnate - File: ${file.originalname}, Prompt: ${prompt}`);
      
      // Create document record
      const document = await storage.createDocument({
        sessionId,
        filename: file.filename,
        originalName: file.originalname,
        fileType: file.mimetype,
        fileSize: file.size,
      });

      let analysisResult;
      let summary = "";

      // Process document based on type using unified chat/completions API
      if (file.mimetype.startsWith("image/")) {
        const fileBuffer = fs.readFileSync(file.path);
        const base64Image = fileBuffer.toString("base64");
        
        const customPrompt = `${prompt}

Document: ${file.originalname}
Task: Extract information according to Sai Kumar Karnate's request above.`;
        
        const imageAnalysis = await analyzeImageDocument(base64Image, customPrompt);
        analysisResult = imageAnalysis.analysis;
        summary = imageAnalysis.analysis.summary;
      } else {
        const fileBuffer = fs.readFileSync(file.path);
        const base64Document = fileBuffer.toString("base64");
        const fileContent = `Document: ${file.originalname} (${file.mimetype})`;
        
        const customPrompt = `${prompt}

Document: ${file.originalname}
Task: Extract information according to Sai Kumar Karnate's request above.`;
        
        analysisResult = await analyzeDocument(fileContent, customPrompt, base64Document);
        summary = analysisResult.summary;
      }

      // Update document with analysis
      const updatedDocument = await storage.updateDocumentAnalysis(
        document.id,
        analysisResult,
        summary
      );

      // Clean up uploaded file
      fs.unlinkSync(file.path);

      // Response includes document info and analysis
      res.json({
        status: "success",
        documentId: updatedDocument.id,
        documentName: updatedDocument.originalName,
        prompt: prompt,
        analysis: analysisResult,
        summary: summary,
        timestamp: new Date().toISOString(),
        addedToRecentDocuments: true
      });
      
    } catch (error) {
      console.error("Unified extraction error:", error);
      // Clean up file if it exists
      if (req.file?.path) {
        try {
          fs.unlinkSync(req.file.path);
        } catch {}
      }
      res.status(500).json({ 
        status: "error",
        message: error instanceof Error ? error.message : "Failed to process document",
        timestamp: new Date().toISOString()
      });
    }
  });

  // Unified High Risk Analysis API - Single call with document + prompt
  app.post("/api/high-risk", upload.single("document"), async (req, res) => {
    try {
      const { prompt, sessionId } = req.body;
      const file = req.file;
      
      if (!file) {
        return res.status(400).json({ message: "No document provided" });
      }
      
      if (!prompt) {
        return res.status(400).json({ message: "No prompt provided" });
      }
      
      if (!sessionId) {
        return res.status(400).json({ message: "No session ID provided" });
      }

      console.log(`High-risk analysis request for Sai Kumar Karnate - File: ${file.originalname}, Prompt: ${prompt}`);
      
      // Create document record
      const document = await storage.createDocument({
        sessionId,
        filename: file.filename,
        originalName: file.originalname,
        fileType: file.mimetype,
        fileSize: file.size,
      });

      // Process document and get high-risk analysis
      let analysisText = "";
      let documentBase64 = "";
      
      if (file.mimetype.startsWith("image/")) {
        const fileBuffer = fs.readFileSync(file.path);
        documentBase64 = fileBuffer.toString("base64");
        analysisText = `Image document: ${file.originalname}. ${prompt}`;
      } else {
        const fileBuffer = fs.readFileSync(file.path);
        documentBase64 = fileBuffer.toString("base64");
        analysisText = `Document: ${file.originalname} (${file.mimetype}). ${prompt}`;
      }

      // Get high-risk analysis using unified API
      const highRiskResult = await getHighRiskAnalysis(analysisText, documentBase64);
      
      // Update document with analysis
      const updatedDocument = await storage.updateDocumentAnalysis(
        document.id,
        highRiskResult,
        `High-risk analysis completed: ${highRiskResult.riskLevel} risk level detected`
      );

      // Clean up uploaded file
      fs.unlinkSync(file.path);

      res.json({
        status: "success",
        documentId: updatedDocument.id,
        documentName: updatedDocument.originalName,
        prompt: prompt,
        analysis: highRiskResult,
        timestamp: new Date().toISOString(),
        addedToRecentDocuments: true
      });
      
    } catch (error) {
      console.error("High-risk analysis error:", error);
      // Clean up file if it exists
      if (req.file?.path) {
        try {
          fs.unlinkSync(req.file.path);
        } catch {}
      }
      res.status(500).json({ 
        status: "error",
        message: error instanceof Error ? error.message : "Failed to analyze document for high-risk items",
        timestamp: new Date().toISOString()
      });
    }
  });

  // Unified Chat API - Single call with optional document + prompt
  app.post("/api/chat", upload.single("document"), async (req, res) => {
    try {
      const { prompt, sessionId } = req.body;
      const file = req.file;
      
      if (!prompt) {
        return res.status(400).json({ message: "No prompt provided" });
      }
      
      if (!sessionId) {
        return res.status(400).json({ message: "No session ID provided" });
      }

      console.log(`Chat request for Sai Kumar Karnate - Prompt: ${prompt}, Document: ${file?.originalname || 'none'}`);
      
      let documentId = null;
      let chatPrompt = prompt;
      
      // If document is provided, process it and add to context
      if (file) {
        // Create document record
        const document = await storage.createDocument({
          sessionId,
          filename: file.filename,
          originalName: file.originalname,
          fileType: file.mimetype,
          fileSize: file.size,
        });
        
        documentId = document.id;
        
        // Enhance prompt with document context
        if (file.mimetype.startsWith("image/")) {
          const fileBuffer = fs.readFileSync(file.path);
          const base64Image = fileBuffer.toString("base64");
          chatPrompt = `${prompt}

[Document attached: ${file.originalname} - image document for analysis]`;
          
          // For image documents, we could enhance the chat with image analysis
          // but for now, we'll just include the context
        } else {
          chatPrompt = `${prompt}

[Document attached: ${file.originalname} (${file.mimetype}) for reference]`;
        }
        
        // Clean up uploaded file
        fs.unlinkSync(file.path);
      }

      // Generate chat response using unified API
      const messages = [
        { role: 'user', content: chatPrompt }
      ];
      
      const chatResponse = await generateChatResponse(messages);
      
      // Save chat message
      const chatMessage = await storage.createChatMessage({
        sessionId,
        role: 'user',
        content: prompt,
        documentId: documentId
      });
      
      const aiMessage = await storage.createChatMessage({
        sessionId,
        role: 'assistant',
        content: chatResponse,
        documentId: documentId
      });

      res.json({
        status: "success",
        sessionId: sessionId,
        userMessage: {
          id: chatMessage.id,
          content: prompt,
          documentId: documentId,
          documentName: file?.originalname || null
        },
        aiResponse: {
          id: aiMessage.id,
          content: chatResponse
        },
        timestamp: new Date().toISOString(),
        addedToRecentDocuments: documentId ? true : false
      });
      
    } catch (error) {
      console.error("Chat API error:", error);
      // Clean up file if it exists
      if (req.file?.path) {
        try {
          fs.unlinkSync(req.file.path);
        } catch {}
      }
      res.status(500).json({ 
        status: "error",
        message: error instanceof Error ? error.message : "Failed to process chat request",
        timestamp: new Date().toISOString()
      });
    }
  });

  // Get recent documents for sidebar
  app.get("/api/recent-documents", async (req, res) => {
    try {
      const recentDocuments = await storage.getRecentDocuments(5);
      res.json(recentDocuments);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch recent documents" });
    }
  });

  // Get all documents
  app.get("/api/documents/all", async (req, res) => {
    try {
      const allDocuments = await storage.getAllDocuments();
      res.json({
        status: "success",
        total: allDocuments.length,
        documents: allDocuments,
        timestamp: new Date().toISOString()
      });
    } catch (error) {
      res.status(500).json({ 
        status: "error",
        message: "Failed to fetch documents",
        timestamp: new Date().toISOString()
      });
    }
  });

  // Get specific document
  app.get("/api/documents/:id", async (req, res) => {
    try {
      const documentId = parseInt(req.params.id);
      const document = await storage.getDocument(documentId);
      
      if (!document) {
        return res.status(404).json({ message: "Document not found" });
      }
      
      res.json(document);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch document" });
    }
  });

  // API Documentation endpoint
  app.get("/api/v1/docs", async (req, res) => {
    try {
      const apiDocs = {
        title: "Wells Fargo Trade Finance AI Assistant API",
        description: "Comprehensive REST API for document analysis, risk assessment, and AI-powered trade finance assistance",
        version: "1.0.0",
        base_url: `${req.protocol}://${req.get('host')}/api`,
        endpoints: {
          "/extract": {
            method: "POST",
            description: "Document extraction and analysis with custom prompts",
            parameters: {
              "document": "File upload (PDF, DOC, JPG, PNG)",
              "prompt": "Custom extraction instructions",
              "sessionId": "Session identifier"
            }
          },
          "/high-risk": {
            method: "POST", 
            description: "High-risk goods and dual-use item detection",
            parameters: {
              "document": "File upload (PDF, DOC, JPG, PNG)",
              "prompt": "Risk analysis instructions",
              "sessionId": "Session identifier"
            }
          },
          "/chat": {
            method: "POST",
            description: "AI chat with optional document context",
            parameters: {
              "prompt": "Chat message or question",
              "sessionId": "Session identifier",
              "document": "Optional file upload"
            }
          },
          "/v1/documents": {
            method: "GET",
            description: "Get all processed documents with metadata",
            parameters: {
              "format": "Response format (json or csv)"
            }
          },
          "/v1/documents/:id/extractions": {
            method: "GET", 
            description: "Get extraction data for specific document",
            parameters: {
              "id": "Document ID"
            }
          }
        },
        authentication: "OAuth 2.0 with Tachyon API integration",
        response_format: "JSON with status, data, and timestamp fields"
      };
      
      res.json(apiDocs);
    } catch (error) {
      res.status(500).json({ error: 'Failed to load API documentation' });
    }
  });

  // API Configuration endpoint
  app.get("/api/config", async (req, res) => {
    try {
      const configPath = "./server/config/api-config.json";
      const configData = JSON.parse(fs.readFileSync(configPath, 'utf8'));
      
      const enhancedConfig = {
        ...configData,
        unified_endpoints: {
          extract: {
            endpoint: '/api/extract',
            method: 'POST',
            description: 'Single API call: document + prompt → analysis response → added to recent documents',
            example_prompt: 'Hello {user_name}, please extract key trade finance fields from this document.',
            requires: ['document (file)', 'prompt (string)', 'sessionId (string)']
          },
          high_risk: {
            endpoint: '/api/high-risk',
            method: 'POST', 
            description: 'Single API call: document + prompt → high-risk analysis → added to recent documents',
            example_prompt: 'Hello {user_name}, analyze this document for dual-use goods and export control items.',
            requires: ['document (file)', 'prompt (string)', 'sessionId (string)']
          },
          chat: {
            endpoint: '/api/chat',
            method: 'POST',
            description: 'Single API call: prompt + optional document → chat response → document added to recent if provided',
            example_prompt: 'Hello {user_name}, help me understand this trade finance document.',
            requires: ['prompt (string)', 'sessionId (string)', 'document (file, optional)']
          }
        }
      };
      
      res.json(enhancedConfig);
    } catch (error) {
      res.status(500).json({ error: 'Failed to load API configuration' });
    }
  });

  const server = createServer(app);
  return server;
}