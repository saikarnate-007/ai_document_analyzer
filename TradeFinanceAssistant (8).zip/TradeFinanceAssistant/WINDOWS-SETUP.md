# Windows Setup Guide - Wells Fargo Trade Finance AI Assistant

## Quick Solutions for Windows Command Prompt

### Method 1: Use the Windows Script (Recommended)
```cmd
run-windows.cmd
```
This script:
- Automatically kills any existing processes on port 5000
- Sets the correct environment variables for Windows
- Starts the application properly

### Method 2: Switch to PowerShell
```cmd
powershell
npm run dev
```

### Method 3: Use the Batch File
Double-click `start.bat` in File Explorer, or run:
```cmd
start.bat
```

### Method 4: Manual Setup
If you prefer to run commands manually:
```cmd
REM Kill any existing process on port 5000
for /f "tokens=5" %a in ('netstat -aon ^| find ":5000" ^| find "LISTENING"') do taskkill /f /pid %a

REM Set environment variable
set NODE_ENV=development

REM Start the application
npx tsx server/index.ts
```

## Why This Happens

Windows Command Prompt doesn't understand the Unix-style environment variable syntax:
- ❌ `NODE_ENV=development tsx server/index.ts` (Unix/PowerShell style)
- ✅ `set NODE_ENV=development && tsx server/index.ts` (Windows CMD style)

## Verification Steps

1. **Run the application** using any method above
2. **Check the console** - you should see: `serving on port 5000`
3. **Open your browser** to: http://localhost:5000
4. **Test the API** at: http://localhost:5000/api/v1/docs

## Available Scripts for Windows

| Script | Purpose | Works in CMD |
|--------|---------|--------------|
| `run-windows.cmd` | Windows-specific startup | ✅ Yes |
| `start.bat` | Interactive startup with checks | ✅ Yes |
| `dev.cmd` | Simple Windows dev script | ✅ Yes |
| `node start.js` | Universal Node.js script | ✅ Yes |
| `npm run dev` | Standard npm script | ❌ PowerShell only |

## Troubleshooting Port Issues

If you get "address already in use" error:

### Option 1: Use the Windows Script (Automatic)
```cmd
run-windows.cmd
```
This automatically handles port conflicts.

### Option 2: Manual Port Cleanup
```cmd
REM Find what's using port 5000
netstat -aon | find ":5000"

REM Kill the process (replace XXXX with actual PID)
taskkill /f /pid XXXX

REM Or kill all Node processes
taskkill /f /im node.exe
```

## Success Indicators

When everything works correctly, you'll see:
```
Starting Wells Fargo Trade Finance AI Assistant...
Platform: Windows Command Prompt
Working Directory: C:\your\project\path
Application will be available at: http://localhost:5000
[express] serving on port 5000
```

Then open http://localhost:5000 in your browser to access the application.

## Features Available

- **Document Extraction**: Upload and analyze trade finance documents
- **AI Chat**: Wells Fargo branded assistance with personalized prompts
- **API Testing**: Live testing interface with "Sai Kumar Karnate" integration
- **High Risk Analysis**: Dual-use goods detection
- **API Documentation**: Complete REST API documentation

## Getting Help

If none of these methods work:
1. Check if Node.js is installed: `node --version`
2. Check if npm is installed: `npm --version`  
3. Ensure you're in the correct project directory
4. Try restarting Command Prompt as Administrator
5. See TROUBLESHOOTING.md for more detailed solutions