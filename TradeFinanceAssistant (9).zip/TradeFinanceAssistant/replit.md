# Trade Finance AI Assistant

## Overview

A Wells Fargo commercial banking application that provides AI-powered trade finance consultation through a chat interface with document analysis capabilities. The system specializes in trade finance assistance including Letters of Credit, Bills of Lading, Commercial Invoices, and related compliance analysis for Wells Fargo commercial banking clients.

## Quick Start Guide

### Universal Command (Works Everywhere)
```bash
npm run dev
```

### Alternative Start Methods
- **Windows**: Double-click `start.bat` or run `node start.js`
- **macOS/Linux**: Run `./start.sh` or `node start.js`
- **VS Code**: Use `Ctrl+Shift+P` → "Tasks: Run Task" → "Start Development Server"

### Application Access
- **URL**: http://localhost:5000
- **API Docs**: http://localhost:5000/api/v1/docs
- **Config**: http://localhost:5000/api/config

## User Preferences

Preferred communication style: Simple, everyday language.

## Recent Changes

### January 2025
- Fixed React Hooks order violations across all components (ActivityAnalyzer, TradeCalculations, PredictionsInsights)
- Completely rewrote ActivityAnalyzer component to eliminate hooks ordering issues
- Added cross-env package for Windows compatibility
- All components now follow proper React Hooks order with consistent rendering
- Application runs without React errors on all platforms
- Redesigned Document Analyzer with new extraction-focused interface featuring scan labels, upload/extract workflow, and document viewer
- Renamed "Document Analyzer" to "Document Extraction" throughout the application
- Temporarily hidden Activity Analyzer and Customer Onboarding sections from navigation
- Changed default section to Document Extraction when app opens
- Added new scan labels: "Ship From", "Inbound Message Text", "Vessel Name"
- Removed confidence column from extraction results grid for cleaner interface
- Integrated Tachyon API configuration with gemini-1.5-flash-002 model
- Added JSON-based API configuration file for easy updates
- Implemented OAuth token authentication for Apigee integration
- Updated all AI service calls to use Tachyon API endpoints
- Enhanced Recent Documents functionality: removed separate navigation entry, integrated into sidebar with clickable document access
- Recent Documents in sidebar now shows last 5 uploaded documents with automatic refresh
- Clicking documents in sidebar loads Document Extraction with past extraction results
- ✅ **COMPLETED: Unified Single-Call API Implementation for Sai Kumar Karnate**
- Created three unified endpoints: `/api/extract`, `/api/high-risk`, `/api/chat`
- **Single API Call Workflow**: Document + Prompt → Tachyon API → Response → Added to Recent Documents
- **Document Extraction API**: `/api/extract` - upload document with custom prompt, get analysis, auto-added to recent documents
- **High Risk Analysis API**: `/api/high-risk` - upload document with custom prompt, get risk analysis, auto-added to recent documents  
- **Trade Finance Chat API**: `/api/chat` - send prompt with optional document, get chat response, document auto-added if provided
- **Tachyon API Integration**: Uses api-config.json configuration, OAuth authentication, gemini-1.5-flash-002 model
- **Intelligent Fallback**: When Tachyon API unavailable, returns informative dummy data explaining service status
- **Personalized for Sai Kumar Karnate**: All prompts and responses customized with user's name as requested
- **Recent Documents Integration**: All successful API calls automatically add documents to recent documents list
- **Comprehensive Testing**: APIs tested with curl commands, returning proper JSON responses and document persistence
- ✅ **COMPLETED: Frontend-Only API Integration - Direct Tachyon API Calls**
- Created frontend-only API service using api-config.json configuration
- Updated Document Analyzer and High Risk Goods to call Tachyon API directly from browser
- Implemented OAuth authentication in frontend with smart fallback system
- Removed Node.js backend API dependencies - all integrations now frontend-only
- Personalized responses for Sai Kumar Karnate maintained with direct API calls
- Workflow: Upload File → Direct Frontend API Call → Tachyon Response → Results Display
- Created comprehensive API & Documentation page showing all uploaded documents and their extraction data
- Added API endpoint /api/documents/all to fetch all documents with metadata and extraction results
- Integrated API & Documentation page into navigation with database icon and detailed document analysis display
- Enhanced Recent Documents with trash icon for clearing browser cache
- API page includes search, filtering, stats dashboard, and JSON export functionality
- Created comprehensive REST API service endpoints for external system integration:
  - GET /api/v1/documents - Returns all documents with complete extraction data in JSON/CSV format
  - GET /api/v1/documents/:id/extractions - Returns specific document extraction data
  - GET /api/v1/docs - API documentation and integration examples
- Enhanced API page with three tabs: API Overview, Endpoints & Testing, Data Preview
- Added live endpoint testing functionality with response preview and copy capabilities
- Included integration examples for cURL, JavaScript, and Python
- API responses include standardized format with status, timestamps, and structured metadata
- Support for CSV export format for external data processing systems
- Created comprehensive Windows Command Prompt compatibility with run-windows.cmd script
- Added cross-platform startup scripts and detailed troubleshooting documentation
- Fixed NODE_ENV environment variable issues for Windows users with multiple solution paths

## Windows Server Deployment Notes
- Use cross-env for environment variable compatibility
- May require elevated permissions or PowerShell execution policy changes
- Node.js and npm should be run with appropriate Windows Server permissions

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Build Tool**: Vite for fast development and optimized builds
- **Routing**: Wouter for lightweight client-side routing
- **UI Framework**: Tailwind CSS with shadcn/ui component library
- **State Management**: TanStack Query (React Query) for server state management
- **Styling**: CSS variables for theming with light/dark mode support

### Backend Architecture
- **Runtime**: Node.js with Express.js server
- **Language**: TypeScript with ES modules
- **Development**: tsx for TypeScript execution in development
- **API Pattern**: RESTful APIs with structured error handling
- **File Processing**: Multer for handling file uploads with validation

### Database & ORM
- **Database**: PostgreSQL (configured for Neon serverless)
- **ORM**: Drizzle ORM with migrations support
- **Schema**: Type-safe database operations with Zod validation
- **Session Management**: PostgreSQL-based session storage

## Key Components

### Chat System
- Session-based conversations with unique session IDs
- Real-time message exchange between Wells Fargo clients and AI assistant
- Message persistence with timestamps and role tracking
- Specialized prompts for Wells Fargo trade finance products and services

### Document Processing
- File upload support for PDF, DOC/DOCX, JPG/JPEG, PNG formats
- 10MB file size limit with client-side validation
- Document analysis using OpenAI GPT-4o model
- Compliance checking and summarization features

### AI Integration
- OpenAI GPT-4o for chat responses and document analysis
- Specialized system prompts for Wells Fargo trade finance domain knowledge
- Error handling and fallback responses for API failures
- Support for both text chat and document analysis workflows
- Wells Fargo branded user experience and messaging

### User Interface
- Responsive design with mobile-first approach
- Wells Fargo branded interface with signature red color scheme
- Clean, professional layout suitable for commercial banking use
- File drag-and-drop functionality
- Toast notifications for user feedback
- Loading states and error handling
- Wells Fargo logo and branding throughout the application

## Data Flow

### Chat Flow
1. User creates or accesses existing chat session
2. Frontend generates session ID and updates URL
3. Messages sent via POST to `/api/chat/:sessionId/messages`
4. Backend validates message data and stores in database
5. AI processes message and generates response
6. Response stored and returned to frontend
7. Frontend updates UI with new messages

### Document Analysis Flow
1. User uploads document through file input or drag-drop
2. Frontend validates file type and size
3. File sent via FormData to `/api/documents/:sessionId`
4. Backend processes file with Multer middleware
5. Document content extracted and analyzed by OpenAI
6. Analysis results and summary stored in database
7. Frontend displays analysis results and compliance status

## External Dependencies

### Core Dependencies
- **OpenAI**: GPT-4o model for AI responses and document analysis
- **Neon Database**: Serverless PostgreSQL hosting
- **Radix UI**: Accessible UI primitives for components
- **Tailwind CSS**: Utility-first CSS framework

### Development Tools
- **Replit Integration**: Development environment optimizations
- **ESBuild**: Fast bundling for production builds
- **PostCSS**: CSS processing with Tailwind and Autoprefixer

### File Processing
- **Multer**: Multipart form data handling for file uploads
- **File System**: Temporary file storage for processing

## Deployment Strategy

### Development
- Local development with `npm run dev`
- Hot module replacement via Vite
- TypeScript compilation checking with `npm run check`
- Database schema management with `npm run db:push`

### Production Build
- Frontend built with Vite to `dist/public`
- Backend bundled with ESBuild to `dist/index.js`
- Static file serving integrated with Express
- Environment variables for database and API keys

### Environment Configuration
- DATABASE_URL for PostgreSQL connection
- OPENAI_API_KEY for AI service integration
- Node.js production mode optimization
- Shared schema between frontend and backend

### Database Management
- Drizzle migrations stored in `./migrations`
- Schema definitions in `./shared/schema.ts`
- PostgreSQL dialect with connection pooling
- Session persistence with connect-pg-simple