# Troubleshooting Guide - Wells Fargo Trade Finance AI Assistant

## Windows Command Prompt Issues

### Problem: `'NODE_ENV' is not recognized as an internal or external command`

**Solution Options (try in order):**

1. **Use PowerShell instead of Command Prompt**
   ```powershell
   powershell
   npm run dev
   ```

2. **Use the Windows batch file**
   ```cmd
   start.bat
   ```
   Or double-click `start.bat` in File Explorer

3. **Use the universal Node.js script**
   ```cmd
   node start.js
   ```

4. **Use the Windows-specific dev script**
   ```cmd
   dev.cmd
   ```

5. **Manual setup for Command Prompt**
   ```cmd
   set NODE_ENV=development
   npx tsx server/index.ts
   ```

## Common Issues and Solutions

### Port Already in Use
**Error**: `EADDRINUSE: address already in use :::5000`

**Solution**:
```bash
# Kill process on port 5000
npx kill-port 5000
# Then restart
npm run dev
```

### Missing Dependencies
**Error**: Module not found errors

**Solution**:
```bash
# Clean reinstall
rm -rf node_modules package-lock.json
npm install
npm run dev
```

### TypeScript Errors
**Error**: TypeScript compilation errors

**Solution**:
```bash
# Check types
npm run check
# If types are correct, restart
npm run dev
```

### API Connection Issues
**Error**: API calls failing

**Solutions**:
1. Check if OPENAI_API_KEY is set in `.env` file
2. Verify network connectivity
3. Check API endpoints: http://localhost:5000/api/v1/docs

### VS Code Issues
**Problem**: Can't run in VS Code

**Solutions**:
1. Use integrated terminal: `Ctrl+`` (backtick)
2. Use Command Palette: `Ctrl+Shift+P` → "Tasks: Run Task" → "Start Development Server"
3. Use Debug: Press `F5` with launch configuration

## Platform-Specific Commands

### Windows Command Prompt
```cmd
start.bat
# OR
node start.js
# OR
dev.cmd
```

### Windows PowerShell
```powershell
npm run dev
# OR
./start.sh
```

### macOS/Linux Terminal
```bash
npm run dev
# OR
./start.sh
```

### Git Bash (Windows)
```bash
npm run dev
# OR
./start.sh
```

## Environment Variables

Create `.env` file in project root:
```
NODE_ENV=development
OPENAI_API_KEY=your_api_key_here
DATABASE_URL=your_database_url_here
```

## Verification Steps

1. **Check Node.js version** (should be 18+):
   ```bash
   node --version
   ```

2. **Check npm version**:
   ```bash
   npm --version
   ```

3. **Verify application is running**:
   - Open browser: http://localhost:5000
   - Check API docs: http://localhost:5000/api/v1/docs

4. **Check console logs**:
   - Browser: Press F12 → Console tab
   - Terminal: Look for "serving on port 5000"

## Getting Help

If none of these solutions work:

1. Check the browser console for JavaScript errors
2. Check the terminal/command prompt for server errors
3. Verify all files are present in the project directory
4. Ensure you're in the correct directory when running commands
5. Try restarting your computer if all else fails

## Quick Success Check

Run this sequence to verify everything works:
```bash
# 1. Check Node.js
node --version

# 2. Install dependencies
npm install

# 3. Start application
npm run dev

# 4. Open browser to http://localhost:5000
```

If you see "serving on port 5000" in the terminal and the webpage loads, you're all set!