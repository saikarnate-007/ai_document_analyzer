# Trade Finance AI Assistant - Production Deployment Guide

## Quick Deployment Options

### 1. Replit Deployments (Recommended)
```bash
# Your application is already configured for Replit deployment
# Simply click the "Deploy" button in Replit interface
```

### 2. Production Build Commands
```bash
# Build the application for production
npm run build

# Start production server
npm start
```

### 3. Manual Production Setup
```bash
# Install dependencies
npm install

# Build frontend and backend
npm run build

# Set production environment
export NODE_ENV=production

# Start the server
node dist/index.js
```

## Environment Variables Required

Set these environment variables for production:

```bash
NODE_ENV=production
OPENAI_API_KEY=your_openai_key_here
DATABASE_URL=your_postgresql_connection_string
PORT=5000
```

## Production Configuration

### Database Setup
- Configure PostgreSQL database connection
- Run migrations: `npm run db:push`
- Ensure database is accessible from production server

### API Configuration
- Update `server/config/api-config.json` with production endpoints
- Configure OAuth credentials for Tachyon API
- Set proper CORS settings for production domain

### Security Checklist
- [ ] HTTPS enabled
- [ ] Environment variables secured
- [ ] Database connection encrypted
- [ ] API rate limiting configured
- [ ] CORS properly configured for production domain

## Docker Deployment (Optional)

```dockerfile
FROM node:18-alpine

WORKDIR /app
COPY package*.json ./
RUN npm ci --only=production

COPY . .
RUN npm run build

EXPOSE 5000
CMD ["npm", "start"]
```

## Replit Deployment Steps

1. **Click Deploy Button** in Replit interface
2. **Configure Domain** (optional custom domain)
3. **Set Environment Variables** in deployment settings
4. **Monitor Deployment** logs for any issues

## Health Check Endpoint

Your application includes health checks at:
- `GET /api/health` - Application health status
- `GET /api/config` - Configuration verification

## Monitoring

Monitor these endpoints in production:
- Application logs via Replit console
- API response times
- Database connection status
- File upload functionality

## Support

For deployment issues:
- Check Replit deployment logs
- Verify environment variables
- Test API endpoints after deployment
- Monitor database connectivity