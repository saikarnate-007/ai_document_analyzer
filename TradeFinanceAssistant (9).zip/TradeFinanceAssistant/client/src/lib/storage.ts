import type { ChatMessage, Document } from "@shared/schema";

export interface UserSettings {
  username: string;
  email?: string;
  theme?: 'light' | 'dark';
}

export interface PersonalNote {
  id: string;
  title: string;
  content: string;
  createdAt: Date;
  isCompleted?: boolean;
}

export interface ChatSession {
  id: string;
  title: string;
  lastActivity: Date;
  messageCount: number;
}

// Local storage service for browser-based data persistence
export class LocalStorageService {
  private static instance: LocalStorageService;
  
  private constructor() {}
  
  static getInstance(): LocalStorageService {
    if (!LocalStorageService.instance) {
      LocalStorageService.instance = new LocalStorageService();
    }
    return LocalStorageService.instance;
  }

  // Chat messages storage
  getChatMessages(sessionId: string): ChatMessage[] {
    try {
      const stored = localStorage.getItem(`chat_messages_${sessionId}`);
      return stored ? JSON.parse(stored) : [];
    } catch {
      return [];
    }
  }

  saveChatMessage(sessionId: string, message: ChatMessage): void {
    try {
      const messages = this.getChatMessages(sessionId);
      messages.push(message);
      localStorage.setItem(`chat_messages_${sessionId}`, JSON.stringify(messages));
    } catch (error) {
      console.error('Failed to save chat message:', error);
    }
  }

  saveChatMessages(sessionId: string, messages: ChatMessage[]): void {
    try {
      localStorage.setItem(`chat_messages_${sessionId}`, JSON.stringify(messages));
    } catch (error) {
      console.error('Failed to save chat messages:', error);
    }
  }

  // Documents storage
  getDocuments(sessionId: string): Document[] {
    try {
      const stored = localStorage.getItem(`documents_${sessionId}`);
      return stored ? JSON.parse(stored) : [];
    } catch {
      return [];
    }
  }

  saveDocument(sessionId: string, document: Document): void {
    try {
      const documents = this.getDocuments(sessionId);
      const existingIndex = documents.findIndex(d => d.id === document.id);
      
      if (existingIndex >= 0) {
        documents[existingIndex] = document;
      } else {
        documents.push(document);
      }
      
      localStorage.setItem(`documents_${sessionId}`, JSON.stringify(documents));
      
      // Also save to recent documents cache
      this.saveToRecentDocuments(document);
    } catch (error) {
      console.error('Failed to save document:', error);
    }
  }

  // Recent documents management in browser cache
  getRecentDocuments(): Document[] {
    try {
      const stored = localStorage.getItem('recent_documents');
      return stored ? JSON.parse(stored) : [];
    } catch {
      return [];
    }
  }

  saveToRecentDocuments(document: Document): void {
    try {
      let recentDocs = this.getRecentDocuments();
      console.log("Current recent docs before save:", recentDocs.length);
      
      // Remove if already exists to avoid duplicates
      recentDocs = recentDocs.filter(d => d.id !== document.id);
      
      // Add to front
      recentDocs.unshift(document);
      
      // Keep only last 5
      recentDocs = recentDocs.slice(0, 5);
      
      localStorage.setItem('recent_documents', JSON.stringify(recentDocs));
      console.log("Saved to recent documents. New count:", recentDocs.length, "Document:", document.originalName);
    } catch (error) {
      console.error('Failed to save to recent documents:', error);
    }
  }

  updateDocumentWithExtraction(documentId: number, extractedFields: any[], scanLabels: string[]): void {
    try {
      // Update in recent documents
      const recentDocs = this.getRecentDocuments();
      const docIndex = recentDocs.findIndex(d => d.id === documentId);
      
      if (docIndex >= 0) {
        recentDocs[docIndex] = {
          ...recentDocs[docIndex],
          extractedFields,
          scanLabels,
          extractedAt: new Date().toISOString()
        };
        localStorage.setItem('recent_documents', JSON.stringify(recentDocs));
        console.log("Updated document with extraction results:", recentDocs[docIndex].originalName);
      } else {
        console.log("Document not found in recent cache for extraction update, ID:", documentId);
      }
    } catch (error) {
      console.error('Failed to update document with extraction:', error);
    }
  }

  // Session management
  getAllSessions(): string[] {
    try {
      const stored = localStorage.getItem('chat_sessions');
      return stored ? JSON.parse(stored) : [];
    } catch {
      return [];
    }
  }

  addSession(sessionId: string): void {
    try {
      const sessions = this.getAllSessions();
      if (!sessions.includes(sessionId)) {
        sessions.unshift(sessionId); // Add to beginning
        localStorage.setItem('chat_sessions', JSON.stringify(sessions.slice(0, 10))); // Keep only last 10 sessions
      }
    } catch (error) {
      console.error('Failed to save session:', error);
    }
  }

  // Clear data
  clearSession(sessionId: string): void {
    try {
      localStorage.removeItem(`chat_messages_${sessionId}`);
      localStorage.removeItem(`documents_${sessionId}`);
      
      const sessions = this.getAllSessions();
      const filteredSessions = sessions.filter(s => s !== sessionId);
      localStorage.setItem('chat_sessions', JSON.stringify(filteredSessions));
    } catch (error) {
      console.error('Failed to clear session:', error);
    }
  }

  clearAllData(): void {
    try {
      const keys = Object.keys(localStorage);
      keys.forEach(key => {
        if (key.startsWith('chat_messages_') || key.startsWith('documents_') || key === 'chat_sessions') {
          localStorage.removeItem(key);
        }
      });
    } catch (error) {
      console.error('Failed to clear all data:', error);
    }
  }

  // User settings
  getUserSettings(): UserSettings {
    try {
      const stored = localStorage.getItem('user_settings');
      return stored ? JSON.parse(stored) : { username: 'Trade Finance User' };
    } catch {
      return { username: 'Trade Finance User' };
    }
  }

  saveUserSettings(settings: UserSettings): void {
    try {
      localStorage.setItem('user_settings', JSON.stringify(settings));
    } catch (error) {
      console.error('Failed to save user settings:', error);
    }
  }

  // Personal notes
  getPersonalNotes(): PersonalNote[] {
    try {
      const stored = localStorage.getItem('personal_notes');
      return stored ? JSON.parse(stored) : [];
    } catch {
      return [];
    }
  }

  savePersonalNote(note: PersonalNote): void {
    try {
      const notes = this.getPersonalNotes();
      const existingIndex = notes.findIndex(n => n.id === note.id);
      
      if (existingIndex >= 0) {
        notes[existingIndex] = note;
      } else {
        notes.push(note);
      }
      
      localStorage.setItem('personal_notes', JSON.stringify(notes));
    } catch (error) {
      console.error('Failed to save personal note:', error);
    }
  }

  deletePersonalNote(noteId: string): void {
    try {
      const notes = this.getPersonalNotes();
      const filteredNotes = notes.filter(n => n.id !== noteId);
      localStorage.setItem('personal_notes', JSON.stringify(filteredNotes));
    } catch (error) {
      console.error('Failed to delete personal note:', error);
    }
  }

  // Chat sessions with enhanced info
  getChatSessions(): ChatSession[] {
    try {
      const stored = localStorage.getItem('chat_sessions_detailed');
      return stored ? JSON.parse(stored) : [];
    } catch {
      return [];
    }
  }

  updateChatSession(sessionId: string, title?: string): void {
    try {
      const sessions = this.getChatSessions();
      const messages = this.getChatMessages(sessionId);
      
      const existingIndex = sessions.findIndex(s => s.id === sessionId);
      const sessionData: ChatSession = {
        id: sessionId,
        title: title || `Chat ${sessionId.substring(0, 8)}`,
        lastActivity: new Date(),
        messageCount: messages.length
      };
      
      if (existingIndex >= 0) {
        sessions[existingIndex] = sessionData;
      } else {
        sessions.unshift(sessionData);
      }
      
      // Keep only last 20 sessions
      localStorage.setItem('chat_sessions_detailed', JSON.stringify(sessions.slice(0, 20)));
    } catch (error) {
      console.error('Failed to update chat session:', error);
    }
  }

  // Get all documents from all sessions (for recent documents)
  getAllDocuments(): Document[] {
    try {
      const allDocs: Document[] = [];
      const sessions = this.getAllSessions();
      
      sessions.forEach(sessionId => {
        const docs = this.getDocuments(sessionId);
        allDocs.push(...docs);
      });
      
      return allDocs.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    } catch {
      return [];
    }
  }
}

export const storage = LocalStorageService.getInstance();