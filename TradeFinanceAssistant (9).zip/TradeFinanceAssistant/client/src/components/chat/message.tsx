import type { ChatMessage } from "@shared/schema";

interface MessageProps {
  message: ChatMessage;
}

export function Message({ message }: MessageProps) {
  const isUser = message.role === "user";
  const formatTime = (date: Date) => {
    return new Date(date).toLocaleTimeString("en-US", {
      hour: "numeric",
      minute: "2-digit",
      hour12: true,
    });
  };

  if (isUser) {
    return (
      <>
        <div className="flex items-start space-x-3 justify-end">
          <div className="flex-1 flex justify-end">
            <div className="bg-primary text-white rounded-lg shadow-sm p-4 max-w-2xl">
              <p className="whitespace-pre-wrap">{message.content}</p>
            </div>
          </div>
          <div className="w-8 h-8 bg-slate-300 rounded-full flex items-center justify-center flex-shrink-0">
            <i className="fas fa-user text-slate-600 text-sm"></i>
          </div>
        </div>
        <div className="flex justify-end">
          <span className="text-xs text-slate-500">
            You • {formatTime(new Date(message.createdAt))}
          </span>
        </div>
      </>
    );
  }

  return (
    <div className="flex items-start space-x-3">
      <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center flex-shrink-0">
        <i className="fas fa-robot text-white text-sm"></i>
      </div>
      <div className="flex-1">
        <div className="bg-white rounded-lg shadow-sm border border-slate-200 p-4 max-w-2xl">
          <div className="prose prose-sm max-w-none">
            <p className="text-slate-700 whitespace-pre-wrap">{message.content}</p>
          </div>
        </div>
        <span className="text-xs text-slate-500 mt-1 block">
          AI Assistant • {formatTime(new Date(message.createdAt))}
        </span>
      </div>
    </div>
  );
}
