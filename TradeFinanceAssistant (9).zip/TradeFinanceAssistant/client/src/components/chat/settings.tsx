import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient } from "@/lib/queryClient";
import { storage } from "@/lib/storage";
import { useToast } from "@/hooks/use-toast";
import type { UserSettings } from "@/lib/storage";

export function Settings() {
  const { toast } = useToast();
  
  const { data: settings = { username: 'Trade Finance User' } } = useQuery<UserSettings>({
    queryKey: ["user_settings"],
    queryFn: () => storage.getUserSettings(),
  });

  const [formData, setFormData] = useState({
    username: settings.username,
    email: settings.email || '',
    theme: settings.theme || 'light'
  });

  const saveSettingsMutation = useMutation({
    mutationFn: async (newSettings: UserSettings) => {
      storage.saveUserSettings(newSettings);
      return newSettings;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["user_settings"] });
      toast({
        title: "Settings Saved",
        description: "Your settings have been updated successfully.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to save settings. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleSave = () => {
    saveSettingsMutation.mutate({
      username: formData.username,
      email: formData.email,
      theme: formData.theme as 'light' | 'dark'
    });
  };

  const handleClearAllData = () => {
    if (confirm('Are you sure you want to clear all data? This action cannot be undone.')) {
      storage.clearAllData();
      toast({
        title: "Data Cleared",
        description: "All chat history and documents have been cleared.",
      });
      window.location.reload();
    }
  };

  return (
    <div className="flex-1 overflow-y-auto p-4">
      <div className="space-y-6">
        {/* User Profile */}
        <div className="bg-white rounded-lg border border-slate-200 p-4">
          <h3 className="font-semibold text-slate-900 mb-4">User Profile</h3>
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Username</label>
              <input
                type="text"
                value={formData.username}
                onChange={(e) => setFormData({...formData, username: e.target.value})}
                className="w-full p-2 border border-slate-300 rounded-md focus:ring-2 focus:ring-primary focus:border-transparent"
                placeholder="Enter your username"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Email (Optional)</label>
              <input
                type="email"
                value={formData.email}
                onChange={(e) => setFormData({...formData, email: e.target.value})}
                className="w-full p-2 border border-slate-300 rounded-md focus:ring-2 focus:ring-primary focus:border-transparent"
                placeholder="Enter your email"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Theme</label>
              <select
                value={formData.theme}
                onChange={(e) => setFormData({...formData, theme: e.target.value})}
                className="w-full p-2 border border-slate-300 rounded-md focus:ring-2 focus:ring-primary focus:border-transparent"
              >
                <option value="light">Light</option>
                <option value="dark">Dark</option>
              </select>
            </div>
            <button
              onClick={handleSave}
              disabled={saveSettingsMutation.isPending}
              className="w-full bg-primary text-white py-2 px-4 rounded-md hover:bg-blue-700 transition-colors disabled:opacity-50"
            >
              {saveSettingsMutation.isPending ? 'Saving...' : 'Save Settings'}
            </button>
          </div>
        </div>

        {/* Data Management */}
        <div className="bg-white rounded-lg border border-slate-200 p-4">
          <h3 className="font-semibold text-slate-900 mb-4">Data Management</h3>
          <div className="space-y-4">
            <div className="flex items-center justify-between p-3 bg-slate-50 rounded-md">
              <div>
                <h4 className="font-medium text-slate-900">Clear All Data</h4>
                <p className="text-sm text-slate-500">Remove all chat history, documents, and settings</p>
              </div>
              <button
                onClick={handleClearAllData}
                className="px-4 py-2 bg-red-500 text-white rounded-md hover:bg-red-600 transition-colors"
              >
                Clear All
              </button>
            </div>
          </div>
        </div>

        {/* Storage Info */}
        <div className="bg-white rounded-lg border border-slate-200 p-4">
          <h3 className="font-semibold text-slate-900 mb-4">Storage Information</h3>
          <div className="space-y-2 text-sm text-slate-600">
            <p>• All data is stored locally in your browser</p>
            <p>• Data persists between sessions</p>
            <p>• Clearing browser data will remove all information</p>
            <p>• No data is sent to external servers</p>
          </div>
        </div>
      </div>
    </div>
  );
}