import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { AlertTriangle, Plus, X, Eye, Search, Upload } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { FileUpload } from '@/components/ui/file-upload';
import type { Document } from '@shared/schema';

interface HighRiskItem {
  id: string;
  category: string;
  description: string;
  riskLevel: 'low' | 'medium' | 'high' | 'critical';
  keywords: string[];
  detectedIn?: string;
  confidence?: number;
}

interface RedFlagEntry {
  id: string;
  name: string;
  description: string;
  keywords: string[];
  category: string;
  addedDate: Date;
}

interface AnalysisResult {
  detectedItems: HighRiskItem[];
  totalRiskScore: number;
  recommendations: string[];
  complianceFlags: string[];
}

export function HighRiskGoods() {
  const sessionId = "default"; // Use a default session ID
  const [selectedDocument, setSelectedDocument] = useState<Document | null>(null);
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);
  const [analysisResult, setAnalysisResult] = useState<AnalysisResult | null>(null);
  const [showRedFlagForm, setShowRedFlagForm] = useState(false);
  const [newRedFlag, setNewRedFlag] = useState({
    name: '',
    description: '',
    keywords: '',
    category: ''
  });
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch existing red flag entries
  const { data: redFlagEntries = [], isLoading: loadingRedFlags } = useQuery({
    queryKey: ['/api/red-flags'],
    enabled: true
  });

  // Remove duplicate query since we're using local state for analysis results

  // Upload document mutation
  const analyzeRiskMutation = useMutation({
    mutationFn: async ({ file, prompt }: { file: File; prompt: string }) => {
      const { tachyonApi } = await import('../../services/tachyonApi');
      return await tachyonApi.analyzeHighRisk(file, prompt);
    },
    onSuccess: (data, { file }) => {
      if (data.status === 'success') {
        const document = {
          id: Date.now(),
          sessionId: sessionId,
          filename: file.name,
          originalName: file.name,
          fileType: file.type,
          fileSize: file.size,
          createdAt: new Date(),
          analysisResult: data.data,
          summary: data.data.analysis,
        };
        
        setSelectedDocument(document);
        setAnalysisResult(data.data);
        setUploadedFile(null);
        
        toast({
          title: "Analysis completed",
          description: `${file.name} has been analyzed for high-risk items.`,
        });
      } else {
        throw new Error(data.error || 'Analysis failed');
      }
    },
    onError: (error) => {
      toast({
        title: "Analysis failed",
        description: error.message || "Failed to analyze document for high-risk items. Please try again.",
        variant: "destructive",
      });
    },
  });



  // Add red flag entry mutation
  const addRedFlagMutation = useMutation({
    mutationFn: async (data: Omit<RedFlagEntry, 'id' | 'addedDate'>) => {
      return apiRequest('/api/red-flags', {
        method: 'POST',
        body: JSON.stringify({
          ...data,
          keywords: data.keywords.split(',').map(k => k.trim()).filter(k => k)
        }),
        headers: { 'Content-Type': 'application/json' }
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/red-flags'] });
      setShowRedFlagForm(false);
      setNewRedFlag({ name: '', description: '', keywords: '', category: '' });
      toast({
        title: "Red Flag Added",
        description: "New red flag entry has been added successfully."
      });
    },
    onError: (error) => {
      toast({
        title: "Failed to Add Red Flag",
        description: error instanceof Error ? error.message : "Failed to add red flag entry",
        variant: "destructive"
      });
    }
  });

  // Delete red flag mutation
  const deleteRedFlagMutation = useMutation({
    mutationFn: async (id: string) => {
      return apiRequest(`/api/red-flags/${id}`, { method: 'DELETE' });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/red-flags'] });
      toast({
        title: "Red Flag Removed",
        description: "Red flag entry has been removed."
      });
    }
  });

  const handleFileSelect = (files: File[]) => {
    if (files.length > 0) {
      const file = files[0];
      setUploadedFile(file);
      // Don't auto-analyze - wait for user to click analyze button
      toast({
        title: "Document uploaded",
        description: `${file.name} is ready for high-risk analysis. Click Analyze Risk.`,
      });
    }
  };

  const handleAnalyze = () => {
    if (!uploadedFile) {
      toast({
        title: "No Document",
        description: "Please upload a document to analyze for high risk goods.",
        variant: "destructive"
      });
      return;
    }
    
    const prompt = "Hello Sai Kumar Karnate, analyze this document for high-risk goods and dual-use items. Identify any potentially restricted items, compliance issues, and provide a risk assessment.";
    analyzeRiskMutation.mutate({
      file: uploadedFile,
      prompt: prompt
    });
  };

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return "0 Bytes";
    const k = 1024;
    const sizes = ["Bytes", "KB", "MB", "GB"];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + " " + sizes[i];
  };

  const handleAddRedFlag = () => {
    if (!newRedFlag.name || !newRedFlag.description) {
      toast({
        title: "Missing Information",
        description: "Please fill in name and description for the red flag entry.",
        variant: "destructive"
      });
      return;
    }
    addRedFlagMutation.mutate(newRedFlag);
  };

  const getRiskBadgeVariant = (level: string) => {
    switch (level) {
      case 'critical': return 'destructive';
      case 'high': return 'destructive';
      case 'medium': return 'secondary';
      case 'low': return 'outline';
      default: return 'outline';
    }
  };

  return (
    <div className="flex-1 overflow-y-auto p-6">
      <div className="space-y-6">


      {/* Document Upload & Analysis */}
      <Card>
        <CardHeader>
          <CardTitle>Document Analysis</CardTitle>
          <CardDescription>
            Upload trade finance documents (Letters of Credit, Commercial Invoices, Bills of Lading) to analyze for high risk goods and dual use items
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center space-x-4">
            <div className="flex-1">
              <FileUpload
                onFileSelect={handleFileSelect}
                accept=".pdf,.doc,.docx,.jpg,.jpeg,.png"
                maxSize={10 * 1024 * 1024} // 10MB
              >
                <div className="border-2 border-dashed border-slate-300 rounded-lg p-6 text-center hover:border-red-400 transition-colors">
                  {uploadedFile || selectedDocument ? (
                    <div className="flex items-center justify-center space-x-2">
                      <span className="text-2xl">📄</span>
                      <div>
                        <p className="text-sm font-medium text-slate-900">
                          {selectedDocument ? selectedDocument.originalName : uploadedFile?.name}
                        </p>
                        <p className="text-xs text-slate-500">
                          {selectedDocument ? formatFileSize(selectedDocument.fileSize) : formatFileSize(uploadedFile?.size || 0)}
                        </p>
                      </div>
                    </div>
                  ) : (
                    <div>
                      <Upload className="h-8 w-8 mx-auto mb-2 text-slate-400" />
                      <p className="text-slate-500">Click to upload or drag and drop</p>
                      <p className="text-xs text-slate-400 mt-1">PDF, DOC, DOCX, JPG, PNG (max 10MB)</p>
                    </div>
                  )}
                </div>
              </FileUpload>
            </div>
            
            <Button 
              onClick={handleAnalyze}
              disabled={!uploadedFile || analyzeRiskMutation.isPending}
              className="bg-red-600 hover:bg-red-700"
            >
              <Search className="h-4 w-4 mr-2" />
              {analyzeRiskMutation.isPending ? 'Analyzing...' : 'Analyze Risk'}
            </Button>
          </div>

          {analyzeRiskMutation.isPending && (
            <div className="flex items-center space-x-2 text-blue-600">
              <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-blue-600"></div>
              <span>Analyzing document...</span>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Analysis Results */}
      {analysisResult && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <AlertTriangle className="h-5 w-5" />
              Risk Analysis Results
              <Badge variant={(analysisResult.totalRiskScore || 0) > 80 ? 'destructive' : (analysisResult.totalRiskScore || 0) > 50 ? 'secondary' : 'outline'}>
                Risk Score: {analysisResult.totalRiskScore || 0}%
              </Badge>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Detected High Risk Items */}
            {analysisResult.detectedItems && analysisResult.detectedItems.length > 0 ? (
              <div className="space-y-3">
                <h4 className="font-medium">Detected High Risk Items:</h4>
                <div className="grid gap-3">
                  {analysisResult.detectedItems.map((item, index) => (
                    <div key={index} className="border rounded-lg p-3 space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="font-medium">{item.category || 'Unknown'}</span>
                        <Badge variant={getRiskBadgeVariant(item.riskLevel || 'low')}>
                          {(item.riskLevel || 'unknown').toUpperCase()}
                        </Badge>
                      </div>
                      <p className="text-sm text-gray-600">{item.description || 'No description available'}</p>
                      {item.confidence && (
                        <p className="text-xs text-gray-500">Confidence: {item.confidence}%</p>
                      )}
                      <div className="flex flex-wrap gap-1">
                        {(item.keywords || []).map((keyword, i) => (
                          <Badge key={i} variant="outline" className="text-xs">
                            {keyword}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ) : (
              <div className="text-center py-4 text-gray-500">
                No high risk items detected in the provided data.
              </div>
            )}

            {/* Compliance Flags */}
            {analysisResult.complianceFlags && analysisResult.complianceFlags.length > 0 && (
              <div className="space-y-2">
                <h4 className="font-medium text-red-600">Compliance Flags:</h4>
                <ul className="list-disc list-inside space-y-1">
                  {analysisResult.complianceFlags.map((flag, index) => (
                    <li key={index} className="text-sm text-red-600">
                      {typeof flag === 'string' ? flag : flag.message || JSON.stringify(flag)}
                    </li>
                  ))}
                </ul>
              </div>
            )}

            {/* Recommendations */}
            {analysisResult.recommendations && analysisResult.recommendations.length > 0 && (
              <div className="space-y-2">
                <h4 className="font-medium">Recommendations:</h4>
                <ul className="list-disc list-inside space-y-1">
                  {analysisResult.recommendations.map((rec, index) => (
                    <li key={index} className="text-sm">
                      {typeof rec === 'string' ? rec : rec.message || JSON.stringify(rec)}
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </CardContent>
        </Card>
      )}


      </div>
    </div>
  );
}