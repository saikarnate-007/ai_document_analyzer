import { useState, useRef, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Message } from "./message";
import { storage } from "@/lib/storage";
import type { ChatMessage } from "@shared/schema";
import { nanoid } from "nanoid";

interface ChatInterfaceProps {
  sessionId: string;
  onDocumentUploaded: () => void;
  selectedMessage?: string;
  onMessageUsed?: () => void;
}

export function ChatInterface({ sessionId, onDocumentUploaded, selectedMessage, onMessageUsed }: ChatInterfaceProps) {
  const [inputMessage, setInputMessage] = useState("");
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();

  // Handle selected message from chat history
  useEffect(() => {
    if (selectedMessage && selectedMessage !== inputMessage) {
      setInputMessage(selectedMessage);
      if (onMessageUsed) {
        onMessageUsed();
      }
    }
  }, [selectedMessage, inputMessage, onMessageUsed]);

  // Use local storage instead of API for messages
  const { data: messages = [], isLoading } = useQuery<ChatMessage[]>({
    queryKey: ["chat_messages", sessionId],
    queryFn: () => storage.getChatMessages(sessionId),
    enabled: !!sessionId,
  });

  const sendMessageMutation = useMutation({
    mutationFn: async (content: string) => {
      // Create user message locally
      const userMessage: ChatMessage = {
        id: parseInt(nanoid(), 36),
        sessionId,
        role: "user",
        content,
        createdAt: new Date(),
      };
      
      // Save user message to local storage
      storage.saveChatMessage(sessionId, userMessage);
      storage.addSession(sessionId);
      storage.updateChatSession(sessionId);
      
      // Call Tachyon API directly from frontend
      const { tachyonApi } = await import('../../services/tachyonApi');
      const response = await tachyonApi.chatMessage(content);
      
      if (response.status === 'success') {
        // Save AI response to local storage
        const assistantMessage: ChatMessage = {
          id: parseInt(nanoid(), 36),
          sessionId,
          role: "assistant",
          content: response.data.response,
          createdAt: new Date(),
        };
        storage.saveChatMessage(sessionId, assistantMessage);
        return response;
      } else {
        throw new Error(response.error || 'Chat failed');
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["chat_messages", sessionId] });
      setInputMessage("");
    },
    onError: (error) => {
      // Still invalidate queries to show the saved user message
      queryClient.invalidateQueries({ queryKey: ["chat_messages", sessionId] });
      setInputMessage("");
      
      toast({
        title: "Connection Issue",
        description: "Using offline mode. Your message was saved locally.",
        variant: "default",
      });
    },
  });

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleSendMessage = () => {
    if (inputMessage.trim() && !sendMessageMutation.isPending) {
      sendMessageMutation.mutate(inputMessage.trim());
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const insertQuickAction = (text: string) => {
    setInputMessage(text);
  };

  const quickActions = [
    "Wells Fargo LC rates",
    "Trade finance solutions", 
    "Check UCP 600 compliance"
  ];

  if (isLoading) {
    return (
      <div className="flex-1 flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-slate-400"></div>
      </div>
    );
  }

  return (
    <div className="flex-1 flex flex-col h-full">
      {/* Chat Messages */}
      <div className="flex-1 overflow-y-auto p-6 space-y-4 min-h-0">
        {messages.length === 0 && (
          <div className="flex items-start space-x-3">
            <div className="w-8 h-8 bg-red-600 rounded-full flex items-center justify-center flex-shrink-0">
              <i className="fas fa-robot text-white text-sm"></i>
            </div>
            <div className="flex-1">
              <div className="bg-white rounded-lg shadow-sm border border-slate-200 p-4 max-w-2xl">
                <p className="text-slate-700">Welcome to Trade Finance AI Assistant! I'm your dedicated Wells Fargo AI assistant for commercial banking trade services. I can help you with:</p>
                <ul className="mt-2 space-y-1 text-sm text-slate-600">
                  <li>• Letters of Credit issuance and compliance validation</li>
                  <li>• Trade document analysis and processing</li>
                  <li>• International trade financing solutions</li>
                  <li>• Supply chain finance and working capital optimization</li>
                  <li>• Regulatory compliance and risk assessment</li>
                </ul>
                <p className="mt-3 text-slate-700">How can Wells Fargo assist with your trade finance needs today?</p>
              </div>
              <span className="text-xs text-slate-500 mt-1 block">AI Assistant • Just now</span>
            </div>
          </div>
        )}

        {messages.map((message) => (
          <Message key={message.id} message={message} />
        ))}

        {sendMessageMutation.isPending && (
          <div className="flex items-start space-x-3">
            <div className="w-8 h-8 bg-red-600 rounded-full flex items-center justify-center flex-shrink-0">
              <i className="fas fa-robot text-white text-sm"></i>
            </div>
            <div className="bg-white rounded-lg shadow-sm border border-slate-200 p-4">
              <div className="flex space-x-1">
                <div className="w-2 h-2 bg-slate-400 rounded-full animate-bounce"></div>
                <div className="w-2 h-2 bg-slate-400 rounded-full animate-bounce" style={{ animationDelay: "0.1s" }}></div>
                <div className="w-2 h-2 bg-slate-400 rounded-full animate-bounce" style={{ animationDelay: "0.2s" }}></div>
              </div>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Chat Input */}
      <div className="border-t border-slate-200 p-4 bg-white flex-shrink-0">
        <div className="flex items-end space-x-3">
          <div className="flex-1">
            <div className="flex items-center space-x-2 p-3 border border-slate-300 rounded-lg focus-within:border-primary focus-within:ring-1 focus-within:ring-primary">
              <input
                type="text"
                value={inputMessage}
                onChange={(e) => setInputMessage(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder="Ask about trade finance solutions, LC processing, or compliance..."
                className="flex-1 bg-transparent outline-none text-slate-700 placeholder-slate-500"
                disabled={sendMessageMutation.isPending}
              />
            </div>
          </div>
          <button
            onClick={handleSendMessage}
            disabled={!inputMessage.trim() || sendMessageMutation.isPending}
            className="px-6 py-3 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <i className="fas fa-paper-plane"></i>
          </button>
        </div>

        {/* Quick Actions */}
        <div className="flex items-center justify-between mt-3">
          <div className="flex items-center space-x-2">
            <span className="text-xs text-slate-500">Quick actions:</span>
            {quickActions.map((action) => (
              <button
                key={action}
                onClick={() => insertQuickAction(action)}
                className="px-3 py-1 bg-slate-100 text-slate-700 rounded-full text-xs hover:bg-slate-200 transition-colors"
              >
                {action}
              </button>
            ))}
          </div>
          <div className="flex items-center space-x-1 text-xs text-slate-500">
            <i className="fas fa-envelope"></i>
            <span>For queries:</span>
            <a 
              href="mailto:sai.karnate@gmail.com" 
              className="text-blue-600 hover:text-blue-800 hover:underline"
            >
              sai.karnate@gmail.com
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}