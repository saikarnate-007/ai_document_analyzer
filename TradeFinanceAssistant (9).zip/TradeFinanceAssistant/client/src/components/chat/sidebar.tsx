import { useState, useEffect } from "react";
import { Trash2 } from "lucide-react";
import { storage } from "@/lib/storage";
import type { Document } from "@shared/schema";

interface SidebarProps {
  sessionId: string;
  activeSection: string;
  onSectionChange: (section: string) => void;
  onDocumentSelect?: (document: Document) => void;
}

export function Sidebar({ sessionId, activeSection, onSectionChange, onDocumentSelect }: SidebarProps) {
  // Use browser cache for recent documents
  const [recentDocuments, setRecentDocuments] = useState<Document[]>([]);

  useEffect(() => {
    const loadRecentDocs = () => {
      const docs = storage.getRecentDocuments();
      console.log("Loading recent documents from cache:", docs);
      setRecentDocuments(docs);
    };
    
    loadRecentDocs();
    
    // Refresh every 2 seconds to catch new extractions
    const interval = setInterval(loadRecentDocs, 2000);
    return () => clearInterval(interval);
  }, []);

  // Also log when recentDocuments state changes
  useEffect(() => {
    console.log("Recent documents state updated:", recentDocuments.length, recentDocuments);
  }, [recentDocuments]);

  const formatRelativeTime = (date: Date): string => {
    const now = new Date();
    const diffInMinutes = Math.floor((now.getTime() - new Date(date).getTime()) / (1000 * 60));
    
    if (diffInMinutes < 1) return "Just now";
    if (diffInMinutes < 60) return `${diffInMinutes} min ago`;
    
    const diffInHours = Math.floor(diffInMinutes / 60);
    if (diffInHours < 24) return `${diffInHours}h ago`;
    
    const diffInDays = Math.floor(diffInHours / 24);
    return `${diffInDays}d ago`;
  };

  const formatFileSize = (bytes: number): string => {
    if (bytes === 0) return "0 Bytes";
    const k = 1024;
    const sizes = ["Bytes", "KB", "MB", "GB"];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + " " + sizes[i];
  };



  const navigationItems = [
    { id: 'chat', label: 'Trade Finance AI Assistant', icon: 'fas fa-comments' },
    { id: 'document-analyzer', label: 'Document Extraction', icon: 'fas fa-file-alt' },
    { id: 'high-risk-goods', label: 'High Risk Goods / Dual Use', icon: 'fas fa-exclamation-triangle' },
    // { id: 'activity-analyzer', label: 'Activity Analyzer', icon: 'fas fa-search' },
    // { id: 'customer-onboarding', label: 'Customer Onboarding', icon: 'fas fa-user-plus' },
    { id: 'api', label: 'API & Documentation', icon: 'fas fa-database' },
    { id: 'chat-history', label: 'Chat History', icon: 'fas fa-history' },
    { id: 'settings', label: 'Settings', icon: 'fas fa-cog' },
    { id: 'personal-notes', label: 'Personal Notes', icon: 'fas fa-sticky-note' }
  ];

  return (
    <div className="w-80 min-w-80 bg-white border-r border-slate-200 flex flex-col h-full">
      {/* Header */}
      <div className="p-4 border-b border-slate-200">
        <div className="flex items-center space-x-3">
          <div className="wells-fargo-logo">
            <div className="wells-fargo-red">
              <span className="wells-text">WELLS</span>
              <span className="fargo-text">FARGO</span>
            </div>
            <div className="wells-fargo-yellow"></div>
          </div>
          <div>
            <h1 className="font-semibold text-slate-900">Trade Finance AI Assistant</h1>
            <p className="text-xs text-slate-500">Wells Fargo Commercial Banking</p>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <div className="p-4 border-b border-slate-200">
        <div className="space-y-1">
          {navigationItems.map((item, index) => (
            <button
              key={item.id}
              onClick={() => onSectionChange(item.id)}
              className={`w-full flex items-center space-x-3 px-3 py-2 rounded-lg text-left transition-colors ${
                activeSection === item.id
                  ? 'bg-primary text-white'
                  : 'text-slate-700 hover:bg-slate-100'
              }`}
            >
              <i className={`${item.icon} text-sm`}></i>
              <span className="text-sm font-medium">{item.label}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Recent Documents */}
      <div className="p-4 border-b border-slate-200">
        <div className="flex items-center justify-between mb-3">
          <h3 className="font-semibold text-slate-900">Recent Documents</h3>
          {recentDocuments.length > 0 && (
            <button
              onClick={() => {
                localStorage.removeItem('recent_documents');
                setRecentDocuments([]);
                console.log("Cleared recent documents cache");
              }}
              className="text-slate-400 hover:text-red-600 transition-colors"
              title="Clear recent documents"
            >
              <Trash2 className="h-4 w-4" />
            </button>
          )}
        </div>
        <p className="text-sm text-slate-500 mb-3">Last 5 from Document Extraction</p>
        
        {recentDocuments.length === 0 ? (
          <p className="text-sm text-slate-500 italic">No documents analyzed yet</p>
        ) : (
          <div className="space-y-3">
            {recentDocuments.map((doc) => (
              <button
                key={doc.id}
                onClick={() => {
                  onSectionChange('document-analyzer');
                  onDocumentSelect?.(doc);
                }}
                className="w-full p-3 border border-slate-200 rounded-lg hover:bg-slate-50 transition-colors text-left"
              >
                <div className="flex items-start justify-between">
                  <div className="flex-1 min-w-0">
                    <h4 className="font-medium text-slate-900 text-sm truncate">{doc.originalName || doc.filename}</h4>
                    <p className="text-xs text-slate-500 mt-1">
                      {formatFileSize(doc.fileSize)} • {formatRelativeTime(new Date(doc.createdAt))}
                    </p>
                    {doc.extractedFields && doc.extractedFields.length > 0 && (
                      <p className="text-xs text-slate-400 mt-1 truncate">
                        {doc.extractedFields.length} fields extracted
                      </p>
                    )}
                  </div>
                  <div className="flex items-center space-x-2 ml-2">
                    <div className={`w-2 h-2 rounded-full ${
                      doc.extractedFields && doc.extractedFields.length > 0 ? "bg-green-500" : "bg-yellow-500"
                    }`}></div>
                  </div>
                </div>
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Trade Finance Tools */}
      <div className="p-4 border-b border-slate-200">
        <h3 className="font-semibold text-slate-900 mb-3">Trade Finance Tools</h3>
        <div className="space-y-1">
          <button
            onClick={() => onSectionChange('trade-calculations')}
            className={`w-full flex items-center space-x-3 px-3 py-2 rounded-lg text-left transition-colors ${
              activeSection === 'trade-calculations'
                ? 'bg-primary text-white'
                : 'text-slate-700 hover:bg-slate-100'
            }`}
          >
            <i className="fas fa-calculator text-sm"></i>
            <span className="text-sm font-medium">Calculation Tools</span>
          </button>
          
          <button
            onClick={() => onSectionChange('predictions-insights')}
            className={`w-full flex items-center space-x-3 px-3 py-2 rounded-lg text-left transition-colors ${
              activeSection === 'predictions-insights'
                ? 'bg-primary text-white'
                : 'text-slate-700 hover:bg-slate-100'
            }`}
          >
            <i className="fas fa-chart-line text-sm"></i>
            <span className="text-sm font-medium">Predictions & Insights</span>
          </button>
        </div>
      </div>
    </div>
  );
}
