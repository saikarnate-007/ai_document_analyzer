import { useState, useEffect } from "react";
import type { Document } from "@shared/schema";

interface ExtractedField {
  label: string;
  value: string;
  confidence: number;
  boundingBox?: {
    x: number;
    y: number;
    width: number;
    height: number;
  };
}

interface DocumentViewerProps {
  document: Document;
  extractedFields: ExtractedField[];
  highlightField?: string;
  onClose: () => void;
}

export function DocumentViewer({ document, extractedFields, highlightField, onClose }: DocumentViewerProps) {
  const [documentContent, setDocumentContent] = useState<string>("");
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    // Since we're using frontend-only approach, show extracted content instead
    if (document.analysisResult?.analysis || document.summary) {
      setDocumentContent(document.analysisResult?.analysis || document.summary || "Document analysis available");
    } else {
      setDocumentContent("Document has been processed. Analysis results available in extracted fields.");
    }
    setIsLoading(false);
  }, [document]);

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg max-w-4xl max-h-[90vh] w-full mx-4 flex flex-col">
        <div className="flex items-center justify-between p-4 border-b">
          <h3 className="text-lg font-medium">Document Viewer - {document.originalName}</h3>
          <button 
            onClick={onClose}
            className="text-gray-500 hover:text-gray-700 text-xl"
          >
            ✕
          </button>
        </div>
        <div className="flex-1 overflow-auto p-4">
          {isLoading ? (
            <div className="flex items-center justify-center h-96">
              <div className="text-gray-500">Loading document content...</div>
            </div>
          ) : (
            <div className="relative">
              {/* Document Analysis Content */}
              <div className="bg-slate-50 rounded-lg p-4 mb-4">
                <h4 className="font-medium text-slate-900 mb-2">Document Analysis</h4>
                <div className="text-sm text-slate-700 whitespace-pre-wrap">
                  {documentContent}
                </div>
              </div>
              
              {/* Extracted Fields Summary */}
              {extractedFields.length > 0 && (
                <div className="bg-blue-50 rounded-lg p-4">
                  <h4 className="font-medium text-blue-900 mb-3">Extracted Information</h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    {extractedFields.map((field, index) => (
                      <div key={index} className="bg-white rounded p-3 border border-blue-200">
                        <div className="text-xs font-medium text-blue-600 uppercase tracking-wide">{field.label}</div>
                        <div className={`text-sm text-slate-900 mt-1 ${highlightField === field.label ? 'bg-yellow-200 px-1 rounded' : ''}`}>
                          {field.value}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
              
              {/* Note about file viewing */}
              <div className="mt-4 p-3 bg-amber-50 border border-amber-200 rounded-lg">
                <div className="text-sm text-amber-800">
                  <strong>Note:</strong> This viewer shows the extracted analysis results. The original file ({document.originalName}) has been processed for key information extraction.
                </div>
              </div>
              
              {/* Highlighting Info */}
              {highlightField && (
                <div className="mt-4 p-3 bg-blue-50 border border-blue-200 rounded">
                  <div className="text-sm font-medium text-blue-800">
                    Highlighting: {highlightField}
                  </div>
                  <div className="text-sm text-blue-600">
                    Value: {extractedFields.find(f => f.label === highlightField)?.value || "Not found"}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}