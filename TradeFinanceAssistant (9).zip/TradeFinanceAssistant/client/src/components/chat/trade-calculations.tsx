import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";

interface CalculationResult {
  type: string;
  result: number;
  breakdown: { [key: string]: number };
  recommendations: string[];
}

export function TradeCalculations() {
  const [activeCalculator, setActiveCalculator] = useState<string>('lc-cost');
  const [calculationResult, setCalculationResult] = useState<CalculationResult | null>(null);
  const { toast } = useToast();
  
  // LC Calculator state
  const [lcAmount, setLcAmount] = useState<number>(0);
  const [lcBank, setLcBank] = useState<string>('');
  const [lcTenor, setLcTenor] = useState<number>(90);
  
  // Shipping Calculator state
  const [shippingWeight, setShippingWeight] = useState<number>(0);
  const [shippingVolume, setShippingVolume] = useState<number>(0);
  const [shippingRoute, setShippingRoute] = useState<string>('');
  const [shippingMode, setShippingMode] = useState<string>('');

  // Fetch real-time calculation data
  const { data: calculationsData, isLoading: isLoadingCalculations } = useQuery({
    queryKey: ["/api/trade-calculations"],
    staleTime: 5 * 60 * 1000, // 5 minutes
  });
  
  // Data source indicator (technical only)
  const isRealTimeData = calculationsData?.dataSource === "realtime";
  
  if (isLoadingCalculations) {
    return (
      <div className="flex-1 flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-slate-400"></div>
      </div>
    );
  }

  const calculators = [
    { id: 'lc-cost', label: 'Letter of Credit Cost', icon: 'fas fa-file-contract' },
    { id: 'shipping-cost', label: 'Shipping Cost Calculator', icon: 'fas fa-ship' },
    { id: 'currency-risk', label: 'Currency Risk Assessment', icon: 'fas fa-exchange-alt' },
    { id: 'trade-margin', label: 'Trade Margin Calculator', icon: 'fas fa-chart-line' },
    { id: 'insurance-premium', label: 'Trade Insurance Premium', icon: 'fas fa-shield-alt' },
    { id: 'financing-cost', label: 'Trade Financing Cost', icon: 'fas fa-percentage' }
  ];

  const calculateLCCost = (amount: number, bank: string, tenor: number) => {
    const baseFee = amount * 0.005; // 0.5% base fee
    const swiftCharges = 150;
    const amendmentReserve = 500;
    const courierCharges = 75;
    const authenticityFee = amount * 0.001; // 0.1%
    
    const total = baseFee + swiftCharges + amendmentReserve + courierCharges + authenticityFee;
    
    return {
      type: 'Letter of Credit Cost',
      result: total,
      breakdown: {
        'LC Issuance Fee (0.5%)': baseFee,
        'SWIFT Charges': swiftCharges,
        'Amendment Reserve': amendmentReserve,
        'Courier Charges': courierCharges,
        'Document Authentication (0.1%)': authenticityFee
      },
      recommendations: [
        'Consider negotiating LC fees based on relationship and transaction volume',
        'Review amendment clause to minimize unexpected costs',
        'Electronic presentation may reduce courier and processing fees'
      ]
    };
  };

  const calculateShippingCost = (weight: number, volume: number, route: string, mode: string) => {
    const baseRates: { [key: string]: number } = {
      'ocean': 800,
      'air': 2500,
      'land': 1200
    };
    
    const routeMultiplier: { [key: string]: number } = {
      'asia-europe': 1.2,
      'asia-americas': 1.5,
      'europe-americas': 1.3,
      'domestic': 0.8
    };
    
    const baseRate = baseRates[mode] || 1000;
    const multiplier = routeMultiplier[route] || 1.0;
    const weightFactor = Math.max(weight, volume * 200); // 200kg per CBM ratio
    
    const freightCost = (baseRate * multiplier * weightFactor) / 1000;
    const insuranceCost = freightCost * 0.02; // 2% insurance
    const documentationFee = 250;
    const handlingCharges = 150;
    
    const total = freightCost + insuranceCost + documentationFee + handlingCharges;
    
    return {
      type: 'Shipping Cost',
      result: total,
      breakdown: {
        'Freight Charges': freightCost,
        'Cargo Insurance (2%)': insuranceCost,
        'Documentation Fee': documentationFee,
        'Handling Charges': handlingCharges
      },
      recommendations: [
        'Consider consolidation for better rates on smaller shipments',
        'Review Incoterms to optimize cost allocation',
        'Negotiate volume discounts for regular shipping routes'
      ]
    };
  };

  const handleLCCalculate = () => {
    if (lcAmount > 0) {
      const result = calculateLCCost(lcAmount, lcBank, lcTenor);
      setCalculationResult(result);
      toast({
        title: "Calculation Complete",
        description: `Total LC cost: $${result.result.toLocaleString()}`,
      });
    }
  };

  const renderLCCalculator = () => {
    return (
      <div className="space-y-6">
        <h4 className="text-lg font-semibold text-slate-900">Letter of Credit Cost Calculator</h4>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">LC Amount (USD)</label>
            <input
              type="number"
              value={lcAmount || ''}
              onChange={(e) => setLcAmount(Number(e.target.value))}
              className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              placeholder="Enter LC amount"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">Issuing Bank Type</label>
            <select
              value={lcBank}
              onChange={(e) => setLcBank(e.target.value)}
              className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            >
              <option value="">Select Bank Type</option>
              <option value="tier1">Tier 1 International Bank</option>
              <option value="regional">Regional Bank</option>
              <option value="local">Local Bank</option>
              <option value="islamic">Islamic Bank</option>
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">LC Tenor (Days)</label>
            <input
              type="number"
              value={lcTenor}
              onChange={(e) => setLcTenor(Number(e.target.value))}
              className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              placeholder="Enter tenor in days"
            />
          </div>
        </div>
        <button
          onClick={handleLCCalculate}
          className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
        >
          Calculate LC Cost
        </button>
      </div>
    );
  };

  const handleShippingCalculate = () => {
    if (shippingWeight > 0 && shippingVolume > 0) {
      const result = calculateShippingCost(shippingWeight, shippingVolume, shippingRoute, shippingMode);
      setCalculationResult(result);
      toast({
        title: "Calculation Complete",
        description: `Total shipping cost: $${result.result.toLocaleString()}`,
      });
    }
  };

  const renderShippingCalculator = () => {
    return (
      <div className="space-y-6">
        <h4 className="text-lg font-semibold text-slate-900">Shipping Cost Calculator</h4>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">Weight (KG)</label>
            <input
              type="number"
              value={shippingWeight || ''}
              onChange={(e) => setShippingWeight(Number(e.target.value))}
              className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              placeholder="Enter cargo weight"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">Volume (CBM)</label>
            <input
              type="number"
              value={shippingVolume || ''}
              onChange={(e) => setShippingVolume(Number(e.target.value))}
              className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              placeholder="Enter cargo volume"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">Trade Route</label>
            <select
              value={shippingRoute}
              onChange={(e) => setShippingRoute(e.target.value)}
              className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            >
              <option value="">Select Route</option>
              <option value="asia-europe">Asia to Europe</option>
              <option value="asia-americas">Asia to Americas</option>
              <option value="europe-americas">Europe to Americas</option>
              <option value="domestic">Domestic</option>
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">Transport Mode</label>
            <select
              value={shippingMode}
              onChange={(e) => setShippingMode(e.target.value)}
              className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            >
              <option value="">Select Mode</option>
              <option value="ocean">Ocean Freight</option>
              <option value="air">Air Freight</option>
              <option value="land">Land Transport</option>
            </select>
          </div>
        </div>
        <button
          onClick={handleShippingCalculate}
          className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
        >
          Calculate Shipping Cost
        </button>
      </div>
    );
  };

  return (
    <div className="flex-1 flex flex-col">
      {/* Calculator Selection */}
      <div className="border-b border-slate-200 p-6 bg-white">
        <h3 className="text-lg font-medium text-slate-900 mb-4">Trade Finance Calculation Tools</h3>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
          {calculators.map((calc) => (
            <button
              key={calc.id}
              onClick={() => setActiveCalculator(calc.id)}
              className={`p-3 rounded-lg border transition-colors text-center ${
                activeCalculator === calc.id
                  ? 'bg-blue-50 border-blue-300 text-blue-700'
                  : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
              }`}
            >
              <i className={`${calc.icon} text-lg mb-2 block`}></i>
              <span className="text-xs font-medium">{calc.label}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Calculator Content */}
      <div className="flex-1 overflow-y-auto p-6">
        <div className="max-w-4xl">
          {activeCalculator === 'lc-cost' && renderLCCalculator()}
          {activeCalculator === 'shipping-cost' && renderShippingCalculator()}
          {activeCalculator === 'currency-risk' && (
            <div className="text-center py-12 text-slate-500">
              <i className="fas fa-tools text-4xl mb-4"></i>
              <p>Currency Risk Assessment calculator coming soon</p>
            </div>
          )}
          {activeCalculator === 'trade-margin' && (
            <div className="text-center py-12 text-slate-500">
              <i className="fas fa-tools text-4xl mb-4"></i>
              <p>Trade Margin Calculator coming soon</p>
            </div>
          )}
          {activeCalculator === 'insurance-premium' && (
            <div className="text-center py-12 text-slate-500">
              <i className="fas fa-tools text-4xl mb-4"></i>
              <p>Trade Insurance Premium calculator coming soon</p>
            </div>
          )}
          {activeCalculator === 'financing-cost' && (
            <div className="text-center py-12 text-slate-500">
              <i className="fas fa-tools text-4xl mb-4"></i>
              <p>Trade Financing Cost calculator coming soon</p>
            </div>
          )}

          {/* Results Display */}
          {calculationResult && (
            <div className="mt-8 bg-white rounded-lg border border-slate-200 p-6">
              <h4 className="text-lg font-semibold text-slate-900 mb-4">{calculationResult.type} Results</h4>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <div className="bg-blue-50 rounded-lg p-4 mb-4">
                    <div className="text-center">
                      <p className="text-sm text-blue-600 mb-1">Total Cost</p>
                      <p className="text-2xl font-bold text-blue-900">
                        ${calculationResult.result.toLocaleString()}
                      </p>
                    </div>
                  </div>
                  
                  <div>
                    <h5 className="text-sm font-medium text-slate-900 mb-3">Cost Breakdown</h5>
                    <div className="space-y-2">
                      {Object.entries(calculationResult.breakdown).map(([item, cost]) => (
                        <div key={item} className="flex justify-between text-sm">
                          <span className="text-slate-600">{item}</span>
                          <span className="font-medium text-slate-900">${cost.toLocaleString()}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
                
                <div>
                  <h5 className="text-sm font-medium text-slate-900 mb-3">Recommendations</h5>
                  <ul className="space-y-2">
                    {calculationResult.recommendations.map((rec, index) => (
                      <li key={index} className="flex items-start space-x-2 text-sm text-slate-600">
                        <i className="fas fa-lightbulb text-yellow-500 mt-0.5 flex-shrink-0"></i>
                        <span>{rec}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          )}
        </div>
        
        {/* Data Source Indicator for Technical Users */}
        {!isRealTimeData && (
          <div className="mt-4 text-xs text-slate-400 border-t pt-2">
            [DS: fallback] - Contact your relationship manager for real-time rates
          </div>
        )}
      </div>
    </div>
  );
}