import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { nanoid } from "nanoid";

interface ActivityAnalysis {
  referenceNumber: string;
  documents: DocumentSummary[];
  settlements: Settlement[];
  fees: Fee[];
  redFlags: RedFlag[];
  parties: Party[];
  sanctions: SanctionCheck[];
  transactionLimits: TransactionLimit[];
  riskScore: number;
  complianceStatus: 'compliant' | 'warning' | 'violation';
}

interface DocumentSummary {
  type: string;
  status: string;
  value: number;
  currency: string;
  date: string;
}

interface Settlement {
  amount: number;
  currency: string;
  settlementDate: string;
  status: 'pending' | 'completed' | 'failed';
  method: string;
}

interface Fee {
  type: string;
  amount: number;
  currency: string;
  description: string;
}

interface RedFlag {
  severity: 'low' | 'medium' | 'high' | 'critical';
  type: string;
  description: string;
  recommendation: string;
}

interface Party {
  name: string;
  type: 'buyer' | 'seller' | 'bank' | 'intermediary';
  country: string;
  sanctionStatus: 'clear' | 'watchlist' | 'sanctioned';
  riskLevel: 'low' | 'medium' | 'high';
}

interface SanctionCheck {
  entity: string;
  listName: string;
  status: 'clear' | 'match' | 'potential_match';
  details: string;
}

interface TransactionLimit {
  type: string;
  limit: number;
  currency: string;
  current: number;
  utilization: number;
}

export function ActivityAnalyzer() {
  // All hooks must be called in the same order every time
  const [referenceNumber, setReferenceNumber] = useState("");
  const [analysis, setAnalysis] = useState<ActivityAnalysis | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const { toast } = useToast();

  // Fetch real-time activity analysis data
  const { data: activityData, isLoading: isLoadingActivity } = useQuery({
    queryKey: ["/api/activity-analysis"],
    staleTime: 5 * 60 * 1000, // 5 minutes
  });

  // Analyze mutation
  const analyzeMutation = useMutation({
    mutationFn: async (refNumber: string) => {
      try {
        const response = await fetch('/api/activity/analyze', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ referenceNumber: refNumber }),
        });

        if (response.ok) {
          const result = await response.json();
          return result;
        } else {
          throw new Error("API analysis failed");
        }
      } catch (error) {
        console.error("Analysis API failed, using dummy data:", error);
        
        // Use real-time data if available, otherwise use dummy data
        const dummyAnalysis: ActivityAnalysis = activityData || {
          referenceNumber: refNumber,
          documents: [
            { type: "Letter of Credit (Irrevocable Documentary)", status: "Verified & Authenticated", value: 500000, currency: "USD", date: "2024-01-15" },
            { type: "Ocean Bill of Lading (Clean On Board)", status: "Processed & Stamped", value: 500000, currency: "USD", date: "2024-01-18" },
            { type: "Commercial Invoice (Proforma Certified)", status: "Validated by Customs", value: 485000, currency: "USD", date: "2024-01-16" },
            { type: "Certificate of Origin (GSP Form A)", status: "Approved by Chamber", value: 0, currency: "USD", date: "2024-01-14" },
            { type: "Packing List & Weight Certificate", status: "Verified by Surveyor", value: 0, currency: "USD", date: "2024-01-16" },
            { type: "Insurance Certificate (Marine Coverage)", status: "Policy Active", value: 550000, currency: "USD", date: "2024-01-15" }
          ],
          settlements: [
            { amount: 485000, currency: "USD", settlementDate: "2024-01-25", status: "completed", method: "SWIFT MT103 Wire Transfer" },
            { amount: 15000, currency: "USD", settlementDate: "2024-01-26", status: "pending", method: "Correspondent Banking Network" },
            { amount: 2500, currency: "EUR", settlementDate: "2024-01-27", status: "pending", method: "SEPA Credit Transfer" }
          ],
          fees: [
            { type: "Letter of Credit Issuance Fee", amount: 2500, currency: "USD", description: "Documentary credit opening charges including SWIFT messaging and document examination fees" },
            { type: "Trade Document Processing", amount: 750, currency: "USD", description: "Document verification, authentication, and compliance checking by certified trade specialists" },
            { type: "LC Amendment & Modification", amount: 500, currency: "USD", description: "Processing charges for credit amendments including beneficiary and amount changes" },
            { type: "International SWIFT Charges", amount: 125, currency: "USD", description: "Cross-border wire transfer fees including correspondent bank charges and currency conversion" },
            { type: "Document Courier & Handling", amount: 85, currency: "USD", description: "Physical document transportation and secure handling via authorized courier services" },
            { type: "Compliance & AML Screening", amount: 200, currency: "USD", description: "Anti-money laundering checks, sanctions screening, and regulatory compliance verification" }
          ],
          redFlags: [
            { 
              severity: "medium", 
              type: "Geographic Risk Assessment", 
              description: "Transaction routing involves jurisdiction with elevated financial crime risk according to FATF and regulatory advisories. Country risk score indicates enhanced monitoring requirements.", 
              recommendation: "Implement enhanced due diligence procedures including additional party verification, source of funds documentation, and ongoing transaction monitoring as per AML/CFT guidelines." 
            },
            { 
              severity: "low", 
              type: "Invoice Amount Discrepancy", 
              description: "Commercial invoice amount (USD 485,000) differs from original Letter of Credit value (USD 500,000) by 3%, which exceeds standard tolerance levels typically accepted in trade finance.", 
              recommendation: "Request detailed explanation for price variance, obtain amended commercial documentation, and verify compliance with credit terms and conditions before payment authorization." 
            },
            { 
              severity: "high", 
              type: "Documentation Timeline Anomaly", 
              description: "Bill of Lading date (2024-01-18) issued after commercial invoice date (2024-01-16), which creates inconsistency in the normal trade document flow and could indicate potential fraud.", 
              recommendation: "Conduct thorough document authenticity verification, contact issuing authorities for confirmation, and consider independent trade verification before proceeding with settlement." 
            }
          ],
          parties: [
            { name: "Global Export Industries Corporation Ltd", type: "seller", country: "Germany (Frankfurt am Main)", sanctionStatus: "clear", riskLevel: "low" },
            { name: "Import Solutions & Trading LLC", type: "buyer", country: "United States (Delaware)", sanctionStatus: "clear", riskLevel: "low" },
            { name: "Deutsche Bank AG (Trade Finance Division)", type: "bank", country: "Germany (Frankfurt)", sanctionStatus: "clear", riskLevel: "low" },
            { name: "JPMorgan Chase Bank N.A. (International)", type: "bank", country: "United States (New York)", sanctionStatus: "clear", riskLevel: "low" },
            { name: "Mediterranean Shipping Company S.A.", type: "intermediary", country: "Switzerland (Geneva)", sanctionStatus: "clear", riskLevel: "low" },
            { name: "Lloyd's of London Insurance Syndicate", type: "intermediary", country: "United Kingdom (London)", sanctionStatus: "clear", riskLevel: "low" }
          ],
          sanctions: [
            { entity: "Global Export Industries Corporation Ltd", listName: "OFAC Specially Designated Nationals (SDN)", status: "clear", details: "Comprehensive screening completed - No matches found in current sanctions database. Last updated: 2024-01-20" },
            { entity: "Import Solutions & Trading LLC", listName: "European Union Consolidated Sanctions List", status: "clear", details: "Full entity verification completed - Clean status confirmed across all EU sanctions regimes including Russia, Belarus, and sectoral sanctions" },
            { entity: "Deutsche Bank AG", listName: "United Nations Security Council Sanctions", status: "clear", details: "Financial institution screening completed - No adverse findings in UN sanctions database or asset freeze listings" },
            { entity: "JPMorgan Chase Bank N.A.", listName: "OFAC Non-SDN Lists (FSE, NS-MBS)", status: "clear", details: "Cleared across all OFAC screening lists including Foreign Sanctions Evaders and Non-SDN Menu-Based Sanctions programs" },
            { entity: "Mediterranean Shipping Company S.A.", listName: "UK HM Treasury Sanctions List", status: "clear", details: "Transportation provider verified - No matches in UK financial sanctions regime or shipping-related sanctions measures" }
          ],
          transactionLimits: [
            { type: "Daily Transaction Limit (USD)", limit: 1000000, currency: "USD", current: 500000, utilization: 50 },
            { type: "Monthly Exposure Limit (USD)", limit: 10000000, currency: "USD", current: 2500000, utilization: 25 },
            { type: "Quarterly Risk Concentration", limit: 20000000, currency: "USD", current: 8500000, utilization: 42.5 },
            { type: "Annual Country Exposure (Germany)", limit: 50000000, currency: "USD", current: 15000000, utilization: 30 },
            { type: "Single Customer Limit", limit: 5000000, currency: "USD", current: 1200000, utilization: 24 }
          ],
          riskScore: 6.2,
          complianceStatus: "warning"
        };
        
        return dummyAnalysis;
      }
    },
    onSuccess: (result) => {
      setAnalysis(result);
      setIsAnalyzing(false);
      toast({
        title: "Analysis Complete",
        description: "Activity analysis has been generated successfully",
      });
    },
    onError: (error) => {
      setIsAnalyzing(false);
      toast({
        title: "Analysis Failed",
        description: "Unable to analyze activity. Please try again.",
        variant: "destructive",
      });
    },
  });

  // Data source indicator (technical only)
  const isRealTimeData = activityData?.dataSource === "realtime";

  const handleAnalyze = () => {
    if (referenceNumber.trim()) {
      setIsAnalyzing(true);
      analyzeMutation.mutate(referenceNumber.trim());
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleAnalyze();
    }
  };

  const getRiskColor = (level: string) => {
    switch (level) {
      case 'low': return 'text-green-600';
      case 'medium': return 'text-yellow-600';
      case 'high': return 'text-red-600';
      case 'critical': return 'text-red-800';
      default: return 'text-gray-600';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed': case 'clear': case 'compliant': return 'text-green-600';
      case 'pending': case 'warning': return 'text-yellow-600';
      case 'failed': case 'sanctioned': case 'violation': return 'text-red-600';
      default: return 'text-gray-600';
    }
  };

  // Show loading state if initial data is loading
  if (isLoadingActivity) {
    return (
      <div className="flex-1 flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-slate-400"></div>
      </div>
    );
  }

  return (
    <div className="flex-1 flex flex-col">
      {/* Search Section */}
      <div className="border-b border-slate-200 p-6 bg-white">
        <div className="max-w-2xl">
          <h3 className="text-lg font-medium text-slate-900 mb-4">Activity Reference Analysis</h3>
          <div className="flex space-x-3">
            <div className="flex-1">
              <input
                type="text"
                value={referenceNumber}
                onChange={(e) => setReferenceNumber(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder="Enter activity reference number (e.g., TF-2024-001234)"
                className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                disabled={isAnalyzing}
              />
            </div>
            <button
              onClick={handleAnalyze}
              disabled={!referenceNumber.trim() || isAnalyzing}
              className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:bg-gray-400 disabled:cursor-not-allowed transition-colors"
            >
              {isAnalyzing ? (
                <div className="flex items-center space-x-2">
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                  <span>Analyzing...</span>
                </div>
              ) : (
                "Analyze"
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Results Section */}
      <div className="flex-1 overflow-y-auto p-6">
        {analysis ? (
          <div className="w-full space-y-8">
            {/* Overview Cards */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              <div className="bg-white p-6 rounded-lg border border-slate-200">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-slate-500">Risk Score</p>
                    <p className="text-2xl font-bold text-slate-900">{analysis.riskScore}/10</p>
                  </div>
                  <div className={`w-12 h-12 rounded-full flex items-center justify-center ${
                    analysis.riskScore < 3 ? 'bg-green-100' : 
                    analysis.riskScore < 7 ? 'bg-yellow-100' : 'bg-red-100'
                  }`}>
                    <span className={`text-lg ${
                      analysis.riskScore < 3 ? 'text-green-600' : 
                      analysis.riskScore < 7 ? 'text-yellow-600' : 'text-red-600'
                    }`}>⚠</span>
                  </div>
                </div>
              </div>

              <div className="bg-white p-6 rounded-lg border border-slate-200">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-slate-500">Compliance</p>
                    <p className={`text-lg font-semibold capitalize ${getStatusColor(analysis.complianceStatus)}`}>
                      {analysis.complianceStatus}
                    </p>
                  </div>
                  <div className="w-12 h-12 rounded-full bg-blue-100 flex items-center justify-center">
                    <span className="text-blue-600 text-lg">✓</span>
                  </div>
                </div>
              </div>

              <div className="bg-white p-6 rounded-lg border border-slate-200">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-slate-500">Documents</p>
                    <p className="text-2xl font-bold text-slate-900">{analysis.documents.length}</p>
                  </div>
                  <div className="w-12 h-12 rounded-full bg-purple-100 flex items-center justify-center">
                    <span className="text-purple-600 text-lg">📄</span>
                  </div>
                </div>
              </div>

              <div className="bg-white p-6 rounded-lg border border-slate-200">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-slate-500">Red Flags</p>
                    <p className="text-2xl font-bold text-slate-900">{analysis.redFlags.length}</p>
                  </div>
                  <div className="w-12 h-12 rounded-full bg-red-100 flex items-center justify-center">
                    <span className="text-red-600 text-lg">⚠</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Documents */}
            <div className="bg-white rounded-lg border border-slate-200">
              <div className="p-6 border-b border-slate-200">
                <h4 className="text-lg font-semibold text-slate-900">Document Analysis</h4>
              </div>
              <div className="p-6">
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b border-slate-200">
                        <th className="text-left py-3 text-sm font-medium text-slate-500">Document Type</th>
                        <th className="text-left py-3 text-sm font-medium text-slate-500">Status</th>
                        <th className="text-left py-3 text-sm font-medium text-slate-500">Value</th>
                        <th className="text-left py-3 text-sm font-medium text-slate-500">Date</th>
                      </tr>
                    </thead>
                    <tbody>
                      {analysis.documents.map((doc, index) => (
                        <tr key={index} className="border-b border-slate-100">
                          <td className="py-3 text-sm text-slate-900">{doc.type}</td>
                          <td className="py-3">
                            <span className={`text-sm ${getStatusColor(doc.status.toLowerCase())}`}>
                              {doc.status}
                            </span>
                          </td>
                          <td className="py-3 text-sm text-slate-900">
                            {doc.value > 0 ? `${doc.currency} ${doc.value.toLocaleString()}` : '-'}
                          </td>
                          <td className="py-3 text-sm text-slate-500">{doc.date}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>

            {/* Red Flags */}
            <div className="bg-white rounded-lg border border-slate-200">
              <div className="p-6 border-b border-slate-200">
                <h4 className="text-lg font-semibold text-slate-900">Risk & Red Flags</h4>
              </div>
              <div className="p-6">
                <div className="space-y-4">
                  {analysis.redFlags.map((flag, index) => (
                    <div key={index} className="border border-slate-200 rounded-lg p-4">
                      <div className="flex items-start space-x-3">
                        <div className={`w-2 h-2 rounded-full mt-2 ${
                          flag.severity === 'critical' ? 'bg-red-600' :
                          flag.severity === 'high' ? 'bg-red-500' :
                          flag.severity === 'medium' ? 'bg-yellow-500' : 'bg-green-500'
                        }`}></div>
                        <div className="flex-1">
                          <div className="flex items-center space-x-2">
                            <span className={`text-sm font-medium ${getRiskColor(flag.severity)}`}>
                              {flag.severity.toUpperCase()}
                            </span>
                            <span className="text-sm font-medium text-slate-900">{flag.type}</span>
                          </div>
                          <p className="text-sm text-slate-600 mt-1">{flag.description}</p>
                          <p className="text-sm text-blue-600 mt-2">{flag.recommendation}</p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        ) : (
          <div className="max-w-2xl mx-auto text-center py-12">
            <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <span className="text-blue-600 text-xl">🔍</span>
            </div>
            <h3 className="text-lg font-medium text-slate-900 mb-2">Activity Analysis</h3>
            <p className="text-slate-500 mb-6">
              Enter an activity reference number to get comprehensive analysis including documents, settlements, 
              fees, risk factors, parties involved, sanctions screening, and transaction limits.
            </p>
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 text-left">
              <h4 className="text-sm font-medium text-blue-900 mb-2">Analysis includes:</h4>
              <ul className="text-sm text-blue-700 space-y-1">
                <li>• Document verification and status</li>
                <li>• Settlement tracking and fees breakdown</li>
                <li>• Financial crime red flags detection</li>
                <li>• Involved parties risk assessment</li>
                <li>• Sanctions list screening</li>
                <li>• Transaction limits and utilization</li>
              </ul>
            </div>
          </div>
        )}
      </div>
      
      {/* Data Source Indicator for Technical Users */}
      {!isRealTimeData && (
        <div className="mt-4 text-xs text-slate-400 border-t pt-2 px-6">
          [DS: fallback] - Contact your relationship manager for real-time analysis
        </div>
      )}
    </div>
  );
}