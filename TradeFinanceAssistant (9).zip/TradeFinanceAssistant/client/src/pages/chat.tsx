import { useState, useEffect } from "react";
import { useParams } from "wouter";
import { nanoid } from "nanoid";
import { storage } from "@/lib/storage";
import { Sidebar } from "@/components/chat/sidebar";
import { ChatInterface } from "@/components/chat/chat-interface";
import { DocumentAnalyzer } from "@/components/chat/document-analyzer";
import { RecentDocuments } from "@/components/chat/recent-documents";
import { HighRiskGoods } from "@/components/chat/high-risk-goods";
import { ChatHistory } from "@/components/chat/chat-history";
import { Settings } from "@/components/chat/settings";
import { PersonalNotes } from "@/components/chat/personal-notes";
import { ActivityAnalyzer } from "@/components/chat/activity-analyzer";
import { CustomerOnboarding } from "@/components/chat/customer-onboarding";
import { TradeCalculations } from "@/components/chat/trade-calculations";
import { PredictionsInsights } from "@/components/chat/predictions-insights";
import APIPage from "@/pages/api";
import type { Document } from "@shared/schema";

type ActiveSection = 'chat' | 'document-analyzer' | 'high-risk-goods' | 'activity-analyzer' | 'customer-onboarding' | 'trade-calculations' | 'predictions-insights' | 'chat-history' | 'settings' | 'personal-notes' | 'api';

export default function ChatPage() {
  const params = useParams();
  const [sessionId, setSessionId] = useState<string>("");
  const [activeSection, setActiveSection] = useState<ActiveSection>('document-analyzer');
  const [selectedMessage, setSelectedMessage] = useState<string>("");
  const [selectedDocument, setSelectedDocument] = useState<Document | null>(null);
  const userSettings = storage.getUserSettings();

  useEffect(() => {
    if (params.sessionId) {
      setSessionId(params.sessionId);
    } else {
      // Generate a new session ID
      const newSessionId = nanoid();
      setSessionId(newSessionId);
      // Update URL without causing navigation
      window.history.replaceState(null, "", `/chat/${newSessionId}`);
    }
  }, [params.sessionId]);

  if (!sessionId) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-slate-400"></div>
      </div>
    );
  }

  const getSectionTitle = (): string => {
    switch (activeSection) {
      case 'chat': return 'Trade Finance AI Assistant';
      case 'document-analyzer': return 'Document Extraction';
      case 'recent-documents': return 'Recent Documents';
      case 'high-risk-goods': return 'High Risk Goods / Dual Use Detection';
      case 'activity-analyzer': return 'Activity Analyzer';
      case 'customer-onboarding': return 'Customer Onboarding';
      case 'trade-calculations': return 'Trade Finance Calculation Tools';
      case 'predictions-insights': return 'Predictions and Insights';
      case 'chat-history': return 'Chat History';
      case 'settings': return 'Settings';
      case 'personal-notes': return 'Personal Notes';
      case 'api': return 'API Data & Extractions';
      default: return 'Trade Finance Assistant';
    }
  };

  const getSectionDescription = (): string => {
    switch (activeSection) {
      case 'chat': return 'Ask questions about trade finance solutions, compliance, and regulations';
      case 'document-analyzer': return 'Extract data from trade finance documents with AI-powered field recognition';

      case 'high-risk-goods': return 'Identify high risk goods and dual use items for compliance screening';
      case 'activity-analyzer': return 'Analyze trade activities, settlements, compliance and risk factors';
      case 'customer-onboarding': return 'Complete customer due diligence and business profile assessment';
      case 'trade-calculations': return 'Calculate trade finance costs, margins, and risk assessments';
      case 'predictions-insights': return 'View market trends, risk predictions, and strategic insights';
      case 'chat-history': return 'View and manage your previous conversations';
      case 'settings': return 'Manage your profile and application settings';
      case 'personal-notes': return 'Create and manage your personal to-do tasks and notes';
      case 'api': return 'View all uploaded documents and their extracted data in API format';
      default: return 'Ask questions and analyze your trade finance documents';
    }
  };

  const handleDocumentUploaded = () => {
    // Optional: Auto-switch to document analyzer after upload
    // setActiveSection('document-analyzer');
  };

  const handleMessageSelect = (message: string) => {
    setSelectedMessage(message);
    setActiveSection('chat');
  };

  const handleMessageUsed = () => {
    setSelectedMessage("");
  };

  return (
    <div className="flex h-screen w-screen overflow-hidden bg-slate-50 fixed inset-0">
      <Sidebar 
        sessionId={sessionId} 
        activeSection={activeSection} 
        onSectionChange={setActiveSection}
        onDocumentSelect={setSelectedDocument}
      />
      
      <div className="flex-1 flex flex-col min-h-0">
        <header className="bg-white border-b border-slate-200 px-6 py-4 flex-shrink-0">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-xl font-semibold text-slate-900">{getSectionTitle()}</h2>
              <p className="text-sm text-slate-500">{getSectionDescription()}</p>
            </div>
            
            {/* User Profile Section */}
            <div className="flex items-center space-x-4">
              <div className="text-right">
                <p className="text-sm font-medium text-slate-900">{userSettings.username}</p>
                <p className="text-xs text-slate-500">Wells Fargo Credit Manager</p>
                {userSettings.email && (
                  <p className="text-xs text-slate-400">{userSettings.email}</p>
                )}
              </div>
              <div 
                className="relative cursor-pointer"
                onClick={() => setActiveSection('settings')}
                title="User Profile Settings"
              >
                <div className="w-10 h-10 bg-red-600 rounded-full flex items-center justify-center hover:bg-red-700 transition-colors">
                  <span className="text-white font-medium text-sm">
                    {userSettings.username.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2)}
                  </span>
                </div>
                <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-green-500 rounded-full border-2 border-white" title="Online"></div>
              </div>
            </div>
          </div>
        </header>

        <div className="flex-1 flex min-h-0 overflow-hidden">
          {activeSection === 'chat' && (
            <div className="flex-1 flex flex-col overflow-hidden">
              <ChatInterface 
                sessionId={sessionId} 
                onDocumentUploaded={handleDocumentUploaded}
                selectedMessage={selectedMessage}
                onMessageUsed={handleMessageUsed}
              />
            </div>
          )}
          
          {activeSection === 'document-analyzer' && (
            <div className="flex-1 flex flex-col overflow-hidden">
              <DocumentAnalyzer selectedDocument={selectedDocument} onDocumentCleared={() => setSelectedDocument(null)} />
            </div>
          )}

          {activeSection === 'high-risk-goods' && (
            <div className="flex-1 flex flex-col overflow-hidden">
              <HighRiskGoods />
            </div>
          )}
          
          {activeSection === 'activity-analyzer' && (
            <div className="flex-1 flex flex-col overflow-hidden">
              <ActivityAnalyzer />
            </div>
          )}
          
          {activeSection === 'customer-onboarding' && (
            <div className="flex-1 flex flex-col overflow-hidden">
              <CustomerOnboarding />
            </div>
          )}
          
          {activeSection === 'trade-calculations' && (
            <div className="flex-1 flex flex-col overflow-hidden">
              <TradeCalculations />
            </div>
          )}
          
          {activeSection === 'predictions-insights' && (
            <div className="flex-1 flex flex-col overflow-hidden">
              <PredictionsInsights />
            </div>
          )}
          
          {activeSection === 'chat-history' && (
            <div className="flex-1 flex flex-col overflow-hidden">
              <ChatHistory onMessageSelect={handleMessageSelect} />
            </div>
          )}
          
          {activeSection === 'settings' && (
            <div className="flex-1 flex flex-col overflow-hidden">
              <Settings />
            </div>
          )}
          
          {activeSection === 'personal-notes' && (
            <div className="flex-1 flex flex-col overflow-hidden">
              <PersonalNotes />
            </div>
          )}
          
          {activeSection === 'api' && (
            <div className="flex-1 flex flex-col overflow-hidden">
              <APIPage />
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
