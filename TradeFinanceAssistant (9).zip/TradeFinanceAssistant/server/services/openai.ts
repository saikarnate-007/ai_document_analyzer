import OpenAI from "openai";
import * as fs from "fs";
import * as path from "path";

// Load API configuration from JSON file
const configPath = path.join(process.cwd(), 'server/config/api-config.json');
const config = JSON.parse(fs.readFileSync(configPath, 'utf8'));
const { tachyon, apigee } = config.services;

// Fallback OpenAI client for when custom API fails
const openai = new OpenAI({ 
  apiKey: process.env.OPENAI_API_KEY || "fallback_key"
});

// Function to get OAuth token from Apigee
async function getOAuthToken(): Promise<string> {
  try {
    const response = await fetch(apigee["oauth-url"], {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
        'Authorization': `Basic ${Buffer.from(`${apigee.consumer.key}:${apigee.consumer.secret}`).toString('base64')}`
      },
      body: 'grant_type=client_credentials'
    });

    if (!response.ok) {
      throw new Error(`OAuth request failed: ${response.status}`);
    }

    const data = await response.json();
    return data.access_token;
  } catch (error) {
    console.error("OAuth token error:", error);
    throw error;
  }
}

// Unified chat/completions API function with document attachment support
async function callChatCompletionsAPI(
  prompt: string, 
  systemPrompt: string, 
  documentBase64?: string, 
  mimeType?: string
): Promise<string> {
  try {
    // Get OAuth token
    const oauthToken = await getOAuthToken();

    // Prepare messages with document attachment if provided
    const messages = [
      { role: "system", content: systemPrompt }
    ];

    if (documentBase64 && mimeType) {
      // Add document as attachment for multimodal analysis
      messages.push({
        role: "user",
        content: [
          { type: "text", text: prompt },
          {
            type: "image_url",
            image_url: {
              url: `data:${mimeType};base64,${documentBase64}`
            }
          }
        ]
      });
    } else {
      // Text-only message
      messages.push({ role: "user", content: prompt });
    }

    const response = await fetch(tachyon["chat-svc-endpoint"], {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${oauthToken}`,
        'usecase-id': tachyon["usecase-id"],
        'client-id': tachyon["client-id"],
        'api-key': tachyon["api-key"]
      },
      body: JSON.stringify({
        model: tachyon.model,
        messages: messages,
        temperature: tachyon.temperature,
        top_p: tachyon.top_p,
        top_k: tachyon.top_k,
        max_tokens: tachyon.max_tokens,
        stubs: tachyon.stubs
      })
    });

    if (!response.ok) {
      throw new Error(`Tachyon API request failed: ${response.status}`);
    }

    const data = await response.json();
    return data.choices?.[0]?.message?.content || "I apologize, but I couldn't generate a response.";
  } catch (error) {
    console.error("Tachyon API error:", error);
    throw error;
  }
}

export async function generateChatResponse(messages: Array<{role: string, content: string}>): Promise<string> {
  try {
    const systemPrompt = `You are Sai Kumar Karnate's specialized Trade Finance AI Assistant with expertise in:
- Letters of Credit (LC) and UCP 600 rules
- Bills of Lading and shipping documents
- Commercial invoices and payment terms
- Trade finance regulations and compliance
- Document validation and analysis
- Import/export procedures

Provide accurate, detailed responses about trade finance topics. When analyzing documents, focus on compliance, accuracy, and potential issues. Always address responses to Sai Kumar Karnate personally.`;

    const conversationText = messages.map(msg => `${msg.role}: ${msg.content}`).join('\n');
    return await callChatCompletionsAPI(conversationText, systemPrompt);
  } catch (error) {
    console.error("Chat API failed, returning fallback response:", error);
    return "Hello Sai Kumar Karnate! I'm experiencing technical difficulties with the AI service. Please try again later. In the meantime, I can help you with basic trade finance questions using our standard knowledge base.";
  }
}

export async function analyzeDocument(documentContent: string, customPrompt: string, documentBase64?: string): Promise<{
  summary: string;
  compliance: Array<{
    status: 'pass' | 'warning' | 'fail';
    message: string;
    reference?: string;
  }>;
  keyFindings: string[];
}> {
  try {
    const systemPrompt = `You are Sai Kumar Karnate's Document Extraction AI specialist. Analyze the provided document for trade finance compliance and extract key information. 

Focus on:
- Document validation and compliance checks
- Key data extraction (dates, amounts, parties, terms)
- Risk assessment and red flags
- UCP 600 and ISBP compliance

Return the analysis in this exact JSON format:
{
  "summary": "Document analysis summary",
  "compliance": [
    {"status": "pass|warning|fail", "message": "Compliance message", "reference": "Standard reference"}
  ],
  "keyFindings": ["Finding 1", "Finding 2", "Finding 3"]
}`;

    const prompt = `${customPrompt}
    
    Document Content: ${documentContent}
    
    Provide comprehensive analysis for Sai Kumar Karnate including compliance status, key findings, and recommendations.`;

    const response = await callChatCompletionsAPI(prompt, systemPrompt, documentBase64, 'image/jpeg');
    return JSON.parse(response);
  } catch (error) {
    console.error("Document analysis API failed, returning fallback data:", error);
    
    // Fallback dummy data
    return {
      summary: `Document analysis completed. The document has been processed and contains standard trade finance information. Technical services are currently experiencing connectivity issues.`,
      compliance: [
        {
          status: 'pass' as const,
          message: 'Document format appears standard',
          reference: 'Fallback Analysis'
        },
        {
          status: 'warning' as const,
          message: 'Unable to perform full compliance check due to service issues',
          reference: 'System Status'
        }
      ],
      keyFindings: [
        'Document uploaded successfully',
        'Basic format validation completed',
        'Full analysis pending service restoration'
      ]
    };
  }
}

export async function analyzeImageDocument(base64Image: string, customPrompt: string): Promise<{
  extractedText: string;
  analysis: {
    summary: string;
    compliance: Array<{
      status: 'pass' | 'warning' | 'fail';
      message: string;
      reference?: string;
    }>;
    keyFindings: string[];
  };
}> {
  try {
    const systemPrompt = `You are Sai Kumar Karnate's Document Extraction AI specialist. Analyze the provided image document for trade finance compliance and extract all text and key information.

Extract all visible text and provide comprehensive analysis including:
- Complete text extraction from the image
- Document validation and compliance checks  
- Key data identification (dates, amounts, parties, terms)
- Risk assessment and potential issues

Return the analysis in this exact JSON format:
{
  "extractedText": "Complete extracted text from the image",
  "analysis": {
    "summary": "Document analysis summary",
    "compliance": [
      {"status": "pass|warning|fail", "message": "Compliance message", "reference": "Standard reference"}
    ],
    "keyFindings": ["Finding 1", "Finding 2", "Finding 3"]
  }
}`;

    const prompt = `${customPrompt}
    
    Please provide:
    1. Complete text extraction from the image
    2. Document analysis and compliance assessment
    3. Key findings for Sai Kumar Karnate
    
    Focus on accuracy and completeness of the extracted information.`;

    const response = await callChatCompletionsAPI(prompt, systemPrompt, base64Image, 'image/jpeg');
    return JSON.parse(response);
  } catch (error) {
    console.error("Image document analysis API failed, returning fallback data:", error);
    
    // Fallback dummy data
    return {
      extractedText: `[Service temporarily unavailable] Document image received for analysis. Text extraction services are currently experiencing connectivity issues. Please try again later or contact support for manual processing.`,
      analysis: {
        summary: `Image document processing attempted. Technical services are currently unavailable for full analysis.`,
        compliance: [
          {
            status: 'warning' as const,
            message: 'Image uploaded successfully but analysis service unavailable',
            reference: 'System Status'
          },
          {
            status: 'pass' as const,
            message: 'Document format appears to be valid image type',
            reference: 'File Validation'
          }
        ],
        keyFindings: [
          'Image document received and validated',
          'Text extraction service temporarily unavailable',
          'Manual review may be required'
        ]
      }
    };
  }
}

export async function getTradeCalculations(): Promise<any> {
  try {
    const systemPrompt = `You are Sai Kumar Karnate's Trade Finance Calculation specialist. Provide comprehensive trade finance calculations and analysis tools.`;
    
    const prompt = `Provide trade finance calculations and analysis tools for Sai Kumar Karnate. Include the following sections:

1. LC Issuance Calculations - fees, processing costs, risk assessments
2. Trade Finance Margins - profit margins, spreads, pricing models  
3. Foreign Exchange Calculations - currency conversions, hedging costs
4. Documentary Collections - fees and timelines
5. Supply Chain Finance - working capital optimization
6. Risk Assessment Tools - country risk, counterparty analysis

Return the response in this exact JSON structure:
{
  "calculations": [
    {
      "type": "LC Issuance Cost Calculator",
      "description": "Calculate total costs for letter of credit issuance",
      "fields": [
        {"name": "LC Amount", "type": "currency", "placeholder": "Enter LC amount"},
        {"name": "Tenor (Days)", "type": "number", "placeholder": "Enter tenor in days"},
        {"name": "Country Risk Rating", "type": "select", "options": ["A", "B", "C", "D"]}
      ],
      "formula": "Base Fee + Risk Premium + Processing Fee",
      "sampleResult": {
        "baseFee": 2500,
        "riskPremium": 750,
        "processingFee": 300,
        "totalCost": 3550
      }
    }
  ],
  "insights": [
    "Current market rates favor USD-based transactions",
    "Emerging market premiums have increased by 15% this quarter"
  ],
  "dataSource": "realtime"
}

Provide realistic, current market data for trade finance calculations.`;

    const response = await callChatCompletionsAPI(prompt, systemPrompt);
    return JSON.parse(response);
  } catch (error) {
    console.error('Trade calculations API failed:', error);
    return {
      calculations: [
        {
          type: "LC Issuance Cost Calculator",
          description: "Calculate total costs for letter of credit issuance",
          fields: [
            {"name": "LC Amount", "type": "currency", "placeholder": "Enter LC amount"},
            {"name": "Tenor (Days)", "type": "number", "placeholder": "Enter tenor in days"},
            {"name": "Country Risk Rating", "type": "select", "options": ["A", "B", "C", "D"]}
          ],
          formula: "Base Fee + Risk Premium + Processing Fee",
          sampleResult: {
            baseFee: 2500,
            riskPremium: 750,
            processingFee: 300,
            totalCost: 3550
          }
        }
      ],
      insights: [
        "Sample data - API connectivity issue",
        "Contact your relationship manager for current rates"
      ],
      dataSource: "fallback"
    };
  }
}

export async function getPredictionsInsights(): Promise<any> {
  try {
    const systemPrompt = `You are Sai Kumar Karnate's Trade Finance Market Analyst. Provide comprehensive market predictions and insights.`;
    
    const prompt = `Provide market predictions and insights for Sai Kumar Karnate. Include:

1. Market Trends - commodity prices, trade volumes, regional analysis
2. Risk Predictions - geopolitical risks, currency volatility, credit risks  
3. Strategic Insights - opportunities, regulatory changes, best practices
4. Trade Finance Outlook - rate forecasts, demand projections

Return the response in this exact JSON structure:
{
  "marketTrends": [
    {
      "category": "Commodity Prices",
      "trend": "up|down|stable", 
      "percentage": 5.2,
      "description": "Detailed market analysis",
      "timeframe": "Next 3 months"
    }
  ],
  "riskPredictions": [
    {
      "type": "Currency Volatility",
      "severity": "low|medium|high|critical",
      "probability": 0.75,
      "impact": "Potential impact description", 
      "mitigation": "Risk mitigation strategy"
    }
  ],
  "insights": [
    {
      "title": "Market Opportunity",
      "type": "opportunity|warning|trend|recommendation",
      "description": "Detailed insight description",
      "actionable": ["Action item 1", "Action item 2"]
    }
  ],
  "dataSource": "realtime"
}

Provide current, actionable insights based on real market conditions.`;

    const response = await callChatCompletionsAPI(prompt, systemPrompt);
    return JSON.parse(response);
  } catch (error) {
    console.error('Predictions insights API failed:', error);
    return {
      marketTrends: [
        {
          category: "Sample Data",
          trend: "stable",
          percentage: 0,
          description: "API connectivity issue - using sample data",
          timeframe: "Unavailable"
        }
      ],
      riskPredictions: [
        {
          type: "System Status",
          severity: "medium",
          probability: 1.0,
          impact: "Real-time data temporarily unavailable",
          mitigation: "Contact your relationship manager for current insights"
        }
      ],
      insights: [
        {
          title: "Data Connectivity",
          type: "warning",
          description: "Unable to fetch real-time market data",
          actionable: ["Check API connectivity", "Use cached data if available"]
        }
      ],
      dataSource: "fallback"
    };
  }
}

export async function getHighRiskAnalysis(text: string, documentBase64?: string): Promise<any> {
  try {
    const systemPrompt = `You are Sai Kumar Karnate's High Risk Goods and Dual-Use Detection specialist. Analyze the provided content for items that may require special export licenses or could be considered dual-use.

Focus on detecting:
- Dual-use goods and technologies
- Weapons and military equipment
- Chemical and biological materials
- Nuclear materials and equipment
- Advanced electronics and semiconductors
- Encryption and cybersecurity tools

Return analysis in this exact JSON format:
{
  "riskLevel": "low|medium|high|critical",
  "detectedItems": [
    {
      "item": "Item name",
      "category": "dual-use|weapons|chemicals|nuclear|electronics|other",
      "riskScore": 7.5,
      "description": "Detailed risk description",
      "recommendations": ["Action 1", "Action 2"]
    }
  ],
  "complianceFlags": [
    {
      "type": "export_control|sanctions|licensing",
      "severity": "low|medium|high|critical",
      "message": "Compliance message"
    }
  ],
  "recommendations": ["Overall recommendation 1", "Overall recommendation 2"]
}`;

    const prompt = `Analyze this content for high-risk goods and dual-use items for Sai Kumar Karnate:

    Text Content: ${text}
    
    Provide comprehensive risk assessment including detected items, compliance flags, and specific recommendations for export control compliance.`;

    const response = await callChatCompletionsAPI(prompt, systemPrompt, documentBase64, 'image/jpeg');
    return JSON.parse(response);
  } catch (error) {
    console.error('High risk analysis API failed, returning fallback data:', error);
    return {
      riskLevel: "unknown",
      detectedItems: [
        {
          item: "Analysis Pending",
          category: "other",
          riskScore: 0,
          description: "High-risk analysis service temporarily unavailable. Manual review recommended.",
          recommendations: ["Contact compliance team for manual review", "Defer shipment until analysis complete"]
        }
      ],
      complianceFlags: [
        {
          type: "export_control",
          severity: "medium",
          message: "Unable to complete automated risk assessment - manual review required"
        }
      ],
      recommendations: [
        "Contact your compliance officer for manual review",
        "Do not proceed with export until clearance obtained",
        "Retry analysis when services are restored"
      ],
      dataSource: "fallback"
    };
  }
}

export async function getActivityAnalysis(transactionData?: string): Promise<any> {
  try {
    const prompt = `As a Wells Fargo compliance and risk analyst, analyze trade finance activities and provide comprehensive analysis in JSON format. Include:

1. Document Analysis - validation status, compliance checks
2. Settlement Analysis - payment flows, timing, methods
3. Risk Assessment - red flags, compliance status, sanctions screening
4. Fee Analysis - breakdown of all charges and fees
5. Party Analysis - counterparty risk, KYC status

${transactionData ? `Analyze this transaction data: ${transactionData}` : 'Provide a general trade activity analysis.'}

Return the response in this exact JSON structure:
{
  "referenceNumber": "TF-2024-001234",
  "documents": [
    {
      "type": "Letter of Credit",
      "status": "Validated", 
      "value": 250000,
      "currency": "USD",
      "date": "2024-01-15"
    }
  ],
  "settlements": [
    {
      "amount": 250000,
      "currency": "USD", 
      "settlementDate": "2024-01-30",
      "status": "pending|completed|failed",
      "method": "SWIFT Wire Transfer"
    }
  ],
  "fees": [
    {
      "type": "LC Issuance Fee",
      "amount": 2500,
      "currency": "USD",
      "description": "Letter of credit issuance and processing"
    }
  ],
  "redFlags": [
    {
      "severity": "low|medium|high|critical",
      "type": "Compliance Check",
      "description": "Issue description",
      "recommendation": "Recommended action"
    }
  ],
  "parties": [
    {
      "name": "ABC Trading Corp",
      "type": "buyer|seller|bank|intermediary",
      "country": "United States", 
      "sanctionStatus": "clear|watchlist|sanctioned",
      "riskLevel": "low|medium|high"
    }
  ],
  "riskScore": 25,
  "complianceStatus": "compliant|warning|violation",
  "dataSource": "realtime"
}

Provide realistic trade finance activity analysis.`;

    const systemPrompt = `You are Sai Kumar Karnate's Trade Finance Activity Analyst. Analyze trade finance activities for risk and regulatory compliance.`;
    
    const response = await callChatCompletionsAPI(prompt, systemPrompt);
    return JSON.parse(response);
  } catch (error) {
    console.error('Activity analysis API failed:', error);
    return {
      referenceNumber: "SAMPLE-2024-001",
      documents: [{
        type: "Sample Document",
        status: "API Error",
        value: 0,
        currency: "USD",
        date: new Date().toISOString().split('T')[0]
      }],
      settlements: [],
      fees: [],
      redFlags: [{
        severity: "medium",
        type: "System Status",
        description: "Unable to fetch real-time activity data",
        recommendation: "Contact your relationship manager for current analysis"
      }],
      parties: [],
      riskScore: 0,
      complianceStatus: "warning",
      dataSource: "fallback"
    };
  }
}


