import { 
  users, 
  chatMessages,
  documents,
  redFlagEntries,
  documentExtractionHistory,
  type User, 
  type InsertUser,
  type ChatMessage,
  type InsertChatMessage,
  type Document,
  type InsertDocument,
  type RedFlagEntry,
  type InsertRedFlagEntry,
  type DocumentExtractionHistory,
  type InsertDocumentExtractionHistory
} from "@shared/schema";

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Chat messages
  createChatMessage(message: InsertChatMessage): Promise<ChatMessage>;
  getChatMessagesBySession(sessionId: string): Promise<ChatMessage[]>;
  
  // Documents
  createDocument(document: InsertDocument): Promise<Document>;
  getDocumentsBySession(sessionId: string): Promise<Document[]>;
  getDocument(id: number): Promise<Document | undefined>;
  updateDocumentAnalysis(id: number, analysisResult: any, summary: string): Promise<Document | undefined>;
  updateDocumentExtraction(id: number, scanLabels: string[], extractedFields: any[]): Promise<Document | undefined>;
  getRecentDocuments(limit?: number): Promise<Document[]>;
  
  // Red Flag Entries
  createRedFlagEntry(entry: InsertRedFlagEntry): Promise<RedFlagEntry>;
  getRedFlagEntries(): Promise<RedFlagEntry[]>;
  deleteRedFlagEntry(id: number): Promise<boolean>;
  
  // Document Extraction History
  createDocumentExtractionHistory(history: InsertDocumentExtractionHistory): Promise<DocumentExtractionHistory>;
  getDocumentExtractionHistory(documentId: number): Promise<DocumentExtractionHistory[]>;
  
  // Get all documents
  getAllDocuments(): Promise<Document[]>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private chatMessages: Map<number, ChatMessage>;
  private documents: Map<number, Document>;
  private redFlagEntries: Map<number, RedFlagEntry>;
  private documentExtractionHistory: Map<number, DocumentExtractionHistory>;
  private currentUserId: number;
  private currentMessageId: number;
  private currentDocumentId: number;
  private currentRedFlagId: number;
  private currentHistoryId: number;

  constructor() {
    this.users = new Map();
    this.chatMessages = new Map();
    this.documents = new Map();
    this.redFlagEntries = new Map();
    this.documentExtractionHistory = new Map();
    this.currentUserId = 1;
    this.currentMessageId = 1;
    this.currentDocumentId = 1;
    this.currentRedFlagId = 1;
    this.currentHistoryId = 1;
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async createChatMessage(insertMessage: InsertChatMessage): Promise<ChatMessage> {
    const id = this.currentMessageId++;
    const message: ChatMessage = {
      ...insertMessage,
      id,
      createdAt: new Date(),
    };
    this.chatMessages.set(id, message);
    return message;
  }

  async getChatMessagesBySession(sessionId: string): Promise<ChatMessage[]> {
    return Array.from(this.chatMessages.values())
      .filter(msg => msg.sessionId === sessionId)
      .sort((a, b) => a.createdAt.getTime() - b.createdAt.getTime());
  }

  async createDocument(insertDocument: InsertDocument): Promise<Document> {
    const id = this.currentDocumentId++;
    const document: Document = {
      ...insertDocument,
      id,
      analysisResult: null,
      summary: null,
      scanLabels: null,
      extractedFields: null,
      createdAt: new Date(),
    };
    this.documents.set(id, document);
    console.log(`Created document with ID: ${id}, name: ${document.originalName}`);
    return document;
  }

  async getDocumentsBySession(sessionId: string): Promise<Document[]> {
    return Array.from(this.documents.values())
      .filter(doc => doc.sessionId === sessionId)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  async getDocument(id: number): Promise<Document | undefined> {
    console.log(`Looking for document with ID: ${id}`);
    console.log(`Available document IDs: ${Array.from(this.documents.keys())}`);
    return this.documents.get(id);
  }

  async updateDocumentAnalysis(id: number, analysisResult: any, summary: string): Promise<Document | undefined> {
    const document = this.documents.get(id);
    if (document) {
      const updatedDocument = { ...document, analysisResult, summary };
      this.documents.set(id, updatedDocument);
      return updatedDocument;
    }
    return undefined;
  }

  async updateDocumentExtraction(id: number, scanLabels: string[], extractedFields: any[]): Promise<Document | undefined> {
    const document = this.documents.get(id);
    if (document) {
      const updatedDocument = { ...document, scanLabels, extractedFields };
      this.documents.set(id, updatedDocument);
      
      // Also create extraction history record
      await this.createDocumentExtractionHistory({
        documentId: id,
        scanLabels,
        extractedFields
      });
      
      return updatedDocument;
    }
    return undefined;
  }

  async getRecentDocuments(limit: number = 5): Promise<Document[]> {
    console.log(`=== getRecentDocuments called, storage has ${this.documents.size} documents ===`);
    const allDocs = Array.from(this.documents.values());
    console.log(`Document IDs in storage: ${allDocs.map(d => d.id).join(', ')}`);
    const sorted = allDocs
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime())
      .slice(0, limit);
    console.log(`Returning ${sorted.length} documents from storage`);
    return sorted;
  }

  // Red Flag Entries
  async createRedFlagEntry(insertEntry: InsertRedFlagEntry): Promise<RedFlagEntry> {
    const id = this.currentRedFlagId++;
    const entry: RedFlagEntry = {
      ...insertEntry,
      id,
      createdAt: new Date(),
    };
    this.redFlagEntries.set(id, entry);
    return entry;
  }

  async getRedFlagEntries(): Promise<RedFlagEntry[]> {
    return Array.from(this.redFlagEntries.values())
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  async deleteRedFlagEntry(id: number): Promise<boolean> {
    return this.redFlagEntries.delete(id);
  }

  // Document Extraction History
  async createDocumentExtractionHistory(insertHistory: InsertDocumentExtractionHistory): Promise<DocumentExtractionHistory> {
    const id = this.currentHistoryId++;
    const history: DocumentExtractionHistory = {
      ...insertHistory,
      id,
      extractedAt: new Date(),
    };
    this.documentExtractionHistory.set(id, history);
    return history;
  }

  async getDocumentExtractionHistory(documentId: number): Promise<DocumentExtractionHistory[]> {
    return Array.from(this.documentExtractionHistory.values())
      .filter(history => history.documentId === documentId)
      .sort((a, b) => b.extractedAt.getTime() - a.extractedAt.getTime());
  }

  async getAllDocuments(): Promise<Document[]> {
    return Array.from(this.documents.values())
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }
}

export const storage = new MemStorage();
